import React, { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  motion,
  useMotionValue,
  useMotionValueEvent,
  useReducedMotion,
  useScroll,
  useTransform,
  type MotionValue,
} from 'framer-motion';
import { ArrowUpRight, FlaskConical } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Botanical } from '@/components/site/apothecary/Botanicals';
import { Vessel } from '@/components/site/apothecary/Vessels';
import { remedies, type Ingredient, type Remedy, type Tint, type VesselId } from '@/data/remedies';

/* ---------------------------------------------------------------------------
 * The dispensary
 * ---------------------------------------------------------------------------
 * The one scene on the site that is not a photograph of a room.
 *
 * A vessel is pinned in the middle of the screen; as you scroll it comes apart
 * and the plants inside it lift out and take their places around it, each
 * labelled. Six preparations run through the same stage back to back, so the
 * scroll reads as "here is what we actually put on you, and what is in it".
 *
 * How it stays smooth
 *   · one scroll source (`useScroll` on the track) feeding one spring; every
 *     other value is a `useTransform` off that spring, so nothing here calls
 *     setState on scroll except the ledger index, which changes six times.
 *   · every animated property is transform or opacity.
 *   · values are clamped, so a scene that is off-stage produces an unchanged
 *     output and framer skips the style write entirely.
 *   · the ring of ingredients is scaled as one layer and each medallion is
 *     counter-scaled, which is what lets the plants converge into the vessel
 *     without a single measurement or a single pixel value in the markup.
 *
 * Colours come from `--rx-*`, defined on `.dispensary` in site-theme.css:
 * Tailwind drops the `/60` alpha modifier when it is applied to an arbitrary
 * `hsl(...)` value, so every translucent colour here carries its own alpha.
 * ------------------------------------------------------------------------- */

/** Ambient backdrop for the pinned frame. */
const WASH =
  'radial-gradient(42rem 30rem at 82% 4%, hsl(38 86% 52% / 0.1), transparent 62%),' +
  'radial-gradient(34rem 30rem at 6% 46%, hsl(140 50% 40% / 0.14), transparent 62%),' +
  'radial-gradient(40rem 26rem at 60% 104%, hsl(38 70% 50% / 0.06), transparent 66%)';

/** Scroll distance each preparation is given, in viewport heights. */
const STEP_VH = 88;

/** Where the medallions settle, as a percentage of the stage's half-size. */
const RING_X = 38;
const RING_Y = 36;

/**
 * Medallions are dealt alternately to the right and left of the vessel and
 * spread across a ±52° arc on each side — never straight above or below it.
 * A ring that runs the full 360° puts a medallion exactly where the lid
 * travels, and every vessel here is taller than it is wide, so the top and
 * bottom of the stage has to stay clear.
 */
const angleFor = (index: number, count: number) => {
  const right = Math.ceil(count / 2);
  const left = count - right;
  const onRight = index % 2 === 0;
  const seat = Math.floor(index / 2);
  const seats = onRight ? right : left;
  const spread = seats === 1 ? 0 : -52 + (104 * seat) / (seats - 1);
  return (onRight ? spread : 180 - spread) * (Math.PI / 180);
};

const TINTS: Record<Tint, string> = {
  leaf: '140 44% 62%',
  amber: '38 86% 62%',
  clay: '20 60% 63%',
  stone: '44 22% 80%',
};

/** The colour of what is inside each vessel. */
const FLUID: Record<VesselId, string> = {
  vial: '38 86% 58%',
  capsule: '74 48% 58%',
  potli: '84 44% 54%',
  dhara: '44 62% 72%',
  vati: '24 54% 58%',
  jar: '20 62% 46%',
};

/* -- one ingredient medallion --------------------------------------------- */

const Medallion = React.memo(
  ({
    ingredient,
    index,
    count,
    travel,
    size,
    still,
  }: {
    ingredient: Ingredient;
    index: number;
    count: number;
    /** 0 = inside the vessel, 1 = settled in its place. */
    travel: MotionValue<number>;
    /** Live width of the square stage, in px. */
    size: MotionValue<number>;
    still: boolean;
  }) => {
    const angle = angleFor(index, count);
    const left = 50 + RING_X * Math.cos(angle);
    const top = 50 + RING_Y * Math.sin(angle);
    /** Medallions above the vessel caption upward, so nothing crosses the middle. */
    const above = Math.sin(angle) < -0.3;

    const from = 0.16 + index * 0.04;
    const eased = useTransform(travel, [from, from + 0.46], [0, 1]);
    const opacity = useTransform(eased, [0, 0.35], [0, 1]);

    // The medallion is laid out at its final spot and pulled back toward the
    // centre; at travel 0 the offset cancels the layout position exactly.
    //
    // The first version scaled the whole ring and counter-scaled each medallion,
    // which needed no measurement at all — but scaling a box of live text forces
    // Chrome to re-rasterise it every frame, and thirty-five of those was the
    // section's single biggest frame cost. Translation on a promoted layer is
    // pure compositing.
    const dx = (RING_X / 100) * Math.cos(angle);
    const dy = (RING_Y / 100) * Math.sin(angle);
    const x = useTransform([eased, size] as const, ([e, s]: number[]) => -(1 - e) * dx * s);
    const y = useTransform([eased, size] as const, ([e, s]: number[]) => -(1 - e) * dy * s);

    const tint = TINTS[ingredient.tint];

    return (
      <li
        className="absolute w-[5.25rem] sm:w-24"
        style={{ left: `${left}%`, top: `${top}%`, transform: 'translate(-50%, -50%)' }}
      >
        <motion.div
          className={cn('group flex items-center', above ? 'flex-col-reverse' : 'flex-col')}
          style={still ? undefined : { x, y, opacity, willChange: 'transform' }}
        >
          <span
            className="grid h-14 w-14 place-items-center rounded-full border sm:h-16 sm:w-16"
            style={{
              borderColor: `hsl(${tint} / 0.4)`,
              background: `hsl(${tint} / 0.1)`,
              ['--rx-fill' as string]: `hsl(${tint} / 0.26)`,
              color: `hsl(${tint})`,
            }}
          >
            <Botanical id={ingredient.glyph} className="h-8 w-8 sm:h-9 sm:w-9" />
          </span>

          <span className={cn('flex flex-col items-center', above ? 'mb-2' : 'mt-2')}>
            <span className="text-center text-[0.66rem] font-semibold uppercase tracking-[0.12em] text-[hsl(var(--rx-ink)/0.95)] sm:text-[0.7rem]">
              {ingredient.name}
            </span>
            <span className="text-center font-display text-[0.62rem] italic leading-tight text-[hsl(var(--rx-ink)/0.5)]">
              {ingredient.sanskrit}
            </span>
            <span className="mt-1 hidden w-28 text-center text-[0.62rem] leading-snug text-[hsl(var(--rx-ink)/0.42)] transition-colors duration-300 group-hover:text-[hsl(var(--rx-gold)/0.9)] sm:block">
              {ingredient.role}
            </span>
          </span>
        </motion.div>
      </li>
    );
  }
);
Medallion.displayName = 'Medallion';

/* -- one preparation ------------------------------------------------------- */

const Scene = React.memo(({
  remedy,
  index,
  total,
  progress,
  still,
}: {
  remedy: Remedy;
  index: number;
  total: number;
  progress: MotionValue<number>;
  /** Reduced motion: render the scene already open, in normal document flow. */
  still: boolean;
}) => {
  // Where this scene sits relative to the playhead: <0 not yet, >1 gone past.
  const rel = useTransform(progress, (p) => (still ? 0.72 : p * total - index));
  const local = useTransform(rel, (v) => Math.min(1, Math.max(0, v)));

  const open = useTransform(local, [0.1, 0.58], [0, 1]);
  const vesselScale = useTransform(local, [0.06, 0.5], [0.88, 1]);
  const glow = useTransform(local, [0.1, 0.7], [0, 1]);
  /** Connector lines grow with the medallions; no per-item stagger needed. */
  const spokes = useTransform(local, [0.16, 0.8], [0.05, 1]);

  // The medallions need the stage's pixel width to convert their polar seats
  // into a translation. One observer per scene, only firing on resize.
  const stageRef = useRef<HTMLDivElement>(null);
  const size = useMotionValue(0);
  useEffect(() => {
    const el = stageRef.current;
    if (!el) return;
    size.set(el.clientWidth);
    const observer = new ResizeObserver(([entry]) => size.set(entry.contentRect.width));
    observer.observe(el);
    return () => observer.disconnect();
  }, [size]);

  // Cross-fade. The first scene starts visible, the last one stays.
  const fadeIn = index === 0 ? [-9, -8.98] : [-0.09, 0];
  const fadeOut = index === total - 1 ? [8.98, 9] : [0.91, 1];
  const opacity = useTransform(rel, [...fadeIn, ...fadeOut], [0, 1, 1, 0]);
  const shift = useTransform(rel, [...fadeIn, ...fadeOut], [22, 0, 0, -22]);
  // Only the scene actually on stage should take a click. Derived from the same
  // scroll value rather than from React state: a `useState` here re-renders all
  // six scenes and every medallion in them, which showed up as a 50ms long task
  // each time the playhead crossed into the next preparation.
  const pointerEvents = useTransform(opacity, (v) => (v > 0.85 ? 'auto' : 'none'));

  return (
    <motion.article
      className={cn(
        'grid w-full items-center gap-8 lg:grid-cols-[minmax(0,0.86fr)_minmax(0,1fr)] lg:gap-12',
        !still && 'absolute inset-0 content-center'
      )}
      style={still ? undefined : { opacity, y: shift, pointerEvents }}
    >
      {/* -- the label ----------------------------------------------------- */}
      <div className="order-2 text-center lg:order-1 lg:text-left">
        <p className="flex items-center justify-center gap-3 lg:justify-start">
          <span className="rx-numeral font-display text-[2.6rem] font-extrabold leading-none">
            {String(index + 1).padStart(2, '0')}
          </span>
          <span className="h-px w-9 bg-[hsl(var(--rx-ink)/0.22)]" aria-hidden />
          <span className="text-[0.66rem] font-semibold uppercase tracking-[0.22em] text-[hsl(var(--rx-gold))]">
            {remedy.form}
          </span>
        </p>

        <h3 className="mt-3 font-display text-[1.7rem] font-extrabold leading-[1.1] text-[hsl(var(--rx-ink))] sm:text-[2.4rem]">
          {remedy.name}
        </h3>

        <p className="mt-2 font-display text-base italic text-[hsl(var(--rx-gold)/0.9)] sm:text-lg">
          {remedy.tagline}
        </p>

        <p className="mx-auto mt-4 hidden max-w-xl text-sm leading-relaxed text-[hsl(var(--rx-ink)/0.66)] sm:block lg:mx-0 lg:text-[0.95rem]">
          {remedy.description}
        </p>

        <p className="mt-4 flex items-start justify-center gap-2 text-xs leading-relaxed text-[hsl(var(--rx-ink)/0.5)] lg:justify-start">
          <FlaskConical className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[hsl(var(--rx-gold)/0.8)]" aria-hidden />
          <span>
            {remedy.method}{' '}
            <span className="font-display italic text-[hsl(var(--rx-ink)/0.38)]">— {remedy.source}</span>
          </span>
        </p>

        <div className="mt-6 flex flex-wrap justify-center gap-2 lg:justify-start">
          <span className="sr-only">Used in these therapies:</span>
          {remedy.usedIn.map((therapy) => (
            <Link
              key={therapy.slug}
              to={`/treatments#therapy-${therapy.slug}`}
              className="group inline-flex items-center gap-1 rounded-full border border-[hsl(var(--rx-ink)/0.16)] px-3 py-1.5 text-[0.72rem] font-semibold text-[hsl(var(--rx-ink)/0.78)] transition-colors hover:border-[hsl(var(--rx-gold)/0.5)] hover:text-[hsl(var(--rx-gold))]"
            >
              {therapy.name}
              <ArrowUpRight
                className="h-3 w-3 opacity-60 transition-transform group-hover:translate-x-0.5"
                aria-hidden
              />
            </Link>
          ))}
        </div>
      </div>

      {/* -- the vessel and what is inside it ------------------------------ */}
      <div className="order-1 flex justify-center lg:order-2">
        <div ref={stageRef} className="relative aspect-square w-[min(84vw,25rem)] lg:w-[min(38vw,30rem)]">
          <span
            aria-hidden
            className="absolute inset-[7%] rounded-full border border-dashed border-[hsl(var(--rx-ink)/0.12)]"
          />

          {/* what is inside, glowing through the shell */}
          <motion.span
            aria-hidden
            className="absolute inset-[18%] rounded-full"
            style={{
              background: `radial-gradient(circle, hsl(${FLUID[remedy.vessel]} / 0.3), transparent 68%)`,
              ...(still ? {} : { opacity: glow }),
            }}
          />

          {/* the vessel — deliberately outside the ring, so it never scales */}
          <motion.div
            className="absolute inset-0 grid place-items-center"
            style={{
              ['--rx-fluid' as string]: `hsl(${FLUID[remedy.vessel]} / 0.62)`,
              ...(still ? {} : { scale: vesselScale, willChange: 'transform' }),
            }}
          >
            <Vessel id={remedy.vessel} open={open} className="h-[48%] w-auto text-[hsl(var(--rx-ink)/0.88)]" />
          </motion.div>

          {/* the ingredients, carried outward as one layer */}
          <ul className="absolute inset-0 list-none">
            <svg
              viewBox="0 0 100 100"
              preserveAspectRatio="none"
              className="absolute inset-0 h-full w-full"
              aria-hidden
            >
              <motion.g
                style={
                  still
                    ? undefined
                    : { scale: spokes, transformBox: 'fill-box', transformOrigin: 'center' }
                }
              >
              {remedy.ingredients.map((ingredient, i) => {
                const a = angleFor(i, remedy.ingredients.length);
                return (
                  <line
                    key={ingredient.name}
                    x1="50"
                    y1="50"
                    x2={50 + RING_X * Math.cos(a)}
                    y2={50 + RING_Y * Math.sin(a)}
                    stroke="hsl(var(--rx-ink) / 0.16)"
                    strokeWidth={1}
                    vectorEffect="non-scaling-stroke"
                  />
                );
              })}
              </motion.g>
            </svg>

            {remedy.ingredients.map((ingredient, i) => (
              <Medallion
                key={ingredient.name}
                ingredient={ingredient}
                index={i}
                count={remedy.ingredients.length}
                travel={local}
                size={size}
                still={still}
              />
            ))}
          </ul>
        </div>
      </div>
    </motion.article>
  );
});
Scene.displayName = 'Scene';

/* -- the ledger ----------------------------------------------------------- */

/**
 * Which preparation is on stage, 01–06. This is the only thing in the section
 * that holds React state, and it is deliberately isolated here: when the state
 * lived in the section, every crossing re-rendered all six scenes and all
 * thirty-five medallions inside them — a 50ms long task, six times per pass.
 */
const Ledger = ({ progress }: { progress: MotionValue<number> }) => {
  const [current, setCurrent] = useState(0);

  useMotionValueEvent(progress, 'change', (v) => {
    const next = Math.min(remedies.length - 1, Math.max(0, Math.floor(v * remedies.length + 0.05)));
    setCurrent((prev) => (prev === next ? prev : next));
  });

  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-[5.5rem] sm:bottom-6">
      <ol className="shell flex items-center justify-center gap-3 sm:justify-start">
        {remedies.map((remedy, i) => (
          <li key={remedy.slug} className="flex items-center gap-2">
            <span
              aria-hidden
              className={cn(
                'block h-px transition-all duration-500',
                current === i ? 'w-9 bg-[hsl(var(--rx-gold))]' : 'w-4 bg-[hsl(var(--rx-ink)/0.22)]'
              )}
            />
            <span
              className={cn(
                'text-[0.6rem] font-semibold tabular-nums tracking-[0.16em] transition-colors duration-500',
                current === i ? 'text-[hsl(var(--rx-gold))]' : 'text-[hsl(var(--rx-ink)/0.28)]'
              )}
            >
              {String(i + 1).padStart(2, '0')}
            </span>
          </li>
        ))}
      </ol>
    </div>
  );
};

/* -- the section ---------------------------------------------------------- */

const ApothecarySection = () => {
  const reduce = useReducedMotion();
  const trackRef = useRef<HTMLDivElement>(null);
  // Read raw, with no spring in between. A spring here looks tempting, but on a
  // pinned scene the scroll position *is* the playhead: any smoothing means the
  // vessel keeps opening after you have stopped scrolling. The first version of
  // this section used stiffness 280 / damping 44, which took over two seconds to
  // catch up after a flick — indistinguishable from the page being slow.
  const { scrollYProgress } = useScroll({ target: trackRef, offset: ['start start', 'end end'] });
  const idle = useMotionValue(0);
  const still = !!reduce;
  const barScale = useTransform(scrollYProgress, [0, 1], [0.02, 1]);

  return (
    <section
      id="dispensary"
      aria-labelledby="dispensary-heading"
      className="dispensary relative [overflow:clip] bg-[hsl(var(--rx-bg))] text-[hsl(var(--rx-ink))]"
    >
      <span aria-hidden className="absolute inset-x-0 top-0 h-px bg-[hsl(var(--rx-gold)/0.35)]" />

      {/* -- intro ---------------------------------------------------------- */}
      <div className="shell relative pt-20 sm:pt-28">
        <div className="mx-auto max-w-3xl text-center">
          <span className="eyebrow !border-[hsl(var(--rx-gold)/0.25)] !bg-[hsl(var(--rx-gold)/0.1)] !text-[hsl(var(--rx-gold))]">
            <FlaskConical className="h-3.5 w-3.5" aria-hidden />
            Inside the medicine
          </span>
          <h2
            id="dispensary-heading"
            className="mt-5 font-display text-3xl font-extrabold leading-[1.12] sm:text-4xl lg:text-[2.7rem]"
          >
            Open the vessel. Everything in it{' '}
            <span className="text-[hsl(var(--rx-gold))]">grew in soil.</span>
          </h2>
          <p className="mt-4 text-base leading-relaxed text-[hsl(var(--rx-ink)/0.66)] sm:text-lg">
            No proprietary blends, no unnamed actives. These are the six preparations our pharmacy
            compounds most — scroll to take each one apart.
          </p>
        </div>
      </div>

      {/* -- the pinned run -------------------------------------------------- */}
      {still ? (
        <div className="shell relative space-y-24 py-20">
          {remedies.map((remedy, i) => (
            <Scene
              key={remedy.slug}
              remedy={remedy}
              index={i}
              total={remedies.length}
              progress={idle}
              still
            />
          ))}
        </div>
      ) : (
        <div
          ref={trackRef}
          className="relative"
          style={{ height: `calc(${remedies.length} * ${STEP_VH}svh + 100svh)` }}
        >
          <div className="sticky top-0 flex h-[100svh] items-center [overflow:clip] pb-20 pt-16 sm:pb-10">
            {/* Ambient wash, scoped to the pinned frame. On the section itself
                this is a 1440×6000 gradient layer that Chrome re-rasterises as
                you scroll; here it is one viewport, painted once. */}
            <span aria-hidden className="pointer-events-none absolute inset-0" style={{ backgroundImage: WASH }} />

            <div className="shell relative w-full">
              <div className="relative h-[min(74svh,40rem)]">
                {remedies.map((remedy, i) => (
                  <Scene
                    key={remedy.slug}
                    remedy={remedy}
                    index={i}
                    total={remedies.length}
                    progress={scrollYProgress}
                    still={false}
                  />
                ))}
              </div>
            </div>

            <Ledger progress={scrollYProgress} />

            <motion.span
              aria-hidden
              className="absolute inset-x-0 bottom-[4.25rem] h-px origin-left bg-[hsl(var(--rx-gold)/0.55)] sm:bottom-0"
              style={{ scaleX: barScale }}
            />
          </div>
        </div>
      )}

      <div className="shell relative pb-20 pt-8 text-center sm:pb-28">
        <p className="mx-auto max-w-2xl text-sm leading-relaxed text-[hsl(var(--rx-ink)/0.5)]">
          Every formula above is dispensed from the hospital pharmacy after consultation. Quantity,
          combination and duration are set by the physician — nothing here is sold as a kit.
        </p>
      </div>
    </section>
  );
};

export default ApothecarySection;
