import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { ArrowRight, Check, ChevronDown, Clock, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { cn } from '@/lib/utils';
import SectionHeading from '@/components/site/SectionHeading';
import { EASE, Reveal } from '@/components/site/motion';
import { treatmentCategories, treatments, type Treatment } from '@/data/treatments';

const INITIAL_COUNT = 8;

const TreatmentCard = ({
  treatment,
  onOpen,
  index,
}: {
  treatment: Treatment;
  onOpen: (t: Treatment) => void;
  index: number;
}) => {
  const reduce = useReducedMotion();
  return (
    <motion.article
      layout={!reduce}
      initial={reduce ? false : { opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      exit={reduce ? undefined : { opacity: 0, y: -10 }}
      transition={{ duration: 0.45, delay: Math.min(index, 8) * 0.035, ease: EASE }}
      className="group surface surface-lift sheen flex h-full flex-col overflow-hidden"
    >
      <button
        type="button"
        onClick={() => onOpen(treatment)}
        aria-label={`View details of ${treatment.name}`}
        className="relative block aspect-[4/3] w-full overflow-hidden bg-muted text-left"
      >
        <img
          src={treatment.image}
          alt={`${treatment.name} — Ayurvedic therapy at Sri Vinayaga Ayurvibe, Chennai`}
          width={900}
          height={675}
          loading="lazy"
          decoding="async"
          className="h-full w-full object-cover transition-transform duration-[900ms] ease-out group-hover:scale-[1.06]"
        />
        <span
          aria-hidden
          className="absolute inset-0 bg-gradient-to-t from-foreground/70 via-transparent to-transparent opacity-80"
        />
        <span className="absolute left-3 top-3 rounded-full bg-background/92 px-2.5 py-1 text-[0.68rem] font-semibold uppercase tracking-wider text-foreground backdrop-blur">
          {treatment.category}
        </span>
        <span className="absolute bottom-3 left-3 flex items-center gap-1.5 text-xs font-medium text-white">
          <Clock className="h-3.5 w-3.5" aria-hidden />
          {treatment.duration}
        </span>
      </button>

      <div className="flex flex-1 flex-col p-5">
        <h3 className="font-display text-lg font-bold leading-snug text-foreground">
          {treatment.name}
        </h3>
        <p className="mt-2 line-clamp-3 text-sm leading-relaxed text-muted-foreground">
          {treatment.description}
        </p>

        <ul className="mt-4 space-y-1.5">
          {treatment.benefits.slice(0, 2).map((benefit) => (
            <li key={benefit} className="flex items-start gap-2 text-xs text-foreground/80">
              <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" aria-hidden />
              {benefit}
            </li>
          ))}
        </ul>

        <div className="mt-5 flex items-center gap-2 pt-1">
          <Button asChild size="sm" className="flex-1 rounded-full font-semibold">
            <Link to="/booking">Book</Link>
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={() => onOpen(treatment)}
            className="rounded-full border-border font-semibold hover:border-primary/40 hover:text-primary"
          >
            Details
          </Button>
        </div>
      </div>
    </motion.article>
  );
};

const TreatmentsSection = () => {
  const [filter, setFilter] = useState<string>('All');
  const [expanded, setExpanded] = useState(false);
  const [active, setActive] = useState<Treatment | null>(null);
  const reduce = useReducedMotion();

  const filtered = useMemo(
    () => (filter === 'All' ? treatments : treatments.filter((t) => t.category === filter)),
    [filter]
  );
  const visible = expanded ? filtered : filtered.slice(0, INITIAL_COUNT);

  return (
    <section id="treatments" aria-labelledby="treatments-heading" className="section-spacing bg-background">
      <div className="shell">
        <SectionHeading
          id="treatments-heading"
          eyebrow="Signature therapies"
          icon={Sparkles}
          title="33 classical treatments, matched to"
          highlight="your constitution"
          description="From Shirodhara and Pizhichil to Kati Vasti and Navara Kizhi — each therapy is prescribed after assessment, never sold as a standalone package."
        />

        {/* Category filter */}
        <Reveal className="mt-10 flex flex-wrap justify-center gap-2">
          <div className="flex flex-wrap justify-center gap-2" role="tablist" aria-label="Filter treatments by category">
            {treatmentCategories.map((category) => {
              const selected = filter === category;
              return (
                <button
                  key={category}
                  type="button"
                  role="tab"
                  aria-selected={selected}
                  onClick={() => {
                    setFilter(category);
                    setExpanded(false);
                  }}
                  className={cn(
                    'relative rounded-full border px-4 py-2 text-sm font-semibold transition-colors',
                    selected
                      ? 'border-primary text-primary-foreground'
                      : 'border-border text-muted-foreground hover:border-primary/40 hover:text-primary'
                  )}
                >
                  {selected && (
                    <motion.span
                      layoutId="treatment-filter-pill"
                      className="absolute inset-0 -z-10 rounded-full bg-primary"
                      transition={{ duration: 0.35, ease: EASE }}
                    />
                  )}
                  {category}
                </button>
              );
            })}
          </div>
        </Reveal>

        <p className="mt-5 text-center text-sm text-muted-foreground">
          Showing <span className="font-semibold text-foreground">{visible.length}</span> of{' '}
          <span className="font-semibold text-foreground">{filtered.length}</span> therapies
        </p>

        {/* Grid */}
        <motion.div
          layout={!reduce}
          className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4"
        >
          <AnimatePresence mode="popLayout">
            {visible.map((treatment, i) => (
              <TreatmentCard key={treatment.slug} treatment={treatment} onOpen={setActive} index={i} />
            ))}
          </AnimatePresence>
        </motion.div>

        {filtered.length > INITIAL_COUNT && (
          <div className="mt-10 text-center">
            <Button
              variant="outline"
              size="lg"
              onClick={() => setExpanded((v) => !v)}
              className="group rounded-full border-border px-7 font-semibold hover:border-primary/40 hover:text-primary"
            >
              {expanded ? 'Show fewer therapies' : `View all ${filtered.length} therapies`}
              <ChevronDown
                className={cn('ml-2 h-4 w-4 transition-transform duration-300', expanded && 'rotate-180')}
                aria-hidden
              />
            </Button>
          </div>
        )}
      </div>

      {/* Details dialog */}
      <Dialog open={!!active} onOpenChange={(open) => !open && setActive(null)}>
        <DialogContent className="max-h-[88vh] max-w-2xl overflow-y-auto rounded-2xl p-0">
          {active && (
            <>
              <div className="relative aspect-[16/9] w-full overflow-hidden bg-muted">
                <img
                  src={active.image}
                  alt={`${active.name} — Ayurvedic therapy at Sri Vinayaga Ayurvibe, Chennai`}
                  width={900}
                  height={506}
                  className="h-full w-full object-cover"
                />
                <span aria-hidden className="absolute inset-0 bg-gradient-to-t from-foreground/70 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 p-5">
                  <span className="rounded-full bg-background/92 px-2.5 py-1 text-[0.68rem] font-semibold uppercase tracking-wider text-foreground">
                    {active.category}
                  </span>
                </div>
              </div>

              <div className="p-6">
                <DialogHeader className="space-y-1 text-left">
                  <DialogTitle className="font-display text-2xl font-bold">{active.name}</DialogTitle>
                  <DialogDescription className="flex items-center gap-1.5 text-sm">
                    <Clock className="h-4 w-4 text-primary" aria-hidden />
                    {active.duration} per session
                  </DialogDescription>
                </DialogHeader>

                <p className="mt-4 text-sm leading-relaxed text-muted-foreground">{active.description}</p>

                <h4 className="mt-6 text-sm font-semibold text-foreground">What it helps with</h4>
                <ul className="mt-3 grid gap-2 sm:grid-cols-2">
                  {active.benefits.map((benefit) => (
                    <li key={benefit} className="flex items-start gap-2 text-sm text-muted-foreground">
                      <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden />
                      {benefit}
                    </li>
                  ))}
                </ul>

                <div className="mt-7 flex flex-col gap-2 sm:flex-row">
                  <Button asChild className="group flex-1 rounded-full font-semibold">
                    <Link to="/booking" onClick={() => setActive(null)}>
                      Book this therapy
                      <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" aria-hidden />
                    </Link>
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setActive(null)}
                    className="rounded-full border-border font-semibold"
                  >
                    Close
                  </Button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
};

export default TreatmentsSection;
