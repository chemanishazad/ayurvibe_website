import React from 'react';
import { Quote, Star } from 'lucide-react';
import SectionHeading from '@/components/site/SectionHeading';
import { Reveal } from '@/components/site/motion';
import { clinic, testimonials } from '@/data/site';
import { cn } from '@/lib/utils';

type Testimonial = (typeof testimonials)[number];

const ReviewCard = ({ item }: { item: Testimonial }) => (
  <figure className="mx-4 flex w-[19rem] shrink-0 flex-col rounded-2xl border border-white/12 bg-white/[0.06] p-6 backdrop-blur-sm sm:w-[23rem]">
    <div className="flex items-center gap-1" aria-label={`${item.rating} out of 5 stars`}>
      {Array.from({ length: item.rating }).map((_, i) => (
        <Star key={i} className="h-4 w-4 fill-saffron text-saffron" aria-hidden />
      ))}
    </div>
    <Quote className="mt-4 h-6 w-6 text-white/25" aria-hidden />
    <blockquote className="mt-2 flex-1 text-sm leading-relaxed text-white/85">{item.quote}</blockquote>
    <figcaption className="mt-5 border-t border-white/12 pt-4">
      <p className="text-sm font-semibold text-white">{item.name}</p>
      <p className="text-xs text-white/60">{item.condition}</p>
      <p className="mt-1 text-xs font-medium text-saffron">{item.treatment}</p>
    </figcaption>
  </figure>
);

const Row = ({ reverse = false, duration }: { reverse?: boolean; duration: string }) => (
  <div className="marquee-host edge-fade overflow-hidden">
    <div
      className={cn('marquee-row', reverse && 'marquee-reverse')}
      style={{ ['--marquee-duration' as string]: duration }}
    >
      {[...testimonials, ...testimonials].map((item, i) => (
        <ReviewCard key={`${item.name}-${i}`} item={item} />
      ))}
    </div>
  </div>
);

const TestimonialsSection = () => (
  <section
    id="testimonials"
    aria-labelledby="testimonials-heading"
    className="section-spacing relative overflow-hidden bg-gradient-earth"
  >
    <div aria-hidden className="pointer-events-none absolute inset-0 bg-grid-dark opacity-70" />

    <div className="relative">
      <div className="shell">
        <SectionHeading
          id="testimonials-heading"
          tone="dark"
          eyebrow="Patient stories"
          icon={Quote}
          title="What people say after"
          highlight="finishing treatment"
          description="Real outcomes from patients treated at our Perumbakkam hospital — collected from Google reviews and follow-up consultations."
        />

        <Reveal className="mt-8 flex justify-center">
          <div className="inline-flex items-center gap-3 rounded-full border border-white/15 bg-white/8 px-5 py-2.5 backdrop-blur">
            <span className="flex items-center gap-0.5" aria-hidden>
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} className="h-4 w-4 fill-saffron text-saffron" />
              ))}
            </span>
            <span className="text-sm font-semibold text-white">
              {clinic.ratingValue} average · {clinic.reviewCount} Google reviews
            </span>
          </div>
        </Reveal>
      </div>

      <div className="mt-12 space-y-5">
        <Row duration="58s" />
        <Row reverse duration="72s" />
      </div>
    </div>
  </section>
);

export default TestimonialsSection;
