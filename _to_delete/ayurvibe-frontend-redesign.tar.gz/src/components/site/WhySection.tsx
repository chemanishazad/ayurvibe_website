import React, { useRef } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import SectionHeading from '@/components/site/SectionHeading';
import { Reveal, StaggerGroup, StaggerItem, useParallax } from '@/components/site/motion';
import { clinic, differentiators } from '@/data/site';
import panchakarmaImg from '@/assets/panchakarma-treatment.webp';

const WhySection = () => {
  const ref = useRef<HTMLDivElement>(null);
  const y = useParallax(ref, 34);

  return (
    <section id="why" aria-labelledby="why-heading" className="section-spacing bg-background">
      <div className="shell">
        <SectionHeading
          id="why-heading"
          eyebrow="Why this hospital"
          icon={ShieldCheck}
          title="The difference between a spa and a"
          highlight="certified hospital"
          description="Ayurveda is only as good as the diagnosis behind it. Here is what that looks like in practice."
        />

        <div className="mt-14 grid items-center gap-10 lg:grid-cols-2 lg:gap-16">
          <Reveal direction="right" className="order-2 lg:order-1">
            <StaggerGroup className="space-y-3" as="ul">
              {differentiators.map((item, i) => (
                <StaggerItem key={item.title} as="li">
                  <div className="surface surface-lift flex gap-4 p-5">
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/8 font-display text-sm font-extrabold text-primary">
                      {String(i + 1).padStart(2, '0')}
                    </span>
                    <div>
                      <h3 className="text-base font-bold text-foreground">{item.title}</h3>
                      <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{item.text}</p>
                    </div>
                  </div>
                </StaggerItem>
              ))}
            </StaggerGroup>

            <Reveal delay={0.12}>
              <Button asChild variant="outline" className="group mt-7 rounded-full border-border px-6 font-semibold hover:border-primary/40 hover:text-primary">
                <Link to="/treatments">
                  See all therapies
                  <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" aria-hidden />
                </Link>
              </Button>
            </Reveal>
          </Reveal>

          <Reveal direction="left" className="order-1 lg:order-2">
            <motion.div ref={ref} style={y ? { y } : undefined} className="relative">
              <div className="overflow-hidden rounded-[1.5rem] border border-border shadow-warm">
                <img
                  src={panchakarmaImg}
                  alt="Panchakarma therapy room at Sri Vinayaga Ayurvibe, Perumbakkam, Chennai"
                  width={1400}
                  height={933}
                  loading="lazy"
                  decoding="async"
                  className="aspect-[4/3] w-full object-cover"
                />
              </div>
              <div className="absolute -bottom-6 left-5 right-5 rounded-2xl border border-border bg-background/95 px-5 py-4 shadow-warm backdrop-blur sm:left-8 sm:right-auto sm:w-64">
                <p className="text-xs font-semibold uppercase tracking-wider text-primary">Certified facility</p>
                <p className="mt-1 text-sm text-muted-foreground">
                  Registration number {clinic.regNo}, issued by the state authority.
                </p>
              </div>
            </motion.div>
          </Reveal>
        </div>
      </div>
    </section>
  );
};

export default WhySection;
