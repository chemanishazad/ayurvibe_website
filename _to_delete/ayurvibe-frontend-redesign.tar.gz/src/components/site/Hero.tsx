import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { ArrowRight, BadgeCheck, CalendarDays, Phone, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { clinic, doctor, heroImage, heroSlides, heroSrcSet, trustPoints } from '@/data/site';
import { EASE } from '@/components/site/motion';

const SLIDE_MS = 6000;

/**
 * Split hero: a stable, keyword-bearing <h1> on the left (so the page always
 * exposes one consistent heading to crawlers) and a rotating clinical gallery
 * on the right. The first frame is a preloaded, eagerly-decoded WebP — it is
 * the LCP element.
 */
const Hero = () => {
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const reduce = useReducedMotion();

  useEffect(() => {
    if (paused || reduce) return;
    const timer = window.setInterval(() => setIndex((i) => (i + 1) % heroSlides.length), SLIDE_MS);
    return () => window.clearInterval(timer);
  }, [paused, reduce]);

  const slide = heroSlides[index];

  return (
    <section
      aria-labelledby="hero-heading"
      className="relative overflow-hidden bg-background pt-28 sm:pt-32 lg:pt-36"
    >
      {/* Ambient background */}
      <div aria-hidden className="pointer-events-none absolute inset-0 bg-grid opacity-[0.55]" />
      <div
        aria-hidden
        className="pointer-events-none absolute -right-32 -top-32 h-[34rem] w-[34rem] rounded-full bg-primary/8 blur-3xl"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -left-40 top-40 h-[26rem] w-[26rem] rounded-full bg-saffron/8 blur-3xl"
      />

      <div className="shell relative grid items-center gap-12 pb-16 lg:grid-cols-[1.05fr_1fr] lg:gap-16 lg:pb-24">
        {/* ---------------------------------------------------------------- */}
        {/* Copy                                                              */}
        {/* ---------------------------------------------------------------- */}
        <div className="max-w-2xl">
          <motion.span
            initial={reduce ? false : { opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: EASE }}
            className="eyebrow"
          >
            <BadgeCheck className="h-3.5 w-3.5" aria-hidden />
            Government certified · Reg. No. {clinic.regNo}
          </motion.span>

          <motion.h1
            id="hero-heading"
            initial={reduce ? false : { opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, delay: 0.06, ease: EASE }}
            className="mt-5 font-display text-[2.35rem] font-extrabold leading-[1.06] text-foreground sm:text-5xl lg:text-[3.65rem]"
          >
            Authentic Ayurveda hospital in{' '}
            <span className="relative whitespace-nowrap text-primary">
              Chennai
              <motion.svg
                aria-hidden
                viewBox="0 0 300 12"
                preserveAspectRatio="none"
                className="absolute -bottom-1 left-0 h-2.5 w-full text-primary/35"
              >
                <motion.path
                  d="M2 8 C 80 2, 220 2, 298 7"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="4"
                  strokeLinecap="round"
                  initial={reduce ? false : { pathLength: 0 }}
                  animate={{ pathLength: 1 }}
                  transition={{ duration: 0.9, delay: 0.5, ease: EASE }}
                />
              </motion.svg>
            </span>
          </motion.h1>

          <motion.p
            initial={reduce ? false : { opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.14, ease: EASE }}
            className="mt-6 text-lg leading-relaxed text-muted-foreground sm:text-xl"
          >
            Classical Panchakarma, Abhyanga and Shirodhara at Nookampalayam, Perumbakkam — every
            plan written by {doctor.name}, {doctor.qualification}, after a full constitutional
            assessment. No packages sold before a diagnosis.
          </motion.p>

          <motion.div
            initial={reduce ? false : { opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.22, ease: EASE }}
            className="mt-8 flex flex-col gap-3 sm:flex-row"
          >
            <Button asChild size="lg" className="group h-12 rounded-full px-7 sm:h-[3.25rem] text-base font-semibold shadow-glow">
              <Link to="/booking">
                <CalendarDays className="mr-2 h-5 w-5" aria-hidden />
                Book a consultation
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" aria-hidden />
              </Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="h-12 rounded-full border-border px-7 sm:h-[3.25rem] text-base font-semibold hover:border-primary/40 hover:text-primary"
            >
              <a href={`tel:${clinic.phone}`}>
                <Phone className="mr-2 h-5 w-5 text-primary" aria-hidden />
                {clinic.phoneDisplay}
              </a>
            </Button>
          </motion.div>

          {/* Trust row */}
          <motion.ul
            initial="hidden"
            animate="show"
            variants={{ show: { transition: { staggerChildren: 0.09, delayChildren: 0.34 } } }}
            className="mt-9 grid gap-x-6 gap-y-4 border-t border-border pt-6 sm:grid-cols-3"
          >
            {trustPoints.map((point) => (
              <motion.li
                key={point.label}
                variants={{ hidden: { opacity: 0, y: 12 }, show: { opacity: 1, y: 0 } }}
                transition={{ duration: 0.5, ease: EASE }}
              >
                <p className="flex items-center gap-1.5 text-sm font-semibold text-foreground">
                  <BadgeCheck className="h-4 w-4 text-primary" aria-hidden />
                  {point.label}
                </p>
                <p className="mt-0.5 pl-[1.375rem] text-xs text-muted-foreground">{point.detail}</p>
              </motion.li>
            ))}
          </motion.ul>
        </div>

        {/* ---------------------------------------------------------------- */}
        {/* Gallery                                                           */}
        {/* ---------------------------------------------------------------- */}
        <motion.div
          initial={reduce ? false : { opacity: 0, scale: 0.97, y: 24 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.1, ease: EASE }}
          className="relative"
          onMouseEnter={() => setPaused(true)}
          onMouseLeave={() => setPaused(false)}
          onFocusCapture={() => setPaused(true)}
          onBlurCapture={() => setPaused(false)}
        >
          <div className="relative aspect-[4/5] overflow-hidden rounded-[1.75rem] border border-border bg-muted shadow-glow sm:aspect-[5/4] lg:aspect-[4/5]">
            {heroSlides.map((s, i) => (
              <img
                key={s.id}
                src={heroImage(s.id, 1100)}
                srcSet={heroSrcSet(s.id)}
                sizes="(min-width: 1024px) 44vw, 100vw"
                alt={s.alt}
                width={1100}
                height={1375}
                loading={i === 0 ? 'eager' : 'lazy'}
                // @ts-expect-error fetchpriority is a valid HTML attribute React 18 forwards as-is
                fetchpriority={i === 0 ? 'high' : undefined}
                decoding={i === 0 ? 'sync' : 'async'}
                className={cn(
                  'absolute inset-0 h-full w-full object-cover transition-opacity duration-[900ms]',
                  i === index ? 'opacity-100' : 'opacity-0',
                  i === index && !reduce && 'ken-burns-slow'
                )}
              />
            ))}

            {/* Legibility scrim */}
            <div aria-hidden className="absolute inset-0 bg-gradient-to-t from-foreground/85 via-foreground/15 to-transparent" />

            {/* Caption */}
            <div className="absolute inset-x-0 bottom-0 p-5 sm:p-7">
              <AnimatePresence mode="wait">
                <motion.div
                  key={slide.id}
                  initial={reduce ? false : { opacity: 0, y: 14 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={reduce ? undefined : { opacity: 0, y: -10 }}
                  transition={{ duration: 0.45, ease: EASE }}
                >
                  <p className="text-xs font-semibold uppercase tracking-[0.16em] text-white/70">{slide.label}</p>
                  <p className="mt-1.5 font-display text-xl font-bold text-white sm:text-2xl">{slide.heading}</p>
                  <p className="mt-1 text-sm text-white/80">{slide.caption}</p>
                </motion.div>
              </AnimatePresence>

              {/* Progress tabs */}
              <div className="mt-5 flex gap-1.5" role="tablist" aria-label="Hero gallery">
                {heroSlides.map((s, i) => (
                  <button
                    key={s.id}
                    type="button"
                    role="tab"
                    aria-selected={i === index}
                    aria-label={s.label}
                    onClick={() => setIndex(i)}
                    className="group relative h-1 flex-1 overflow-hidden rounded-full bg-white/25"
                  >
                    <span
                      className={cn(
                        'absolute inset-y-0 left-0 rounded-full bg-white transition-[width] ease-linear',
                        i === index ? 'w-full' : 'w-0 group-hover:w-1/4'
                      )}
                      style={
                        i === index && !reduce && !paused
                          ? { animation: `hero-progress ${SLIDE_MS}ms linear` }
                          : undefined
                      }
                    />
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Floating rating card */}
          <motion.figure
            initial={reduce ? false : { opacity: 0, y: 18, x: -10 }}
            animate={{ opacity: 1, y: 0, x: 0 }}
            transition={{ duration: 0.6, delay: 0.55, ease: EASE }}
            className="absolute left-4 top-1/2 hidden w-52 -translate-y-1/2 rounded-2xl border border-border bg-background/95 p-4 shadow-warm backdrop-blur sm:block lg:-left-10"
          >
            <div className="flex items-center gap-1" aria-hidden>
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} className="h-4 w-4 fill-saffron text-saffron" />
              ))}
            </div>
            <figcaption className="mt-2 text-sm font-semibold text-foreground">
              {clinic.ratingValue} out of 5
            </figcaption>
            <p className="text-xs text-muted-foreground">{clinic.reviewCount} Google reviews</p>
          </motion.figure>

          {/* Floating doctor card */}
          <motion.div
            initial={reduce ? false : { opacity: 0, y: 18, x: 10 }}
            animate={{ opacity: 1, y: 0, x: 0 }}
            transition={{ duration: 0.6, delay: 0.68, ease: EASE }}
            className="absolute -right-3 top-8 hidden max-w-[13rem] rounded-2xl border border-border bg-background/95 p-4 shadow-warm backdrop-blur lg:block xl:-right-8"
          >
            <p className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-primary">
              <span className="h-2 w-2 rounded-full bg-primary pulse-dot" aria-hidden />
              Consulting today
            </p>
            <p className="mt-2 text-sm font-semibold text-foreground">{doctor.name}</p>
            <p className="text-xs text-muted-foreground">{doctor.qualification} · {doctor.role}</p>
          </motion.div>
        </motion.div>
      </div>

      {/* Scoped keyframe for the tab progress fill */}
      <style>{`@keyframes hero-progress { from { width: 0% } to { width: 100% } }`}</style>
    </section>
  );
};

export default Hero;
