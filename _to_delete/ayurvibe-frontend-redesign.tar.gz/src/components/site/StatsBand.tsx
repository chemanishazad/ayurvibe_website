import React from 'react';
import { treatments } from '@/data/treatments';
import { stats } from '@/data/site';
import { CountUp, StaggerGroup, StaggerItem } from '@/components/site/motion';

/** Thin marquee of therapy names — a quiet way to show range without a wall of text. */
const TherapyMarquee = () => {
  const names = treatments.map((t) => t.name);
  return (
    <div className="marquee-host edge-fade overflow-hidden border-y border-border bg-secondary/60 py-3">
      <div className="marquee-row gap-8" style={{ ['--marquee-duration' as string]: '60s' }}>
        {[...names, ...names].map((name, i) => (
          <span
            key={`${name}-${i}`}
            className="flex shrink-0 items-center gap-8 text-sm font-medium tracking-tight text-muted-foreground"
          >
            {name}
            <span aria-hidden className="h-1 w-1 rounded-full bg-primary/40" />
          </span>
        ))}
      </div>
    </div>
  );
};

/** Key numbers, counted up on scroll, separated by hairlines. */
const StatsBand = () => (
  <section aria-label="Clinic at a glance" className="bg-background">
    <TherapyMarquee />
    <div className="shell py-10 sm:py-14">
      <StaggerGroup className="grid grid-cols-2 gap-y-8 lg:grid-cols-4" as="ul">
        {stats.map((stat, i) => (
          <StaggerItem
            key={stat.label}
            as="li"
            className={
              'px-4 text-center sm:px-6 lg:text-left ' +
              (i > 0 ? 'lg:border-l lg:border-border' : '')
            }
          >
            <p className="font-display text-4xl font-extrabold tracking-tight text-foreground sm:text-5xl">
              <CountUp value={stat.value} />
              {'suffix' in stat && stat.suffix ? (
                <span className="ml-0.5 text-2xl text-saffron sm:text-3xl">{stat.suffix}</span>
              ) : null}
            </p>
            <p className="mt-1.5 text-sm font-semibold text-foreground">{stat.label}</p>
            <p className="text-xs text-muted-foreground">{stat.detail}</p>
          </StaggerItem>
        ))}
      </StaggerGroup>
    </div>
  </section>
);

export default StatsBand;
