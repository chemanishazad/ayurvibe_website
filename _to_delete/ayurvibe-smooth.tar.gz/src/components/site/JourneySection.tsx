import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { ArrowRight, ClipboardList, HeartPulse, Route, Sparkles, Stethoscope } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import SectionHeading from '@/components/site/SectionHeading';
import { EASE, Reveal } from '@/components/site/motion';
import { Magnetic } from '@/components/site/scroll';
import { approachSteps, heroImage, heroSrcSet } from '@/data/site';

/** One frame per step, reusing the already-optimised hero renditions. */
const stepMedia = [
  { id: 'hospital', alt: 'Consultation room at Sri Vinayaga Ayurvibe, Perumbakkam' },
  { id: 'herbs', alt: 'Herbal formulations prepared for a personalised treatment plan' },
  { id: 'shirodhara', alt: 'Shirodhara therapy being delivered in a dedicated therapy room' },
  { id: 'panchakarma', alt: 'Follow-up review during a Panchakarma programme' },
];

const stepIcons = [Stethoscope, ClipboardList, Sparkles, HeartPulse];

/**
 * How a treatment plan is built.
 *
 * The four steps are selectable rather than scroll-driven: clicking (or
 * tabbing to) a step swaps the image. That keeps the reading order intact, puts
 * the visitor in control, and costs one state change instead of a scroll
 * subscription running every frame. All four descriptions stay in the DOM.
 */
const JourneySection = () => {
  const reduce = useReducedMotion();
  const [active, setActive] = useState(0);
  const media = stepMedia[Math.min(active, stepMedia.length - 1)];

  return (
    <section id="journey" aria-labelledby="journey-heading" className="section-spacing bg-background">
      <div className="shell">
        <SectionHeading
          id="journey-heading"
          eyebrow="The process"
          icon={Route}
          title="Four steps from first visit to"
          highlight="lasting change"
          description="Nothing is prescribed before you are assessed. Here is exactly how a treatment plan is built and followed through."
        />

        <div className="mt-14 grid items-center gap-10 lg:grid-cols-[1fr_1.05fr] lg:gap-16">
          {/* Steps */}
          <ol className="relative space-y-3">
            <span
              aria-hidden
              className="absolute left-[1.35rem] top-3 hidden h-[calc(100%-1.5rem)] w-[2px] bg-border lg:block"
            >
              <motion.span
                className="block w-full origin-top bg-primary"
                initial={false}
                animate={{ scaleY: (active + 1) / approachSteps.length }}
                transition={{ duration: 0.45, ease: EASE }}
                style={{ height: '100%' }}
              />
            </span>

            {approachSteps.map((step, i) => {
              const Icon = stepIcons[i] ?? Stethoscope;
              const isActive = i === active;
              return (
                <li key={step.step}>
                  <button
                    type="button"
                    onClick={() => setActive(i)}
                    onMouseEnter={() => setActive(i)}
                    aria-current={isActive ? 'step' : undefined}
                    className={cn(
                      'flex w-full gap-4 rounded-2xl border p-4 text-left transition-colors duration-300 lg:p-5',
                      isActive
                        ? 'border-primary/30 bg-background shadow-warm'
                        : 'border-transparent hover:border-border hover:bg-secondary/40'
                    )}
                  >
                    <span
                      className={cn(
                        'relative z-10 flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border transition-colors duration-300',
                        isActive
                          ? 'border-primary bg-primary text-primary-foreground'
                          : 'border-border bg-background text-muted-foreground'
                      )}
                    >
                      <Icon className="h-5 w-5" aria-hidden />
                    </span>
                    <span className="min-w-0">
                      <span className="font-display text-xs font-extrabold tracking-[0.2em] text-primary">
                        {step.step}
                      </span>
                      <h3 className="mt-0.5 font-display text-lg font-bold text-foreground lg:text-xl">
                        {step.title}
                      </h3>
                      <span className="mt-1.5 block text-sm leading-relaxed text-muted-foreground">
                        {step.text}
                      </span>
                    </span>
                  </button>
                </li>
              );
            })}

            <li className="pt-2 lg:pl-5">
              <Magnetic>
                <Button asChild className="group rounded-full px-6 font-semibold">
                  <Link to="/booking">
                    Start at step one
                    <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" aria-hidden />
                  </Link>
                </Button>
              </Magnetic>
            </li>
          </ol>

          {/* Media */}
          <Reveal direction="left" className="hidden lg:block">
            <div className="relative aspect-[4/3] overflow-hidden rounded-[1.75rem] border border-border bg-muted shadow-glow">
              <AnimatePresence mode="sync">
                <motion.img
                  key={media.id}
                  src={heroImage(media.id, 1100)}
                  srcSet={heroSrcSet(media.id)}
                  sizes="(min-width: 1024px) 46vw, 100vw"
                  alt={media.alt}
                  width={1100}
                  height={825}
                  loading="lazy"
                  decoding="async"
                  initial={reduce ? false : { opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={reduce ? undefined : { opacity: 0 }}
                  transition={{ duration: 0.55, ease: EASE }}
                  className="absolute inset-0 h-full w-full object-cover"
                />
              </AnimatePresence>
              <span
                aria-hidden
                className="absolute inset-0 bg-gradient-to-t from-foreground/70 via-transparent to-transparent"
              />

              <div className="absolute bottom-5 left-5 right-5 flex items-end justify-between gap-4">
                <p className="font-display text-5xl font-extrabold leading-none tabular text-white/90">
                  {String(active + 1).padStart(2, '0')}
                  <span className="text-2xl text-white/50">/{String(approachSteps.length).padStart(2, '0')}</span>
                </p>
                <div className="flex gap-1.5 pb-2">
                  {approachSteps.map((step, i) => (
                    <button
                      key={step.step}
                      type="button"
                      onClick={() => setActive(i)}
                      aria-label={`Step ${i + 1}: ${step.title}`}
                      className={cn(
                        'h-1 rounded-full transition-all duration-400',
                        i === active ? 'w-8 bg-white' : 'w-2 bg-white/40 hover:bg-white/70'
                      )}
                    />
                  ))}
                </div>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
};

export default JourneySection;
