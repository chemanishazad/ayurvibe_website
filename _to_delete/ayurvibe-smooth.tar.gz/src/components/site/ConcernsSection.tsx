import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Activity,
  ArrowRight,
  Bone,
  Brain,
  Check,
  Flower2,
  HeartPulse,
  Sparkles,
  Stethoscope,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import SectionHeading from '@/components/site/SectionHeading';
import { StaggerGroup, StaggerItem } from '@/components/site/motion';
import { treatments } from '@/data/treatments';

interface Concern {
  id: string;
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  summary: string;
  conditions: string[];
  /** Treatment slugs, resolved against src/data/treatments.ts */
  therapies: string[];
}

const concerns: Concern[] = [
  {
    id: 'mind',
    icon: Brain,
    title: 'Stress, sleep & mind',
    summary: 'Therapies that work directly on the nervous system — for people who cannot switch off.',
    conditions: ['Anxiety', 'Insomnia', 'Migraine', 'Burnout', 'Low mood'],
    therapies: ['shirodhara', 'takra-dhara', 'thalapothichil', 'shiro-abhyangam'],
  },
  {
    id: 'joints',
    icon: Bone,
    title: 'Joints, spine & muscle',
    summary: 'Warm, localised treatments for pain, stiffness and restricted movement.',
    conditions: ['Back pain', 'Cervical pain', 'Knee pain', 'Arthritis', 'Sciatica'],
    therapies: ['kati-vasti', 'greeva-vasti', 'jaanu-vasti', 'elakizhi', 'pizhichil'],
  },
  {
    id: 'digestion',
    icon: Activity,
    title: 'Digestion & metabolism',
    summary: 'Restoring digestive fire first — most chronic complaints start here.',
    conditions: ['IBS', 'Acidity', 'Bloating', 'Weight gain', 'Thyroid imbalance'],
    therapies: ['udwarthanam', 'podi-kizhi', 'matra-vasti', 'kashaya-vasti'],
  },
  {
    id: 'womens-health',
    icon: Flower2,
    title: "Women's health",
    summary: 'Cycle, fertility and postnatal care handled by a women’s-health specialist.',
    conditions: ['PCOS', 'Irregular cycles', 'Menstrual pain', 'Postnatal recovery'],
    therapies: ['yoni-prakshalanam', 'prishta-vasti', 'shareera-abhyangam', 'navara-kizhi'],
  },
  {
    id: 'skin-hair',
    icon: Sparkles,
    title: 'Skin, hair & face',
    summary: 'Classical external therapies for the skin barrier, scalp and facial nerves.',
    conditions: ['Hair fall', 'Dandruff', 'Dull skin', 'Pigmentation', 'Facial palsy'],
    therapies: ['navara-mukha-lepam', 'mukha-abhyangam', 'shiro-pichu', 'ksheera-dhoomam'],
  },
  {
    id: 'vitality',
    icon: HeartPulse,
    title: 'Detox & vitality',
    summary: 'Supervised Panchakarma and rejuvenation for long-running fatigue and chronic illness.',
    conditions: ['Chronic fatigue', 'Low immunity', 'Post-illness recovery', 'Toxin build-up'],
    therapies: ['dhanyamla-dhara', 'valuka-swedanam', 'baspa-sweda', 'ksheera-dhara'],
  },
];

const therapiesFor = (concern: Concern) =>
  concern.therapies.map((slug) => treatments.find((t) => t.slug === slug)).filter(Boolean);

const ConcernsSection = () => {
  const [active, setActive] = useState<Concern | null>(null);

  return (
    <section id="body-map" aria-labelledby="concerns-heading" className="section-spacing bg-background">
      <div className="shell">
        <SectionHeading
          id="concerns-heading"
          eyebrow="Find your therapy"
          icon={Stethoscope}
          title="Start from the problem, not the"
          highlight="price list"
          description="Pick what you are dealing with and see which classical therapies are indicated — then we confirm the right one in consultation."
        />

        <StaggerGroup className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3" as="ul">
          {concerns.map((concern) => (
            <StaggerItem key={concern.id} as="li" className="h-full">
              <button
                type="button"
                onClick={() => setActive(concern)}
                className="surface card-hover group flex h-full w-full flex-col p-6 text-left"
                aria-label={`See therapies for ${concern.title}`}
              >
                <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/8 text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                  <concern.icon className="h-6 w-6" aria-hidden />
                </span>

                <h3 className="mt-4 font-display text-lg font-bold text-foreground">{concern.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{concern.summary}</p>

                <ul className="mt-4 flex flex-wrap gap-1.5">
                  {concern.conditions.slice(0, 4).map((condition) => (
                    <li
                      key={condition}
                      className="rounded-full border border-border px-2.5 py-1 text-xs text-muted-foreground"
                    >
                      {condition}
                    </li>
                  ))}
                </ul>

                <span className="mt-5 inline-flex items-center gap-1.5 text-sm font-semibold text-primary">
                  {therapiesFor(concern).length} matching therapies
                  <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" aria-hidden />
                </span>
              </button>
            </StaggerItem>
          ))}
        </StaggerGroup>
      </div>

      <Dialog open={!!active} onOpenChange={(open) => !open && setActive(null)}>
        <DialogContent className="max-h-[88vh] max-w-2xl overflow-y-auto rounded-2xl">
          {active && (
            <>
              <DialogHeader className="text-left">
                <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/8 text-primary">
                  <active.icon className="h-6 w-6" aria-hidden />
                </span>
                <DialogTitle className="mt-3 font-display text-2xl font-bold">{active.title}</DialogTitle>
                <DialogDescription className="text-sm">{active.summary}</DialogDescription>
              </DialogHeader>

              <div>
                <h4 className="text-sm font-semibold text-foreground">Commonly treated</h4>
                <ul className="mt-2 flex flex-wrap gap-1.5">
                  {active.conditions.map((condition) => (
                    <li
                      key={condition}
                      className="rounded-full bg-secondary px-3 py-1 text-xs font-medium text-foreground"
                    >
                      {condition}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="mt-5">
                <h4 className="text-sm font-semibold text-foreground">Therapies usually indicated</h4>
                <ul className="mt-3 space-y-3">
                  {therapiesFor(active).map((therapy) => (
                    <li key={therapy!.slug} className="flex gap-3 rounded-xl border border-border p-3">
                      <img
                        src={therapy!.thumb}
                        alt={`${therapy!.name} therapy`}
                        width={480}
                        height={360}
                        loading="lazy"
                        decoding="async"
                        className="h-16 w-20 shrink-0 rounded-lg object-cover"
                      />
                      <div>
                        <p className="text-sm font-semibold text-foreground">{therapy!.name}</p>
                        <p className="mt-0.5 line-clamp-2 text-xs leading-relaxed text-muted-foreground">
                          {therapy!.description}
                        </p>
                        <p className="mt-1 flex items-center gap-1 text-xs text-primary">
                          <Check className="h-3 w-3" aria-hidden />
                          {therapy!.duration}
                        </p>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>

              <p className="mt-4 rounded-xl bg-secondary p-3 text-xs leading-relaxed text-muted-foreground">
                This is a guide, not a prescription. The final plan is decided after a clinical
                assessment with the doctor.
              </p>

              <Button asChild className="group mt-2 w-full rounded-full font-semibold">
                <Link to="/booking" onClick={() => setActive(null)}>
                  Book a consultation
                  <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" aria-hidden />
                </Link>
              </Button>
            </>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
};

export default ConcernsSection;
