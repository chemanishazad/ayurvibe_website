import React, { useState } from 'react';
import { Compass, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import SectionHeading from '@/components/site/SectionHeading';
import { Reveal, StaggerGroup, StaggerItem } from '@/components/site/motion';
import { Magnetic } from '@/components/site/scroll';
import { doshas } from '@/data/site';
import DoshaQuiz from '@/components/DoshaQuiz';

type Dosha = (typeof doshas)[number];

const DoshaCard = ({ dosha, active = true }: { dosha: Dosha; active?: boolean }) => (
  <article
    className={cn(
      'surface flex h-full w-full flex-col overflow-hidden transition-[opacity,box-shadow] duration-500',
      active ? 'opacity-100 shadow-warm' : 'opacity-55'
    )}
  >
    <div className={`bg-gradient-to-br ${dosha.accent} p-6`}>
      <span className="font-display text-5xl font-extrabold text-foreground/85">{dosha.name[0]}</span>
      <h3 className="mt-2 font-display text-2xl font-bold text-foreground">{dosha.name}</h3>
      <p className="text-sm font-medium text-foreground/70">{dosha.element}</p>
    </div>

    <div className="flex flex-1 flex-col p-6">
      <p className="text-sm leading-relaxed text-muted-foreground">{dosha.summary}</p>

      <h4 className="mt-5 text-xs font-semibold uppercase tracking-wider text-foreground">Typical traits</h4>
      <ul className="mt-2 flex flex-wrap gap-1.5">
        {dosha.traits.map((trait) => (
          <li key={trait} className="rounded-full border border-border px-2.5 py-1 text-xs text-muted-foreground">
            {trait}
          </li>
        ))}
      </ul>

      <h4 className="mt-5 text-xs font-semibold uppercase tracking-wider text-foreground">
        What keeps it balanced
      </h4>
      <ul className="mt-2 space-y-1">
        {dosha.lifestyle.slice(0, 4).map((tip) => (
          <li key={tip} className="flex items-start gap-2 text-xs text-muted-foreground">
            <span aria-hidden className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-primary" />
            {tip}
          </li>
        ))}
      </ul>
    </div>
  </article>
);

/**
 * The three constitutions, side by side.
 *
 * Plain cards with a CSS hover lift. All three sets of traits and lifestyle
 * guidance are in the markup at once — good for reading, good for indexing, and
 * nothing to animate while the visitor scrolls past.
 */
const DoshaSection = () => {
  const [quizOpen, setQuizOpen] = useState(false);

  return (
    <section id="dosha" aria-labelledby="dosha-heading" className="section-spacing overflow-hidden bg-secondary/40">
      <div className="shell">
        <SectionHeading
          id="dosha-heading"
          eyebrow="Know yourself"
          icon={Compass}
          title="Three constitutions, one"
          highlight="that's yours"
          description="Vata, Pitta and Kapha describe how your body runs — how you digest, sleep, react to stress and fall ill. Knowing yours is where a personalised plan starts."
        />

        <StaggerGroup className="mt-12 grid gap-5 md:grid-cols-3" as="ul">
          {doshas.map((dosha) => (
            <StaggerItem key={dosha.name} as="li" className="h-full">
              <DoshaCard dosha={dosha} />
            </StaggerItem>
          ))}
        </StaggerGroup>

        <Reveal className="mt-14 flex flex-col items-center text-center">
          <Magnetic>
            <Button
              size="lg"
              onClick={() => setQuizOpen(true)}
              className="rounded-full px-8 py-6 text-base font-semibold shadow-glow"
            >
              <Sparkles className="mr-2 h-5 w-5" aria-hidden />
              Take the 5-minute dosha quiz
            </Button>
          </Magnetic>
          <p className="mt-3 text-sm text-muted-foreground">
            Free, no sign-up. The result is an indication — the clinical assessment happens in consultation.
          </p>
        </Reveal>
      </div>

      <DoshaQuiz isOpen={quizOpen} onClose={() => setQuizOpen(false)} />
    </section>
  );
};

export default DoshaSection;
