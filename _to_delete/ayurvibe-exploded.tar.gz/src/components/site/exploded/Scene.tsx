import React, { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { motion, useMotionValue, useTransform, type MotionValue } from 'framer-motion';
import { ArrowUpRight, FlaskConical } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Mark } from '@/components/site/exploded/Marks';
import { Figure } from '@/components/site/exploded/Figures';
import type { SceneData, Satellite, Tint } from '@/components/site/exploded/types';

/* ---------------------------------------------------------------------------
 * One exploded scene: label on the left, figure on the right
 * ---------------------------------------------------------------------------
 * The figure comes apart and its satellites lift out of it and take labelled
 * places around it. Everything is driven by a single `progress` value, and
 * every animated property is transform or opacity.
 *
 * Two things worth knowing before editing:
 *
 * · Satellites are laid out at their final seat and *pulled back* toward the
 *   centre. An earlier version scaled the whole ring and counter-scaled each
 *   medallion — no measurement needed — but scaling a box of live text forces
 *   a full re-rasterise every frame, and it was the single biggest frame cost
 *   on the page. Translating promoted layers is pure compositing.
 *
 * · Colours come from `--rx-*` on `.exploded-light` / `.exploded-dark` (see
 *   site-theme.css). Tailwind silently drops the `/60` alpha modifier when it
 *   is applied to an arbitrary `hsl(...)` value, so every translucent colour
 *   here carries its own alpha inside the value.
 * ------------------------------------------------------------------------- */

/** Where satellites settle, as a percentage of the stage's half-size. */
export const RING_X = 38;
export const RING_Y = 36;

const TINT_VAR: Record<Tint, string> = {
  leaf: '--rx-leaf',
  amber: '--rx-amber',
  clay: '--rx-clay',
  stone: '--rx-stone',
};

/**
 * Satellites are dealt alternately right and left of the figure and spread
 * across a ±52° arc on each side — never straight above or below it. A ring
 * that runs the full 360° puts one exactly where the lid travels, and every
 * figure here is taller than it is wide.
 */
export const angleFor = (index: number, count: number) => {
  const right = Math.ceil(count / 2);
  const left = count - right;
  const onRight = index % 2 === 0;
  const seat = Math.floor(index / 2);
  const seats = onRight ? right : left;
  const spread = seats === 1 ? 0 : -52 + (104 * seat) / (seats - 1);
  return (onRight ? spread : 180 - spread) * (Math.PI / 180);
};

const Medallion = React.memo(
  ({
    satellite,
    index,
    count,
    travel,
    size,
    still,
  }: {
    satellite: Satellite;
    index: number;
    count: number;
    /** 0 = inside the figure, 1 = settled in its seat. */
    travel: MotionValue<number>;
    /** Live width of the square stage, in px. */
    size: MotionValue<number>;
    still: boolean;
  }) => {
    const angle = angleFor(index, count);
    const left = 50 + RING_X * Math.cos(angle);
    const top = 50 + RING_Y * Math.sin(angle);
    /** Satellites above the figure caption upward, so nothing crosses the middle. */
    const above = Math.sin(angle) < -0.3;

    const from = 0.16 + index * 0.04;
    const eased = useTransform(travel, [from, from + 0.46], [0, 1]);
    const opacity = useTransform(eased, [0, 0.35], [0, 1]);

    const dx = (RING_X / 100) * Math.cos(angle);
    const dy = (RING_Y / 100) * Math.sin(angle);
    const x = useTransform([eased, size] as const, ([e, s]: number[]) => -(1 - e) * dx * s);
    const y = useTransform([eased, size] as const, ([e, s]: number[]) => -(1 - e) * dy * s);

    const tint = `var(${TINT_VAR[satellite.tint]})`;

    return (
      <li
        className="absolute w-[5.5rem] sm:w-[6.5rem]"
        style={{ left: `${left}%`, top: `${top}%`, transform: 'translate(-50%, -50%)' }}
      >
        <motion.div
          className={cn('group flex items-center', above ? 'flex-col-reverse' : 'flex-col')}
          style={still ? undefined : { x, y, opacity, willChange: 'transform' }}
        >
          <span
            className="grid h-14 w-14 place-items-center rounded-full border sm:h-[4.25rem] sm:w-[4.25rem]"
            style={{
              borderColor: `hsl(${tint} / 0.4)`,
              background: `hsl(${tint} / 0.1)`,
              ['--rx-fill' as string]: `hsl(${tint} / 0.26)`,
              color: `hsl(${tint})`,
            }}
          >
            <Mark id={satellite.mark} className="h-8 w-8 sm:h-9 sm:w-9" />
          </span>

          <span className={cn('flex flex-col items-center', above ? 'mb-2' : 'mt-2')}>
            <span className="text-center text-[0.68rem] font-semibold uppercase leading-tight tracking-[0.1em] text-[hsl(var(--rx-ink)/0.95)] sm:text-[0.72rem]">
              {satellite.name}
            </span>
            {satellite.sub && (
              <span className="text-center font-display text-[0.63rem] italic leading-tight text-[hsl(var(--rx-ink)/0.5)]">
                {satellite.sub}
              </span>
            )}
            <span className="mt-1 hidden w-[7.5rem] text-center text-[0.63rem] leading-snug text-[hsl(var(--rx-ink)/0.42)] transition-colors duration-300 group-hover:text-[hsl(var(--rx-gold)/0.9)] sm:block">
              {satellite.note}
            </span>
          </span>
        </motion.div>
      </li>
    );
  }
);
Medallion.displayName = 'Medallion';

/** The figure and its satellites. Exported so a section can use it on its own. */
export const ExplodedFigure = ({
  scene,
  progress,
  still,
}: {
  scene: SceneData;
  /** 0 = sealed, 1 = fully open and settled. */
  progress: MotionValue<number>;
  still: boolean;
}) => {
  const open = useTransform(progress, [0.1, 0.58], [0, 1]);
  const figureScale = useTransform(progress, [0.06, 0.5], [0.88, 1]);
  const glow = useTransform(progress, [0.1, 0.7], [0, 1]);
  /** Connector lines grow with the satellites; no per-item stagger needed. */
  const spokes = useTransform(progress, [0.16, 0.8], [0.05, 1]);

  // Satellites need the stage's pixel width to turn a polar seat into a
  // translation. One observer per scene, firing only on resize.
  const stageRef = useRef<HTMLDivElement>(null);
  const size = useMotionValue(0);
  useEffect(() => {
    const el = stageRef.current;
    if (!el) return;
    size.set(el.clientWidth);
    const observer = new ResizeObserver(([entry]) => size.set(entry.contentRect.width));
    observer.observe(el);
    return () => observer.disconnect();
  }, [size]);

  return (
    <div
      ref={stageRef}
      className="relative aspect-square w-[min(88vw,27rem)] lg:w-[min(46vw,34rem)]"
      style={{ ['--rx-fluid' as string]: `hsl(${scene.accent} / 0.62)` }}
    >
      <span aria-hidden className="absolute inset-[7%] rounded-full border border-dashed border-[hsl(var(--rx-ink)/0.12)]" />

      <motion.span
        aria-hidden
        className="absolute inset-[18%] rounded-full"
        style={{
          background: `radial-gradient(circle, hsl(${scene.accent} / 0.3), transparent 68%)`,
          ...(still ? {} : { opacity: glow }),
        }}
      />

      <motion.div
        className="absolute inset-0 grid place-items-center"
        style={still ? undefined : { scale: figureScale, willChange: 'transform' }}
      >
        <Figure id={scene.figure} open={open} className="h-[54%] w-auto text-[hsl(var(--rx-ink)/0.88)]" />
      </motion.div>

      <ul className="absolute inset-0 list-none">
        <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="absolute inset-0 h-full w-full" aria-hidden>
          <motion.g
            style={still ? undefined : { scale: spokes, transformBox: 'fill-box', transformOrigin: 'center' }}
          >
            {scene.satellites.map((satellite, i) => {
              const a = angleFor(i, scene.satellites.length);
              return (
                <line
                  key={satellite.name}
                  x1="50"
                  y1="50"
                  x2={50 + RING_X * Math.cos(a)}
                  y2={50 + RING_Y * Math.sin(a)}
                  stroke="hsl(var(--rx-ink) / 0.16)"
                  strokeWidth={1}
                  vectorEffect="non-scaling-stroke"
                />
              );
            })}
          </motion.g>
        </svg>

        {scene.satellites.map((satellite, i) => (
          <Medallion
            key={satellite.name}
            satellite={satellite}
            index={i}
            count={scene.satellites.length}
            travel={progress}
            size={size}
            still={still}
          />
        ))}
      </ul>
    </div>
  );
};

/** Label on the left, figure on the right. */
export const ExplodedScene = React.memo(
  ({
    scene,
    index,
    progress,
    still,
    fade,
  }: {
    scene: SceneData;
    /** Shown as the outlined numeral; pass -1 to hide it. */
    index: number;
    /** Local progress for this scene, 0 → 1. */
    progress: MotionValue<number>;
    still: boolean;
    /** Cross-fade of the whole scene, when several share one stage. */
    fade?: { opacity: MotionValue<number>; y: MotionValue<number>; pointerEvents: MotionValue<string> };
  }) => (
    <motion.article
      className={cn(
        'grid w-full items-center gap-8 lg:grid-cols-[minmax(0,0.78fr)_minmax(0,1.12fr)] lg:gap-10',
        fade && 'absolute inset-0 content-center'
      )}
      style={fade ? { opacity: fade.opacity, y: fade.y, pointerEvents: fade.pointerEvents } : undefined}
    >
      <div className="order-2 text-center lg:order-1 lg:text-left">
        <p className="flex items-center justify-center gap-3 lg:justify-start">
          {index >= 0 && (
            <span className="rx-numeral font-display text-[2.6rem] font-extrabold leading-none">
              {String(index + 1).padStart(2, '0')}
            </span>
          )}
          <span className="h-px w-9 bg-[hsl(var(--rx-ink)/0.22)]" aria-hidden />
          <span className="text-[0.66rem] font-semibold uppercase tracking-[0.22em] text-[hsl(var(--rx-gold))]">
            {scene.kicker}
          </span>
        </p>

        <h3 className="mt-3 font-display text-[1.7rem] font-extrabold leading-[1.1] text-[hsl(var(--rx-ink))] sm:text-[2.3rem]">
          {scene.title}
        </h3>

        <p className="mt-2 font-display text-base italic text-[hsl(var(--rx-gold)/0.9)] sm:text-lg">
          {scene.tagline}
        </p>

        <p className="mx-auto mt-4 hidden max-w-xl text-sm leading-relaxed text-[hsl(var(--rx-ink)/0.66)] sm:block lg:mx-0">
          {scene.body}
        </p>

        <p className="mt-4 flex items-start justify-center gap-2 text-xs leading-relaxed text-[hsl(var(--rx-ink)/0.5)] lg:justify-start">
          <FlaskConical className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[hsl(var(--rx-gold)/0.8)]" aria-hidden />
          <span>
            {scene.footnote}
            {scene.footnoteSource && (
              <span className="font-display italic text-[hsl(var(--rx-ink)/0.38)]"> — {scene.footnoteSource}</span>
            )}
          </span>
        </p>

        {scene.links && scene.links.length > 0 && (
          <div className="mt-6 flex flex-wrap justify-center gap-2 lg:justify-start">
            <span className="sr-only">Related therapies:</span>
            {scene.links.map((link) => (
              <Link
                key={link.slug}
                to={`/treatments#therapy-${link.slug}`}
                className="group inline-flex items-center gap-1 rounded-full border border-[hsl(var(--rx-ink)/0.16)] px-3 py-1.5 text-[0.72rem] font-semibold text-[hsl(var(--rx-ink)/0.78)] transition-colors hover:border-[hsl(var(--rx-gold)/0.5)] hover:text-[hsl(var(--rx-gold))]"
              >
                {link.name}
                <ArrowUpRight className="h-3 w-3 opacity-60 transition-transform group-hover:translate-x-0.5" aria-hidden />
              </Link>
            ))}
          </div>
        )}
      </div>

      <div className="order-1 flex justify-center lg:order-2">
        <ExplodedFigure scene={scene} progress={progress} still={still} />
      </div>
    </motion.article>
  )
);
ExplodedScene.displayName = 'ExplodedScene';
