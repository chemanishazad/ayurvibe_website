import React from 'react';
import {
  Activity, Anchor, Baby, BatteryLow, Bed, Bone, CalendarDays, CheckCheck, ClipboardList,
  Clock, Cloud, CloudRain, Compass, DoorClosed, Droplet, Droplets, Eye, Feather, Flame,
  Footprints, Gauge, Hourglass, ListChecks, Mountain, Moon, Pill, Repeat, Scale, Settings2,
  Shield, Snowflake, Sprout, Stethoscope, Sun, Sunrise, Syringe, Target, Thermometer,
  TrendingUp, UtensilsCrossed, Users, Waves, Wind, Zap, type LucideIcon,
} from 'lucide-react';
import { Botanical } from '@/components/site/apothecary/Botanicals';
import type { LucideMarkId, MarkId } from '@/components/site/exploded/types';

/* ---------------------------------------------------------------------------
 * Medallion marks
 * ---------------------------------------------------------------------------
 * Two sources, deliberately.
 *
 * The botanicals are hand-drawn (apothecary/Botanicals.tsx) because they are
 * the distinctive thing on the page — no stock photograph of turmeric, and no
 * icon set has a Haritaki. Everything else is conceptual (a moon, a spine, a
 * clock) and comes from the icon set already in the bundle: same 1.5–2 weight,
 * same round caps, so a ring mixing the two still reads as one drawing.
 * ------------------------------------------------------------------------- */

const LUCIDE: Record<LucideMarkId, LucideIcon> = {
  wind: Wind, waves: Waves, syringe: Syringe, droplets: Droplets, droplet: Droplet,
  feather: Feather, snowflake: Snowflake, moon: Moon, flame: Flame, sun: Sun, target: Target,
  thermometer: Thermometer, spark: Zap, anchor: Anchor, hourglass: Hourglass, bed: Bed,
  mountain: Mountain, cloud: Cloud, pulse: Activity, eye: Eye, clipboard: ClipboardList,
  compass: Compass, checklist: ListChecks, pill: Pill, plate: UtensilsCrossed,
  calendar: CalendarDays, clock: Clock, door: DoorClosed, people: Users,
  stethoscope: Stethoscope, trend: TrendingUp, sliders: Settings2, sunrise: Sunrise,
  battery: BatteryLow, rain: CloudRain, bone: Bone, activity: CheckCheck, foot: Footprints,
  scale: Scale, gauge: Gauge, ring: Repeat, repeat: Repeat, baby: Baby, shoot: Sprout,
  shield: Shield,
};

const isLucide = (id: MarkId): id is LucideMarkId => id in LUCIDE;

/** One mark, tinted by the medallion around it. */
export const Mark = ({ id, className }: { id: MarkId; className?: string }) => {
  if (isLucide(id)) {
    const Icon = LUCIDE[id];
    return <Icon className={className} strokeWidth={1.5} aria-hidden />;
  }
  return <Botanical id={id} className={className} />;
};

export default Mark;
