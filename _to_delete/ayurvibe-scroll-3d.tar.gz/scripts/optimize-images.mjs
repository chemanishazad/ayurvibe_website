#!/usr/bin/env node
/**
 * Image optimiser for the public site.
 *
 * The design masters (PNG/JPG exports) are huge — 2 MB+ each — which is fine as
 * source material but catastrophic for Core Web Vitals. This script derives the
 * WebP renditions the site actually ships:
 *
 *   src/assets/treatments/<slug>.png  ->  src/assets/treatments/<slug>.webp   (900w)
 *   src/assets/<hero source>          ->  public/hero/<id>-{700,1100,1800}.webp
 *   src/assets/<inline image>         ->  src/assets/<name>.webp
 *
 * Hero frames live in /public with stable filenames so index.html can preload
 * the LCP image before the JS bundle parses.
 *
 * Usage:  npm run images        (requires the optional `sharp` devDependency)
 */
import { readdirSync, existsSync, mkdirSync, statSync } from 'fs';
import { dirname, join, basename, extname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT = dirname(__dirname);

let sharp;
try {
  ({ default: sharp } = await import('sharp'));
} catch {
  console.error(
    '[images] `sharp` is not installed.\n' +
      '         Run `npm install` (it is listed as a devDependency) and try again.'
  );
  process.exit(1);
}

const TREATMENTS_DIR = join(ROOT, 'src/assets/treatments');
const ASSETS_DIR = join(ROOT, 'src/assets');
const HERO_OUT = join(ROOT, 'public/hero');

/** id -> source file, used for the hero gallery in src/data/site.ts */
const HERO_SOURCES = {
  hospital: 'hospital-exterior.jpg',
  panchakarma: 'panchakarma-treatment.png',
  shirodhara: 'shirodhara-therapy.png',
  abhyanga: 'abhyanga-massage.png',
  herbs: 'ayurvedic-herbs.jpg',
};

const HERO_WIDTHS = [700, 1100, 1800];

/** Inline imagery imported directly by components. */
const INLINE = [
  { src: 'dr-vaitheeshwari.jpg', out: 'dr-vaitheeshwari.webp', width: 760, quality: 80 },
  { src: 'hospital-exterior.jpg', out: 'hospital-exterior.webp', width: 1400, quality: 76 },
  { src: 'ayurvedic-herbs.jpg', out: 'ayurvedic-herbs.webp', width: 1200, quality: 78 },
  { src: 'panchakarma-treatment.png', out: 'panchakarma-treatment.webp', width: 1400, quality: 74 },
];

let written = 0;
let bytesIn = 0;
let bytesOut = 0;

const convert = async (src, dst, width, quality) => {
  if (!existsSync(src)) {
    console.warn(`[images] missing source, skipped: ${basename(src)}`);
    return;
  }
  mkdirSync(dirname(dst), { recursive: true });
  await sharp(src).resize({ width, withoutEnlargement: true }).webp({ quality, effort: 6 }).toFile(dst);
  bytesIn += statSync(src).size;
  bytesOut += statSync(dst).size;
  written++;
};

// 1. Treatment cards
const masters = existsSync(TREATMENTS_DIR)
  ? readdirSync(TREATMENTS_DIR).filter((f) => /\.(png|jpe?g)$/i.test(f))
  : [];
for (const file of masters) {
  const slug = basename(file, extname(file));
  await convert(join(TREATMENTS_DIR, file), join(TREATMENTS_DIR, `${slug}.webp`), 900, 74);
}

// 2. Hero gallery
for (const [id, file] of Object.entries(HERO_SOURCES)) {
  for (const width of HERO_WIDTHS) {
    await convert(join(ASSETS_DIR, file), join(HERO_OUT, `${id}-${width}.webp`), width, width > 900 ? 72 : 70);
  }
}

// 3. Inline imagery
for (const item of INLINE) {
  await convert(join(ASSETS_DIR, item.src), join(ASSETS_DIR, item.out), item.width, item.quality);
}

const mb = (n) => (n / 1e6).toFixed(2);
console.log(`[images] wrote ${written} WebP files — ${mb(bytesIn)} MB of sources -> ${mb(bytesOut)} MB shipped.`);
