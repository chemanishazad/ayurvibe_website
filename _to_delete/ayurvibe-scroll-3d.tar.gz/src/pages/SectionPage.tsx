import { useEffect } from 'react';
import Index from './Index';

interface SectionPageProps {
  /** id of the section on the landing page to scroll to. */
  sectionId: string;
  title: string;
  description?: string;
  canonical?: string;
  /** Label used in the BreadcrumbList entry for this route. */
  breadcrumbName?: string;
  path?: string;
}

/**
 * Readable deep-links (/about, /treatments, …) render the landing page and
 * scroll to the matching section. The route's own title/description/canonical
 * are handed to <Index> so exactly one <SEO> runs — otherwise the landing
 * page's canonical would overwrite the section's.
 */
const SectionPage = ({
  sectionId,
  title,
  description,
  canonical,
  breadcrumbName,
  path,
}: SectionPageProps) => {
  useEffect(() => {
    const scroll = () => {
      const el = document.getElementById(sectionId);
      if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    };
    // Small delay so layout and fonts settle before we jump.
    const timer = window.setTimeout(scroll, 150);
    return () => window.clearTimeout(timer);
  }, [sectionId]);

  return (
    <Index
      title={title}
      description={description}
      canonical={canonical}
      breadcrumb={breadcrumbName && path ? { name: breadcrumbName, path } : undefined}
    />
  );
};

export default SectionPage;
