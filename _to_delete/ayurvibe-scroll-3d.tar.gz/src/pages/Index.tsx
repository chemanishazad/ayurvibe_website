import React, { useMemo } from 'react';
import SEO from '@/components/SEO';
import SmoothScroll from '@/components/SmoothScroll';
import BackToTop from '@/components/BackToTop';
import ProgressiveWebApp from '@/components/ProgressiveWebApp';
import LiveChat from '@/components/LiveChat';

import SiteHeader from '@/components/site/SiteHeader';
import Hero from '@/components/site/Hero';
import StatsBand from '@/components/site/StatsBand';
import AboutSection from '@/components/site/AboutSection';
import JourneySection from '@/components/site/JourneySection';
import TreatmentsSection from '@/components/site/TreatmentsSection';
import ConcernsSection from '@/components/site/ConcernsSection';
import DoctorSection from '@/components/site/DoctorSection';
import TestimonialsSection from '@/components/site/TestimonialsSection';
import WhySection from '@/components/site/WhySection';
import DoshaSection from '@/components/site/DoshaSection';
import FaqSection from '@/components/site/FaqSection';
import BookingSection from '@/components/site/BookingSection';
import SiteFooter from '@/components/site/SiteFooter';
import MobileCtaBar from '@/components/site/MobileCtaBar';
import { IntroCurtain, MagneticCursor, RouteTransition, ScrollRail } from '@/components/site/Chrome';
import { SmoothScrollProvider } from '@/components/site/scroll';
import { useSiteTheme } from '@/components/site/motion';

import { clinic, doctor, faqs, testimonials } from '@/data/site';
import { treatments } from '@/data/treatments';

/** Sections surfaced by the right-hand scroll rail. */
const RAIL_SECTIONS = [
  { id: 'hero-section', label: 'Top' },
  { id: 'about', label: 'The clinic' },
  { id: 'journey', label: 'How it works' },
  { id: 'treatments', label: 'Therapies' },
  { id: 'body-map', label: 'Your concern' },
  { id: 'doctors', label: 'Your doctor' },
  { id: 'testimonials', label: 'Stories' },
  { id: 'why', label: 'Why us' },
  { id: 'dosha', label: 'Dosha' },
  { id: 'faq', label: 'Questions' },
  { id: 'booking', label: 'Book' },
];

const LOCATIONS = [
  'Perumbakkam', 'Nookampalayam', 'Sholinganallur', 'OMR', 'Pallikaranai', 'Navalur',
  'Kelambakkam', 'Tambaram', 'Medavakkam', 'Velachery', 'Chromepet', 'Thoraipakkam',
  'Thiruvanmiyur', 'Adyar', 'Guindy', 'Chennai',
];

export interface IndexSeoProps {
  /** Route-specific <title>. Defaults to the landing-page title. */
  title?: string;
  description?: string;
  /** Absolute canonical URL for this route. */
  canonical?: string;
  /** Adds a BreadcrumbList entry below "Home" for section deep-links. */
  breadcrumb?: { name: string; path: string };
  /** Overrides the location keyword set used for the meta keywords tag. */
  locationKeywords?: string[];
}

const DEFAULT_TITLE =
  'Sri Vinayaga Ayurvibe — Best Ayurveda Hospital Chennai | Perumbakkam, OMR';
const DEFAULT_DESCRIPTION =
  'Government-certified Ayurveda hospital at Nookampalayam, Perumbakkam, Chennai. Authentic Panchakarma, Abhyanga & Shirodhara by Dr. V. Vaitheeshwari, B.A.M.S. Book a consultation.';

/**
 * Public landing page.
 *
 * Layout lives in src/components/site/*; this file wires the sections together
 * and derives the page's structured data from the same content the sections
 * render, so schema and copy cannot drift apart. Section deep-links
 * (/about, /treatments, …) render this same page through SectionPage and pass
 * their own title/description/canonical, so exactly one <SEO> runs per route.
 */
const Index = ({ title, description, canonical, breadcrumb, locationKeywords }: IndexSeoProps = {}) => {
  useSiteTheme();

  const jsonLd = useMemo(
    () => [
      {
        '@type': 'MedicalClinic',
        '@id': `${clinic.url}/#business`,
        name: clinic.name,
        description: `Government-certified Ayurveda hospital at ${clinic.street}, ${clinic.locality} ${clinic.postalCode}. Classical Panchakarma, Abhyanga and Shirodhara led by ${doctor.name}, ${doctor.qualification}.`,
        url: `${clinic.url}/`,
        telephone: clinic.phone,
        email: clinic.email,
        priceRange: '₹₹',
        address: {
          '@type': 'PostalAddress',
          streetAddress: clinic.street,
          addressLocality: clinic.locality,
          addressRegion: clinic.region,
          postalCode: clinic.postalCode,
          addressCountry: clinic.country,
        },
        geo: { '@type': 'GeoCoordinates', latitude: clinic.geo.lat, longitude: clinic.geo.lng },
        openingHoursSpecification: [
          {
            '@type': 'OpeningHoursSpecification',
            dayOfWeek: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
            opens: clinic.hoursOpens,
            closes: clinic.hoursCloses,
          },
        ],
        medicalSpecialty: 'Ayurvedic',
        areaServed: LOCATIONS.map((name) => ({ '@type': 'City', name })),
        aggregateRating: {
          '@type': 'AggregateRating',
          ratingValue: clinic.ratingValue,
          reviewCount: clinic.reviewCount,
          bestRating: '5',
        },
        employee: {
          '@type': 'Physician',
          name: `${doctor.name}, ${doctor.qualification}`,
          medicalSpecialty: 'Ayurvedic',
          knowsLanguage: doctor.languages,
        },
      },
      {
        '@type': 'ItemList',
        name: `Ayurvedic treatments at ${clinic.name}`,
        numberOfItems: treatments.length,
        itemListElement: treatments.map((treatment, index) => ({
          '@type': 'ListItem',
          position: index + 1,
          item: {
            '@type': 'MedicalTherapy',
            name: treatment.name,
            description: treatment.description,
            medicineSystem: 'https://schema.org/Ayurvedic',
            relevantSpecialty: 'Ayurvedic',
            provider: { '@id': `${clinic.url}/#business` },
          },
        })),
      },
      {
        '@type': 'FAQPage',
        mainEntity: faqs.map((faq) => ({
          '@type': 'Question',
          name: faq.question,
          acceptedAnswer: { '@type': 'Answer', text: faq.answer },
        })),
      },
      ...testimonials.slice(0, 3).map((review) => ({
        '@type': 'Review',
        itemReviewed: { '@id': `${clinic.url}/#business` },
        reviewRating: { '@type': 'Rating', ratingValue: String(review.rating), bestRating: '5' },
        author: { '@type': 'Person', name: review.name },
        reviewBody: review.quote,
      })),
      {
        '@type': 'BreadcrumbList',
        itemListElement: [
          { '@type': 'ListItem', position: 1, name: 'Home', item: `${clinic.url}/` },
          ...(breadcrumb
            ? [{ '@type': 'ListItem', position: 2, name: breadcrumb.name, item: `${clinic.url}${breadcrumb.path}` }]
            : []),
        ],
      },
    ],
    [breadcrumb]
  );

  return (
    <div className="min-h-dvh bg-background">
      <SEO
        title={title ?? DEFAULT_TITLE}
        description={description ?? DEFAULT_DESCRIPTION}
        canonical={canonical ?? `${clinic.url}/`}
        locationKeywords={locationKeywords ?? LOCATIONS}
        jsonLd={jsonLd}
      />

      <a href="#main" className="skip-link">Skip to main content</a>

      <SmoothScrollProvider>
        <IntroCurtain />
        <RouteTransition />
        <MagneticCursor />

        <SmoothScroll />
        <BackToTop />
        <ProgressiveWebApp />

        <SiteHeader />
        <ScrollRail sections={RAIL_SECTIONS} />

        <main id="main">
          <Hero />
          <StatsBand />
          <AboutSection />
          <JourneySection />
          <TreatmentsSection />
          <ConcernsSection />
          <DoctorSection />
          <TestimonialsSection />
          <WhySection />
          <DoshaSection />
          <FaqSection />
          <BookingSection />
        </main>

        <SiteFooter />
        <MobileCtaBar />
        <LiveChat />
      </SmoothScrollProvider>
    </div>
  );
};

export default Index;
