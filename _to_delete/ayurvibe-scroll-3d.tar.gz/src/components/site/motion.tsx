import React, { useEffect, useRef, useState } from 'react';
import {
  motion,
  useInView,
  useReducedMotion,
  useScroll,
  useSpring,
  useTransform,
  type MotionValue,
  type Variants,
} from 'framer-motion';
import { cn } from '@/lib/utils';

/* ---------------------------------------------------------------------------
 * Shared easing + timing so every animation on the site feels like one system.
 * ------------------------------------------------------------------------- */
export const EASE = [0.22, 1, 0.36, 1] as const;
export const EASE_OUT = [0.16, 1, 0.3, 1] as const;

/**
 * Adds `site` to <html> while a public page is mounted. That scopes the
 * marketing palette (src/styles/site-theme.css) to the public site and lets
 * Radix portals — dialogs, selects, toasts — inherit it too.
 */
export const useSiteTheme = () => {
  useEffect(() => {
    const root = document.documentElement;
    root.classList.add('site');
    return () => root.classList.remove('site');
  }, []);
};

type Direction = 'up' | 'down' | 'left' | 'right' | 'none';

const offsetFor = (direction: Direction, distance: number) => {
  switch (direction) {
    case 'up': return { y: distance };
    case 'down': return { y: -distance };
    case 'left': return { x: distance };
    case 'right': return { x: -distance };
    default: return {};
  }
};

interface RevealProps {
  children: React.ReactNode;
  direction?: Direction;
  delay?: number;
  duration?: number;
  distance?: number;
  /** Adds a subtle blur-in. Nice for headings, skip it for large blocks. */
  blur?: boolean;
  className?: string;
  as?: 'div' | 'span' | 'section' | 'li' | 'header' | 'article';
  once?: boolean;
  amount?: number;
}

/**
 * Scroll-triggered entrance. Falls back to a plain element when the visitor
 * prefers reduced motion, so nothing ever animates against their settings.
 */
export const Reveal = ({
  children,
  direction = 'up',
  delay = 0,
  duration = 0.65,
  distance = 22,
  blur = false,
  className,
  as = 'div',
  once = true,
  amount = 0.25,
}: RevealProps) => {
  const reduce = useReducedMotion();
  const Tag = as as React.ElementType;
  const MotionTag = motion[as] as typeof motion.div;

  if (reduce) return <Tag className={className}>{children}</Tag>;

  return (
    <MotionTag
      className={className}
      initial={{ opacity: 0, filter: blur ? 'blur(8px)' : 'blur(0px)', ...offsetFor(direction, distance) }}
      whileInView={{ opacity: 1, x: 0, y: 0, filter: 'blur(0px)' }}
      viewport={{ once, amount, margin: '0px 0px -8% 0px' }}
      transition={{ duration, delay, ease: EASE }}
    >
      {children}
    </MotionTag>
  );
};

const groupVariants: Variants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.08, delayChildren: 0.04 } },
};

const itemVariants: Variants = {
  hidden: { opacity: 0, y: 22 },
  show: { opacity: 1, y: 0, transition: { duration: 0.6, ease: EASE } },
};

export const StaggerGroup = ({
  children,
  className,
  amount = 0.15,
  as = 'div',
}: {
  children: React.ReactNode;
  className?: string;
  amount?: number;
  as?: 'div' | 'ul' | 'ol';
}) => {
  const reduce = useReducedMotion();
  const Tag = as as React.ElementType;
  const MotionTag = motion[as] as typeof motion.div;
  if (reduce) return <Tag className={className}>{children}</Tag>;
  return (
    <MotionTag
      className={className}
      variants={groupVariants}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, amount }}
    >
      {children}
    </MotionTag>
  );
};

export const StaggerItem = ({
  children,
  className,
  as = 'div',
}: {
  children: React.ReactNode;
  className?: string;
  as?: 'div' | 'li' | 'article';
}) => {
  const reduce = useReducedMotion();
  const Tag = as as React.ElementType;
  const MotionTag = motion[as] as typeof motion.div;
  if (reduce) return <Tag className={className}>{children}</Tag>;
  return (
    <MotionTag className={className} variants={itemVariants}>
      {children}
    </MotionTag>
  );
};

/**
 * Word-by-word headline entrance. Renders real text (no per-letter spans) so
 * screen readers and crawlers still read one clean sentence.
 */
export const AnimatedHeadline = ({
  text,
  className,
  as: Tag = 'h2',
  highlight,
  highlightClassName = 'text-primary',
  delay = 0,
  id,
}: {
  text: string;
  className?: string;
  as?: 'h1' | 'h2' | 'h3';
  /** Optional trailing phrase rendered in an accent colour. */
  highlight?: string;
  highlightClassName?: string;
  delay?: number;
  id?: string;
}) => {
  const reduce = useReducedMotion();
  const words = text.split(' ');
  const highlightWords = highlight ? highlight.split(' ') : [];

  if (reduce) {
    return (
      <Tag className={className} id={id}>
        {text}
        {highlight ? <> <span className={highlightClassName}>{highlight}</span></> : null}
      </Tag>
    );
  }

  return (
    <Tag className={className} id={id}>
      <motion.span
        className="inline"
        initial="hidden"
        whileInView="show"
        viewport={{ once: true, amount: 0.4 }}
        variants={{ show: { transition: { staggerChildren: 0.045, delayChildren: delay } } }}
      >
        {words.map((word, i) => (
          <motion.span
            key={`${word}-${i}`}
            className="inline-block"
            variants={{
              hidden: { opacity: 0, y: '0.4em', filter: 'blur(6px)' },
              show: { opacity: 1, y: 0, filter: 'blur(0px)', transition: { duration: 0.55, ease: EASE } },
            }}
          >
            {word}
            {i < words.length - 1 ? ' ' : ''}
          </motion.span>
        ))}
        {highlightWords.map((word, i) => (
          <motion.span
            key={`hl-${word}-${i}`}
            className={`inline-block ${highlightClassName}`}
            variants={{
              hidden: { opacity: 0, y: '0.4em', filter: 'blur(6px)' },
              show: { opacity: 1, y: 0, filter: 'blur(0px)', transition: { duration: 0.55, ease: EASE } },
            }}
          >
            {i === 0 ? ' ' : ''}
            {word}
            {i < highlightWords.length - 1 ? ' ' : ''}
          </motion.span>
        ))}
      </motion.span>
    </Tag>
  );
};

/**
 * Counts a numeric value up when it scrolls into view. Accepts display strings
 * like "100+", "4.9", "7" and preserves the suffix.
 */
export const CountUp = ({
  value,
  className,
  durationMs = 1600,
}: {
  value: string;
  className?: string;
  durationMs?: number;
}) => {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: '0px 0px -12% 0px' });
  const reduce = useReducedMotion();

  const match = value.match(/^(\d+(?:\.\d+)?)(.*)$/);
  const target = match ? parseFloat(match[1]) : null;
  const suffix = match ? match[2] : '';
  const decimals = match && match[1].includes('.') ? 1 : 0;

  const [display, setDisplay] = useState(reduce || target === null ? value : `0${suffix}`);

  useEffect(() => {
    if (!inView || reduce || target === null) return;
    let frame = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const progress = Math.min((now - start) / durationMs, 1);
      const eased = 1 - Math.pow(1 - progress, 4);
      setDisplay(`${(target * eased).toFixed(decimals)}${suffix}`);
      if (progress < 1) frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [inView, reduce, target, suffix, decimals, durationMs]);

  return (
    <span ref={ref} className={cn('tabular', className)}>
      {display}
    </span>
  );
};

/** Vertical parallax for decorative media. Returns a MotionValue for `y`. */
export const useParallax = (
  ref: React.RefObject<HTMLElement>,
  distance = 60
): MotionValue<number> | undefined => {
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start end', 'end start'] });
  const raw = useTransform(scrollYProgress, [0, 1], [distance, -distance]);
  const smooth = useSpring(raw, { stiffness: 80, damping: 24, restDelta: 0.5 });
  return reduce ? undefined : smooth;
};

/**
 * Pointer-following tilt for feature cards. Disabled for reduced motion and on
 * touch devices (where there is no hover to drive it).
 */
export const TiltCard = ({
  children,
  className,
  intensity = 6,
}: {
  children: React.ReactNode;
  className?: string;
  intensity?: number;
}) => {
  const reduce = useReducedMotion();
  const ref = useRef<HTMLDivElement>(null);
  const [transform, setTransform] = useState('');

  if (reduce) return <div className={className}>{children}</div>;

  const onMove = (event: React.MouseEvent<HTMLDivElement>) => {
    const el = ref.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const px = (event.clientX - rect.left) / rect.width - 0.5;
    const py = (event.clientY - rect.top) / rect.height - 0.5;
    setTransform(`perspective(900px) rotateX(${(-py * intensity).toFixed(2)}deg) rotateY(${(px * intensity).toFixed(2)}deg)`);
  };

  return (
    <div
      ref={ref}
      className={className}
      onMouseMove={onMove}
      onMouseLeave={() => setTransform('')}
      style={{ transform, transition: transform ? 'transform 120ms ease-out' : 'transform 500ms cubic-bezier(0.22,1,0.36,1)' }}
    >
      {children}
    </div>
  );
};

/** Thin reading-progress bar, used by the sticky header. */
export const useScrollProgress = () => {
  const { scrollYProgress } = useScroll();
  return useSpring(scrollYProgress, { stiffness: 130, damping: 28, restDelta: 0.001 });
};

export default Reveal;
