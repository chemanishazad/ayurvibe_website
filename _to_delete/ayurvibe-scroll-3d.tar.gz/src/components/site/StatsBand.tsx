import React from 'react';
import { motion, useReducedMotion } from 'framer-motion';
import { treatments } from '@/data/treatments';
import { stats } from '@/data/site';
import { CountUp, EASE } from '@/components/site/motion';
import { VelocityMarquee } from '@/components/site/scroll';

/**
 * Therapy-name ribbon whose speed and skew react to scroll velocity — it leans
 * into the direction you are scrolling, then settles.
 */
const TherapyRibbon = () => (
  <div className="border-y border-border bg-secondary/60 py-3">
    <VelocityMarquee baseSpeed={38} className="edge-fade">
      {treatments.map((treatment) => (
        <span
          key={treatment.slug}
          className="flex shrink-0 items-center gap-6 pr-6 text-sm font-medium tracking-tight text-muted-foreground"
        >
          {treatment.name}
          <span aria-hidden className="h-1 w-1 rounded-full bg-primary/40" />
        </span>
      ))}
    </VelocityMarquee>
  </div>
);

/** Key numbers, each card flipping up from below in 3D as it enters view. */
const StatsBand = () => {
  const reduce = useReducedMotion();

  return (
    <section aria-label="Clinic at a glance" className="relative bg-background">
      <TherapyRibbon />

      <div className="shell py-12 sm:py-16">
        <motion.ul
          initial={reduce ? false : 'hidden'}
          whileInView="show"
          viewport={{ once: true, amount: 0.4 }}
          variants={{ show: { transition: { staggerChildren: 0.1 } } }}
          className="grid grid-cols-2 gap-y-10 [perspective:1200px] lg:grid-cols-4"
        >
          {stats.map((stat, i) => (
            <motion.li
              key={stat.label}
              variants={{
                hidden: { opacity: 0, y: 40, rotateX: -35 },
                show: { opacity: 1, y: 0, rotateX: 0, transition: { duration: 0.75, ease: EASE } },
              }}
              className={
                'origin-bottom px-4 text-center preserve-3d sm:px-6 lg:text-left ' +
                (i > 0 ? 'lg:border-l lg:border-border' : '')
              }
            >
              <p className="font-display text-4xl font-extrabold tracking-tight text-foreground sm:text-5xl">
                <CountUp value={stat.value} />
                {'suffix' in stat && stat.suffix ? (
                  <span className="ml-0.5 text-2xl text-saffron sm:text-3xl">{stat.suffix}</span>
                ) : null}
              </p>
              <p className="mt-1.5 text-sm font-semibold text-foreground">{stat.label}</p>
              <p className="text-xs text-muted-foreground">{stat.detail}</p>
            </motion.li>
          ))}
        </motion.ul>
      </div>
    </section>
  );
};

export default StatsBand;
