import React, { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { AnimatePresence, motion, useReducedMotion, useScroll, useTransform } from 'framer-motion';
import { ArrowRight, BadgeCheck, CalendarDays, MousePointer2, Phone, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { clinic, doctor, heroImage, heroSlides, heroSrcSet, trustPoints } from '@/data/site';
import { EASE } from '@/components/site/motion';
import { Depth, Magnetic, Stage3D, useScrollToSection } from '@/components/site/scroll';

const SLIDE_MS = 6000;

/**
 * Hero scene.
 *
 * Three things happen here:
 *  1. A perspective stage tilts the whole composition toward the pointer, with
 *     the image card, badges and orbs sitting at different translateZ depths.
 *  2. Scroll drives the scene away — copy rises and fades, the card recedes and
 *     blurs — so the page feels like a camera pulling back rather than a list.
 *  3. The gallery cross-fades through five clinical frames. Frame one is the
 *     preloaded LCP image; the <h1> never changes, so crawlers see one heading.
 */
const Hero = () => {
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const reduce = useReducedMotion();
  const sectionRef = useRef<HTMLElement>(null);
  const scrollTo = useScrollToSection();

  const { scrollYProgress } = useScroll({ target: sectionRef, offset: ['start start', 'end start'] });
  const copyY = useTransform(scrollYProgress, [0, 1], [0, -110]);
  const copyOpacity = useTransform(scrollYProgress, [0, 0.75], [1, 0]);
  const cardScale = useTransform(scrollYProgress, [0, 1], [1, 0.88]);
  const cardY = useTransform(scrollYProgress, [0, 1], [0, 70]);
  const cardBlur = useTransform(scrollYProgress, [0.35, 1], ['blur(0px)', 'blur(6px)']);
  const bgY = useTransform(scrollYProgress, [0, 1], [0, 160]);

  useEffect(() => {
    if (paused || reduce) return;
    const timer = window.setInterval(() => setIndex((i) => (i + 1) % heroSlides.length), SLIDE_MS);
    return () => window.clearInterval(timer);
  }, [paused, reduce]);

  const slide = heroSlides[index];
  const motionStyle = (style: Record<string, unknown>) => (reduce ? undefined : style);

  return (
    <section
      id="hero-section"
      ref={sectionRef}
      aria-labelledby="hero-heading"
      className="relative overflow-hidden bg-background pt-28 sm:pt-32 lg:pt-36"
    >
      {/* Ambient depth layers */}
      <motion.div aria-hidden style={motionStyle({ y: bgY })} className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-grid opacity-[0.55]" />
        <div className="drift absolute -right-32 -top-32 h-[34rem] w-[34rem] rounded-full bg-primary/8 blur-3xl" />
        <div className="drift absolute -left-40 top-40 h-[26rem] w-[26rem] rounded-full bg-saffron/8 blur-3xl" style={{ animationDelay: '-3s' }} />
      </motion.div>

      <div className="shell relative grid items-center gap-12 pb-20 lg:grid-cols-[1.05fr_1fr] lg:gap-16 lg:pb-28">
        {/* ---------------------------------------------------------------- */}
        {/* Copy                                                             */}
        {/* ---------------------------------------------------------------- */}
        <motion.div style={motionStyle({ y: copyY, opacity: copyOpacity })} className="max-w-2xl">
          <motion.span
            initial={reduce ? false : { opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: EASE }}
            className="eyebrow"
          >
            <BadgeCheck className="h-3.5 w-3.5" aria-hidden />
            Government certified · Reg. No. {clinic.regNo}
          </motion.span>

          {/* Word-by-word 3D headline: each word rotates up from below. */}
          <h1
            id="hero-heading"
            className="mt-5 font-display text-[2.35rem] font-extrabold leading-[1.06] text-foreground sm:text-5xl lg:text-[3.65rem]"
          >
            <motion.span
              className="inline-block [perspective:800px]"
              initial={reduce ? false : 'hidden'}
              animate="show"
              variants={{ show: { transition: { staggerChildren: 0.07, delayChildren: 0.1 } } }}
            >
              {['Authentic', 'Ayurveda', 'hospital', 'in'].map((word) => (
                <motion.span
                  key={word}
                  className="inline-block origin-bottom preserve-3d"
                  variants={{
                    hidden: { opacity: 0, y: '0.55em', rotateX: -55 },
                    show: { opacity: 1, y: 0, rotateX: 0, transition: { duration: 0.7, ease: EASE } },
                  }}
                >
                  {word}&nbsp;
                </motion.span>
              ))}
              <motion.span
                className="relative inline-block origin-bottom whitespace-nowrap preserve-3d text-primary"
                variants={{
                  hidden: { opacity: 0, y: '0.55em', rotateX: -55 },
                  show: { opacity: 1, y: 0, rotateX: 0, transition: { duration: 0.7, ease: EASE } },
                }}
              >
                Chennai
                <svg
                  aria-hidden
                  viewBox="0 0 300 12"
                  preserveAspectRatio="none"
                  className="absolute -bottom-1 left-0 h-2.5 w-full text-primary/35"
                >
                  <motion.path
                    d="M2 8 C 80 2, 220 2, 298 7"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="4"
                    strokeLinecap="round"
                    initial={reduce ? false : { pathLength: 0 }}
                    animate={{ pathLength: 1 }}
                    transition={{ duration: 0.9, delay: 0.65, ease: EASE }}
                  />
                </svg>
              </motion.span>
            </motion.span>
          </h1>

          {/* This paragraph is the largest element in the viewport, i.e. the LCP
              candidate. It animates with transform + blur only — an opacity
              fade would make the browser treat it as unpainted and push LCP out
              by the length of the animation. */}
          <motion.p
            initial={reduce ? false : { y: 18, filter: 'blur(5px)' }}
            animate={{ y: 0, filter: 'blur(0px)' }}
            transition={{ duration: 0.55, delay: 0.18, ease: EASE }}
            className="mt-6 text-lg leading-relaxed text-muted-foreground sm:text-xl"
          >
            Classical Panchakarma, Abhyanga and Shirodhara at Nookampalayam, Perumbakkam — every
            plan written by {doctor.name}, {doctor.qualification}, after a full constitutional
            assessment. No packages sold before a diagnosis.
          </motion.p>

          <motion.div
            initial={reduce ? false : { opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.45, ease: EASE }}
            className="mt-8 flex flex-col gap-3 sm:flex-row"
          >
            <Magnetic>
              <Button asChild size="lg" className="group h-12 rounded-full px-7 text-base font-semibold shadow-glow sm:h-[3.25rem]">
                <Link to="/booking">
                  <CalendarDays className="mr-2 h-5 w-5" aria-hidden />
                  Book a consultation
                  <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" aria-hidden />
                </Link>
              </Button>
            </Magnetic>
            <Magnetic strength={10}>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="h-12 rounded-full border-border px-7 text-base font-semibold hover:border-primary/40 hover:text-primary sm:h-[3.25rem]"
              >
                <a href={`tel:${clinic.phone}`}>
                  <Phone className="mr-2 h-5 w-5 text-primary" aria-hidden />
                  {clinic.phoneDisplay}
                </a>
              </Button>
            </Magnetic>
          </motion.div>

          <motion.ul
            initial="hidden"
            animate="show"
            variants={{ show: { transition: { staggerChildren: 0.09, delayChildren: 0.6 } } }}
            className="mt-9 grid gap-x-6 gap-y-4 border-t border-border pt-6 sm:grid-cols-3"
          >
            {trustPoints.map((point) => (
              <motion.li
                key={point.label}
                variants={{ hidden: { opacity: 0, y: 12 }, show: { opacity: 1, y: 0 } }}
                transition={{ duration: 0.5, ease: EASE }}
              >
                <p className="flex items-center gap-1.5 text-sm font-semibold text-foreground">
                  <BadgeCheck className="h-4 w-4 text-primary" aria-hidden />
                  {point.label}
                </p>
                <p className="mt-0.5 pl-[1.375rem] text-xs text-muted-foreground">{point.detail}</p>
              </motion.li>
            ))}
          </motion.ul>
        </motion.div>

        {/* ---------------------------------------------------------------- */}
        {/* 3D gallery                                                       */}
        {/* ---------------------------------------------------------------- */}
        <motion.div
          style={motionStyle({ scale: cardScale, y: cardY, filter: cardBlur })}
          initial={reduce ? false : { opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.15, ease: EASE }}
          onMouseEnter={() => setPaused(true)}
          onMouseLeave={() => setPaused(false)}
          onFocusCapture={() => setPaused(true)}
          onBlurCapture={() => setPaused(false)}
        >
          <Stage3D maxRotate={6} className="[transform-style:preserve-3d]">
            <Depth z={0} className="relative">
              <div className="relative aspect-[4/5] overflow-hidden rounded-[1.75rem] border border-border bg-muted shadow-glow sm:aspect-[5/4] lg:aspect-[4/5]">
                {heroSlides.map((s, i) => (
                  <img
                    key={s.id}
                    src={heroImage(s.id, 1100)}
                    srcSet={heroSrcSet(s.id)}
                    sizes="(min-width: 1024px) 44vw, 100vw"
                    alt={s.alt}
                    width={1100}
                    height={1375}
                    loading={i === 0 ? 'eager' : 'lazy'}
                    // @ts-expect-error fetchpriority is a valid HTML attribute React 18 forwards as-is
                    fetchpriority={i === 0 ? 'high' : undefined}
                    decoding={i === 0 ? 'sync' : 'async'}
                    className={cn(
                      'absolute inset-0 h-full w-full object-cover transition-opacity duration-[1100ms]',
                      i === index ? 'opacity-100' : 'opacity-0',
                      i === index && !reduce && 'ken-burns-slow'
                    )}
                  />
                ))}

                <div aria-hidden className="absolute inset-0 bg-gradient-to-t from-foreground/85 via-foreground/15 to-transparent" />

                <div className="absolute inset-x-0 bottom-0 p-5 sm:p-7">
                  <AnimatePresence mode="wait">
                    <motion.div
                      key={slide.id}
                      initial={reduce ? false : { opacity: 0, y: 18, filter: 'blur(6px)' }}
                      animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
                      exit={reduce ? undefined : { opacity: 0, y: -14, filter: 'blur(6px)' }}
                      transition={{ duration: 0.5, ease: EASE }}
                    >
                      <p className="text-xs font-semibold uppercase tracking-[0.16em] text-white/70">{slide.label}</p>
                      <p className="mt-1.5 font-display text-xl font-bold text-white sm:text-2xl">{slide.heading}</p>
                      <p className="mt-1 text-sm text-white/80">{slide.caption}</p>
                    </motion.div>
                  </AnimatePresence>

                  <div className="mt-5 flex gap-1.5" role="tablist" aria-label="Hero gallery">
                    {heroSlides.map((s, i) => (
                      <button
                        key={s.id}
                        type="button"
                        role="tab"
                        aria-selected={i === index}
                        aria-label={s.label}
                        onClick={() => setIndex(i)}
                        className="group relative h-1 flex-1 overflow-hidden rounded-full bg-white/25"
                      >
                        <span
                          className={cn(
                            'absolute inset-y-0 left-0 rounded-full bg-white transition-[width] ease-linear',
                            i === index ? 'w-full' : 'w-0 group-hover:w-1/4'
                          )}
                          style={
                            i === index && !reduce && !paused
                              ? { animation: `hero-progress ${SLIDE_MS}ms linear` }
                              : undefined
                          }
                        />
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </Depth>

            {/* Rating card floats in front of the image */}
            <Depth z={90} className="absolute left-4 top-1/2 hidden w-52 -translate-y-1/2 sm:block lg:-left-10">
              <motion.figure
                initial={reduce ? false : { opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.7, ease: EASE }}
                className="rounded-2xl border border-border bg-background/95 p-4 shadow-warm backdrop-blur"
              >
                <div className="flex items-center gap-1" aria-hidden>
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-saffron text-saffron" />
                  ))}
                </div>
                <figcaption className="mt-2 text-sm font-semibold text-foreground">
                  {clinic.ratingValue} out of 5
                </figcaption>
                <p className="text-xs text-muted-foreground">{clinic.reviewCount} Google reviews</p>
              </motion.figure>
            </Depth>

            {/* Doctor card floats further forward */}
            <Depth z={130} className="absolute -right-3 top-8 hidden max-w-[13rem] lg:block xl:-right-8">
              <motion.div
                initial={reduce ? false : { opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.85, ease: EASE }}
                className="rounded-2xl border border-border bg-background/95 p-4 shadow-warm backdrop-blur"
              >
                <p className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-primary">
                  <span className="h-2 w-2 rounded-full bg-primary pulse-dot" aria-hidden />
                  Consulting today
                </p>
                <p className="mt-2 text-sm font-semibold text-foreground">{doctor.name}</p>
                <p className="text-xs text-muted-foreground">
                  {doctor.qualification} · {doctor.role}
                </p>
              </motion.div>
            </Depth>
          </Stage3D>
        </motion.div>
      </div>

      {/* Scroll cue */}
      <motion.button
        type="button"
        onClick={() => scrollTo('#treatments')}
        style={motionStyle({ opacity: copyOpacity })}
        className="group absolute bottom-6 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-1.5 text-xs font-medium uppercase tracking-[0.2em] text-muted-foreground lg:flex"
      >
        <MousePointer2 className="h-4 w-4 text-primary transition-transform group-hover:translate-y-0.5" aria-hidden />
        Scroll to explore
        <span className="mt-1 block h-8 w-[1px] overflow-hidden bg-border">
          <motion.span
            className="block h-4 w-full bg-primary"
            animate={reduce ? undefined : { y: [-16, 32] }}
            transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut' }}
          />
        </span>
      </motion.button>

      <style>{`@keyframes hero-progress { from { width: 0% } to { width: 100% } }`}</style>
    </section>
  );
};

export default Hero;
