import React, { useEffect, useState } from 'react';
import { motion, useReducedMotion } from 'framer-motion';
import { ChevronLeft, ChevronRight, Compass, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import SectionHeading from '@/components/site/SectionHeading';
import { EASE, Reveal, StaggerGroup, StaggerItem } from '@/components/site/motion';
import { Magnetic } from '@/components/site/scroll';
import { doshas } from '@/data/site';
import DoshaQuiz from '@/components/DoshaQuiz';

const ROTATE_MS = 5200;
const ANGLE = 360 / doshas.length;
/** Distance from the centre of the carousel to each face, in px. */
const RADIUS = 300;

type Dosha = (typeof doshas)[number];

const DoshaCard = ({ dosha, active }: { dosha: Dosha; active: boolean }) => (
  <article
    className={cn(
      'surface flex h-full w-full flex-col overflow-hidden transition-[opacity,box-shadow] duration-500',
      active ? 'opacity-100 shadow-warm' : 'opacity-55'
    )}
  >
    <div className={`bg-gradient-to-br ${dosha.accent} p-6`}>
      <span className="font-display text-5xl font-extrabold text-foreground/85">{dosha.name[0]}</span>
      <h3 className="mt-2 font-display text-2xl font-bold text-foreground">{dosha.name}</h3>
      <p className="text-sm font-medium text-foreground/70">{dosha.element}</p>
    </div>

    <div className="flex flex-1 flex-col p-6">
      <p className="text-sm leading-relaxed text-muted-foreground">{dosha.summary}</p>

      <h4 className="mt-5 text-xs font-semibold uppercase tracking-wider text-foreground">Typical traits</h4>
      <ul className="mt-2 flex flex-wrap gap-1.5">
        {dosha.traits.map((trait) => (
          <li key={trait} className="rounded-full border border-border px-2.5 py-1 text-xs text-muted-foreground">
            {trait}
          </li>
        ))}
      </ul>

      <h4 className="mt-5 text-xs font-semibold uppercase tracking-wider text-foreground">
        What keeps it balanced
      </h4>
      <ul className="mt-2 space-y-1">
        {dosha.lifestyle.slice(0, 4).map((tip) => (
          <li key={tip} className="flex items-start gap-2 text-xs text-muted-foreground">
            <span aria-hidden className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-primary" />
            {tip}
          </li>
        ))}
      </ul>
    </div>
  </article>
);

/**
 * Dosha scene.
 *
 * Wide screens get a true 3D carousel: three cards sit on the faces of a
 * rotating prism (rotateY + translateZ inside a preserve-3d stage), advancing
 * on a timer and via the arrow controls. Narrow screens and reduced-motion
 * visitors get the same three cards as a plain grid — no content is exclusive
 * to the 3D view.
 */
const DoshaSection = () => {
  const [quizOpen, setQuizOpen] = useState(false);
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const reduce = useReducedMotion();
  const [is3D, setIs3D] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia('(min-width: 1024px)');
    const update = () => setIs3D(mq.matches);
    update();
    mq.addEventListener('change', update);
    return () => mq.removeEventListener('change', update);
  }, []);

  const carousel = is3D && !reduce;

  useEffect(() => {
    if (!carousel || paused || quizOpen) return;
    const timer = window.setInterval(() => setIndex((i) => i + 1), ROTATE_MS);
    return () => window.clearInterval(timer);
  }, [carousel, paused, quizOpen]);

  const activeIndex = ((index % doshas.length) + doshas.length) % doshas.length;

  return (
    <section id="dosha" aria-labelledby="dosha-heading" className="section-spacing overflow-hidden bg-secondary/40">
      <div className="shell">
        <SectionHeading
          id="dosha-heading"
          eyebrow="Know yourself"
          icon={Compass}
          title="Three constitutions, one"
          highlight="that's yours"
          description="Vata, Pitta and Kapha describe how your body runs — how you digest, sleep, react to stress and fall ill. Knowing yours is where a personalised plan starts."
        />

        {carousel ? (
          <div
            className="relative mt-16"
            onMouseEnter={() => setPaused(true)}
            onMouseLeave={() => setPaused(false)}
            onFocusCapture={() => setPaused(true)}
            onBlurCapture={() => setPaused(false)}
          >
            <div className="relative h-[34rem]" style={{ perspective: '1600px' }}>
              <motion.div
                className="absolute left-1/2 top-0 h-full w-[22rem] -translate-x-1/2 preserve-3d"
                animate={{ rotateY: -index * ANGLE }}
                transition={{ duration: 1.1, ease: EASE }}
              >
                {doshas.map((dosha, i) => (
                  <div
                    key={dosha.name}
                    className="absolute inset-0 backface-hidden"
                    style={{ transform: `rotateY(${i * ANGLE}deg) translateZ(${RADIUS}px)` }}
                    aria-hidden={i !== activeIndex}
                  >
                    <DoshaCard dosha={dosha} active={i === activeIndex} />
                  </div>
                ))}
              </motion.div>

              {/* Floor reflection to seat the prism */}
              <div
                aria-hidden
                className="pointer-events-none absolute inset-x-0 bottom-[-3rem] mx-auto h-24 w-2/3 rounded-[50%] bg-foreground/8 blur-2xl"
              />
            </div>

            {/* Controls */}
            <div className="mt-14 flex items-center justify-center gap-4">
              <button
                type="button"
                onClick={() => setIndex((i) => i - 1)}
                aria-label="Previous dosha"
                className="flex h-11 w-11 items-center justify-center rounded-full border border-border bg-background text-foreground transition-colors hover:border-primary/40 hover:text-primary"
              >
                <ChevronLeft className="h-5 w-5" aria-hidden />
              </button>

              <div className="flex items-center gap-2" role="tablist" aria-label="Choose a dosha">
                {doshas.map((dosha, i) => (
                  <button
                    key={dosha.name}
                    type="button"
                    role="tab"
                    aria-selected={i === activeIndex}
                    onClick={() => setIndex(i)}
                    className={cn(
                      'rounded-full px-4 py-2 text-sm font-semibold transition-colors',
                      i === activeIndex
                        ? 'bg-primary text-primary-foreground'
                        : 'border border-border text-muted-foreground hover:text-primary'
                    )}
                  >
                    {dosha.name}
                  </button>
                ))}
              </div>

              <button
                type="button"
                onClick={() => setIndex((i) => i + 1)}
                aria-label="Next dosha"
                className="flex h-11 w-11 items-center justify-center rounded-full border border-border bg-background text-foreground transition-colors hover:border-primary/40 hover:text-primary"
              >
                <ChevronRight className="h-5 w-5" aria-hidden />
              </button>
            </div>
          </div>
        ) : (
          <StaggerGroup className="mt-12 grid gap-5 md:grid-cols-3" as="ul">
            {doshas.map((dosha) => (
              <StaggerItem key={dosha.name} as="li" className="h-full">
                <DoshaCard dosha={dosha} active />
              </StaggerItem>
            ))}
          </StaggerGroup>
        )}

        <Reveal className="mt-14 flex flex-col items-center text-center">
          <Magnetic>
            <Button
              size="lg"
              onClick={() => setQuizOpen(true)}
              className="rounded-full px-8 py-6 text-base font-semibold shadow-glow"
            >
              <Sparkles className="mr-2 h-5 w-5" aria-hidden />
              Take the 5-minute dosha quiz
            </Button>
          </Magnetic>
          <p className="mt-3 text-sm text-muted-foreground">
            Free, no sign-up. The result is an indication — the clinical assessment happens in consultation.
          </p>
        </Reveal>
      </div>

      <DoshaQuiz isOpen={quizOpen} onClose={() => setQuizOpen(false)} />
    </section>
  );
};

export default DoshaSection;
