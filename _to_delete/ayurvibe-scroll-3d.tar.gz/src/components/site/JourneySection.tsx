import React from 'react';
import { Link } from 'react-router-dom';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { ArrowRight, ClipboardList, HeartPulse, Route, Sparkles, Stethoscope } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import SectionHeading from '@/components/site/SectionHeading';
import { EASE } from '@/components/site/motion';
import { Depth, Magnetic, Stage3D, usePinnedSteps } from '@/components/site/scroll';
import { approachSteps, heroImage, heroSrcSet } from '@/data/site';

/** One frame per step, reusing the already-optimised hero renditions. */
const stepMedia = [
  { id: 'hospital', alt: 'Consultation room at Sri Vinayaga Ayurvibe, Perumbakkam' },
  { id: 'herbs', alt: 'Herbal formulations prepared for a personalised treatment plan' },
  { id: 'shirodhara', alt: 'Shirodhara therapy being delivered in a dedicated therapy room' },
  { id: 'panchakarma', alt: 'Follow-up review during a Panchakarma programme' },
];

const stepIcons = [Stethoscope, ClipboardList, Sparkles, HeartPulse];

/**
 * Pinned scroll story: the section holds still for four screens of scrolling
 * while the step list, the counter and the image advance. Below lg — and for
 * reduced-motion visitors — it degrades to a plain vertical list of the same
 * content, so nothing is hidden behind the scroll interaction.
 */
const JourneySection = () => {
  const reduce = useReducedMotion();
  const { ref, pinned, active, setActive } = usePinnedSteps(approachSteps.length);

  return (
    <section id="journey" aria-labelledby="journey-heading" className="relative bg-background">
      <div className="shell section-spacing pb-0">
        <SectionHeading
          id="journey-heading"
          eyebrow="The process"
          icon={Route}
          title="Four steps from first visit to"
          highlight="lasting change"
          description="Nothing is prescribed before you are assessed. Here is exactly how a treatment plan is built and followed through."
        />
      </div>

      {/* Pinned scene ------------------------------------------------------- */}
      <div
        ref={ref}
        style={pinned ? { height: `${approachSteps.length * 100}vh` } : undefined}
        className="relative mt-12"
      >
        <div className={cn(pinned && 'sticky top-0 flex h-screen items-center overflow-hidden')}>
          <div className="shell grid w-full items-center gap-10 lg:grid-cols-[1fr_1.05fr] lg:gap-16">
            {/* Steps */}
            <ol className="relative space-y-3 lg:space-y-4">
              {/* Progress spine */}
              <span aria-hidden className="absolute left-[1.35rem] top-3 hidden h-[calc(100%-1.5rem)] w-[2px] bg-border lg:block">
                <motion.span
                  className="block w-full origin-top bg-primary"
                  animate={{ scaleY: pinned ? (active + 1) / approachSteps.length : 1 }}
                  transition={{ duration: 0.5, ease: EASE }}
                  style={{ height: '100%' }}
                />
              </span>

              {approachSteps.map((step, i) => {
                const Icon = stepIcons[i] ?? Stethoscope;
                const isActive = !pinned || i === active;
                return (
                  <li key={step.step}>
                    <button
                      type="button"
                      onClick={() => setActive(i)}
                      aria-current={pinned && i === active ? 'step' : undefined}
                      className={cn(
                        'flex w-full gap-4 rounded-2xl border p-4 text-left transition-all duration-500 lg:p-5',
                        isActive
                          ? 'border-primary/30 bg-background shadow-warm'
                          : 'border-transparent bg-transparent opacity-45 hover:opacity-75'
                      )}
                    >
                      <span
                        className={cn(
                          'relative z-10 flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border transition-colors duration-500',
                          isActive
                            ? 'border-primary bg-primary text-primary-foreground'
                            : 'border-border bg-background text-muted-foreground'
                        )}
                      >
                        <Icon className="h-5 w-5" aria-hidden />
                      </span>
                      <span className="min-w-0">
                        <span className="font-display text-xs font-extrabold tracking-[0.2em] text-primary">
                          {step.step}
                        </span>
                        <h3 className="mt-0.5 font-display text-lg font-bold text-foreground lg:text-xl">
                          {step.title}
                        </h3>
                        <motion.span
                          initial={false}
                          animate={{
                            height: isActive || !pinned ? 'auto' : 0,
                            opacity: isActive || !pinned ? 1 : 0,
                          }}
                          transition={{ duration: 0.4, ease: EASE }}
                          className="block overflow-hidden"
                        >
                          <span className="mt-1.5 block text-sm leading-relaxed text-muted-foreground">
                            {step.text}
                          </span>
                        </motion.span>
                      </span>
                    </button>
                  </li>
                );
              })}

              <li className="pt-2 lg:pl-5">
                <Magnetic>
                  <Button asChild className="group rounded-full px-6 font-semibold">
                    <Link to="/booking">
                      Start at step one
                      <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" aria-hidden />
                    </Link>
                  </Button>
                </Magnetic>
              </li>
            </ol>

            {/* Media — cross-fades with the active step */}
            <div className={cn('relative', !pinned && 'hidden lg:block')}>
              <Stage3D maxRotate={5}>
                <Depth z={0}>
                  <div className="relative aspect-[4/3] overflow-hidden rounded-[1.75rem] border border-border bg-muted shadow-glow">
                    <AnimatePresence mode="sync">
                      <motion.img
                        key={stepMedia[Math.min(active, stepMedia.length - 1)].id}
                        src={heroImage(stepMedia[Math.min(active, stepMedia.length - 1)].id, 1100)}
                        srcSet={heroSrcSet(stepMedia[Math.min(active, stepMedia.length - 1)].id)}
                        sizes="(min-width: 1024px) 46vw, 100vw"
                        alt={stepMedia[Math.min(active, stepMedia.length - 1)].alt}
                        width={1100}
                        height={825}
                        loading="lazy"
                        decoding="async"
                        initial={reduce ? false : { opacity: 0, scale: 1.06 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={reduce ? undefined : { opacity: 0 }}
                        transition={{ duration: 0.8, ease: EASE }}
                        className="absolute inset-0 h-full w-full object-cover"
                      />
                    </AnimatePresence>
                    <span aria-hidden className="absolute inset-0 bg-gradient-to-t from-foreground/70 via-transparent to-transparent" />

                    {/* Step counter */}
                    <div className="absolute bottom-5 left-5 right-5 flex items-end justify-between gap-4">
                      <p className="font-display text-5xl font-extrabold leading-none text-white/90 tabular">
                        {String(active + 1).padStart(2, '0')}
                        <span className="text-2xl text-white/50">/{String(approachSteps.length).padStart(2, '0')}</span>
                      </p>
                      <div className="flex gap-1.5 pb-2">
                        {approachSteps.map((step, i) => (
                          <span
                            key={step.step}
                            aria-hidden
                            className={cn(
                              'h-1 rounded-full transition-all duration-500',
                              i === active ? 'w-8 bg-white' : 'w-2 bg-white/40'
                            )}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                </Depth>

                <Depth z={70} className="absolute -left-4 -top-5 hidden lg:block">
                  <div className="rounded-2xl border border-border bg-background/95 px-4 py-3 shadow-warm backdrop-blur">
                    <p className="text-xs font-semibold uppercase tracking-wider text-primary">Now</p>
                    <p className="text-sm font-semibold text-foreground">{approachSteps[active].title}</p>
                  </div>
                </Depth>
              </Stage3D>
            </div>
          </div>
        </div>
      </div>

      {!pinned && <div className="pb-4" />}
    </section>
  );
};

export default JourneySection;
