import React, { useRef } from 'react';
import { Link } from 'react-router-dom';
import { motion, useReducedMotion, useScroll, useTransform } from 'framer-motion';
import { ArrowRight, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import SectionHeading from '@/components/site/SectionHeading';
import { EASE, Reveal } from '@/components/site/motion';
import { ClipReveal, Magnetic, Parallax } from '@/components/site/scroll';
import { clinic, differentiators } from '@/data/site';
import panchakarmaImg from '@/assets/panchakarma-treatment.webp';

/**
 * One card in the stack. Each sticks to the top in turn while the next slides
 * over it; the card underneath scales back and dims, so the pile reads as
 * depth rather than a list.
 */
const StackCard = ({
  index,
  total,
  title,
  text,
}: {
  index: number;
  total: number;
  title: string;
  text: string;
}) => {
  const ref = useRef<HTMLDivElement>(null);
  const reduce = useReducedMotion();
  // Progress of this card from the moment it pins to the moment the next card
  // has fully covered it.
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start 18%', 'end 30%'] });
  // Cards are opaque, so the incoming card covers the one beneath it. Only the
  // scale changes — fading would make two sets of text legible at once.
  const scale = useTransform(scrollYProgress, [0, 1], [1, 0.92]);
  const y = useTransform(scrollYProgress, [0, 1], [0, -8]);

  return (
    <div
      ref={ref}
      className={cn('stack-panel', !reduce && 'lg:sticky')}
      style={reduce ? undefined : { top: `calc(7.5rem + ${index * 0.9}rem)` }}
    >
      <motion.article
        style={reduce ? undefined : { scale, y }}
        className="surface origin-top overflow-hidden bg-background p-6 sm:p-8"
      >
        <div className="flex items-start gap-4">
          <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary/8 font-display text-sm font-extrabold text-primary">
            {String(index + 1).padStart(2, '0')}
          </span>
          <div>
            <h3 className="font-display text-xl font-bold text-foreground sm:text-2xl">{title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground sm:text-base">{text}</p>
          </div>
          <span className="ml-auto hidden shrink-0 text-xs font-medium text-muted-foreground sm:block">
            {index + 1} / {total}
          </span>
        </div>
      </motion.article>
    </div>
  );
};

const WhySection = () => (
  <section id="why" aria-labelledby="why-heading" className="section-spacing bg-background">
    <div className="shell">
      <SectionHeading
        id="why-heading"
        eyebrow="Why this hospital"
        icon={ShieldCheck}
        title="The difference between a spa and a"
        highlight="certified hospital"
        description="Ayurveda is only as good as the diagnosis behind it. Here is what that looks like in practice."
      />

      <div className="mt-14 grid gap-10 lg:grid-cols-2 lg:items-start lg:gap-16">
        {/* Stacked cards */}
        <div className="order-2 space-y-4 lg:order-1 lg:space-y-[26vh]">
          {differentiators.map((item, i) => (
            <StackCard
              key={item.title}
              index={i}
              total={differentiators.length}
              title={item.title}
              text={item.text}
            />
          ))}

          <div className="pt-2 lg:pt-[10vh]">
            <Magnetic>
              <Button
                asChild
                variant="outline"
                className="group rounded-full border-border px-6 font-semibold hover:border-primary/40 hover:text-primary"
              >
                <Link to="/treatments">
                  See all therapies
                  <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" aria-hidden />
                </Link>
              </Button>
            </Magnetic>
          </div>
        </div>

        {/* Sticky media */}
        <Reveal direction="left" className="order-1 lg:order-2 lg:sticky lg:top-28">
          <Parallax distance={26}>
            <div className="relative">
              <ClipReveal direction="up" className="overflow-hidden rounded-[1.5rem] border border-border shadow-warm">
                <img
                  src={panchakarmaImg}
                  alt="Panchakarma therapy room at Sri Vinayaga Ayurvibe, Perumbakkam, Chennai"
                  width={1400}
                  height={933}
                  loading="lazy"
                  decoding="async"
                  className="aspect-[4/3] w-full object-cover"
                />
              </ClipReveal>
              <motion.div
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.5 }}
                transition={{ duration: 0.6, delay: 0.35, ease: EASE }}
                className="absolute -bottom-6 left-5 right-5 rounded-2xl border border-border bg-background/95 px-5 py-4 shadow-warm backdrop-blur sm:left-8 sm:right-auto sm:w-64"
              >
                <p className="text-xs font-semibold uppercase tracking-wider text-primary">Certified facility</p>
                <p className="mt-1 text-sm text-muted-foreground">
                  Registration number {clinic.regNo}, issued by the state authority.
                </p>
              </motion.div>
            </div>
          </Parallax>
        </Reveal>
      </div>
    </div>
  </section>
);

export default WhySection;
