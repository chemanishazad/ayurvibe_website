import React, { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion, useMotionValue, useReducedMotion, useSpring } from 'framer-motion';
import { useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { EASE } from '@/components/site/motion';
import { useScrollProgress } from '@/components/site/motion';
import { useScrollToSection } from '@/components/site/scroll';
import { logoPath } from '@/components/Logo';

/* ===========================================================================
 * LOAD INTRO
 * ========================================================================= */

const INTRO_KEY = 'ayurvibe:intro-shown';

/**
 * Branded curtain shown on the first visit of a session: the logo settles, a
 * progress line fills, then two panels wipe apart to reveal the page.
 * Skipped for repeat navigations and for reduced-motion visitors, and it never
 * blocks interaction for longer than ~1.6 s.
 */
export const IntroCurtain = () => {
  const reduce = useReducedMotion();
  const [visible, setVisible] = useState(() => {
    if (typeof window === 'undefined') return false;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return false;
    return sessionStorage.getItem(INTRO_KEY) !== '1';
  });

  useEffect(() => {
    if (!visible) return;
    sessionStorage.setItem(INTRO_KEY, '1');
    const timer = window.setTimeout(() => setVisible(false), 1050);
    return () => window.clearTimeout(timer);
  }, [visible]);

  if (reduce) return null;

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          className="pointer-events-none fixed inset-0 z-[80]"
          initial={{ opacity: 1 }}
          exit={{ opacity: 1 }}
          aria-hidden
        >
          {/* Curtain panels */}
          <motion.div
            className="absolute inset-x-0 top-0 h-1/2 bg-foreground"
            initial={{ y: 0 }}
            exit={{ y: '-100%' }}
            transition={{ duration: 0.7, ease: EASE }}
          />
          <motion.div
            className="absolute inset-x-0 bottom-0 h-1/2 bg-foreground"
            initial={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ duration: 0.7, ease: EASE }}
          />

          {/* Mark + progress */}
          <motion.div
            className="absolute inset-0 flex flex-col items-center justify-center gap-5"
            initial={{ opacity: 0, scale: 0.94 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.06, transition: { duration: 0.35, ease: EASE } }}
            transition={{ duration: 0.5, ease: EASE }}
          >
            <img src={logoPath} alt="" width={64} height={96} loading="eager" decoding="async" className="h-16 w-auto" />
            <p className="font-display text-sm font-semibold uppercase tracking-[0.3em] text-background/80">
              Sri Vinayaga Ayurvibe
            </p>
            <span className="relative h-[2px] w-40 overflow-hidden rounded-full bg-background/20">
              <motion.span
                className="absolute inset-y-0 left-0 bg-background"
                initial={{ width: '0%' }}
                animate={{ width: '100%' }}
                transition={{ duration: 0.95, ease: 'easeInOut' }}
              />
            </span>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

/* ===========================================================================
 * CUSTOM CURSOR
 * ========================================================================= */

/**
 * Two-part cursor: a small dot that tracks exactly, and a ring that lags
 * behind and grows over interactive elements. Mouse-only — it never renders on
 * touch devices, and the native cursor stays available for anyone who prefers
 * reduced motion.
 */
export const MagneticCursor = () => {
  const reduce = useReducedMotion();
  const [enabled, setEnabled] = useState(false);
  const [variant, setVariant] = useState<'default' | 'grow' | 'text'>('default');
  const [hidden, setHidden] = useState(true);

  const x = useMotionValue(-100);
  const y = useMotionValue(-100);
  const ringX = useSpring(x, { stiffness: 180, damping: 20, mass: 0.5 });
  const ringY = useSpring(y, { stiffness: 180, damping: 20, mass: 0.5 });

  useEffect(() => {
    if (reduce) return;
    const mq = window.matchMedia('(pointer: fine)');
    const update = () => setEnabled(mq.matches);
    update();
    mq.addEventListener('change', update);
    return () => mq.removeEventListener('change', update);
  }, [reduce]);

  useEffect(() => {
    if (!enabled) return;
    document.documentElement.classList.add('has-custom-cursor');

    const onMove = (event: PointerEvent) => {
      x.set(event.clientX);
      y.set(event.clientY);
      setHidden(false);

      const target = event.target as HTMLElement | null;
      const interactive = target?.closest('a, button, [role="button"], [role="tab"], input, textarea, select, [data-cursor]');
      if (!interactive) {
        setVariant('default');
        return;
      }
      const hint = interactive.getAttribute('data-cursor');
      if (hint === 'text' || ['INPUT', 'TEXTAREA'].includes(interactive.tagName)) setVariant('text');
      else setVariant('grow');
    };

    const onLeave = () => setHidden(true);

    window.addEventListener('pointermove', onMove, { passive: true });
    window.addEventListener('pointerdown', onMove, { passive: true });
    document.addEventListener('mouseleave', onLeave);
    return () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerdown', onMove);
      document.removeEventListener('mouseleave', onLeave);
      document.documentElement.classList.remove('has-custom-cursor');
    };
  }, [enabled, x, y]);

  if (!enabled || reduce) return null;

  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 z-[70] hidden lg:block">
      <motion.div
        className="absolute h-1.5 w-1.5 rounded-full bg-primary"
        style={{ x, y, translateX: '-50%', translateY: '-50%', opacity: hidden ? 0 : 1 }}
      />
      <motion.div
        className={cn(
          'absolute rounded-full border transition-[width,height,background-color,border-color] duration-300',
          variant === 'grow'
            ? 'h-12 w-12 border-primary/50 bg-primary/10'
            : variant === 'text'
              ? 'h-8 w-[2px] rounded-sm border-primary bg-primary/70'
              : 'h-8 w-8 border-primary/35'
        )}
        style={{ x: ringX, y: ringY, translateX: '-50%', translateY: '-50%', opacity: hidden ? 0 : 1 }}
      />
    </div>
  );
};

/* ===========================================================================
 * SCROLL RAIL
 * ========================================================================= */

interface RailSection {
  id: string;
  label: string;
}

/**
 * Right-hand rail: a progress line plus one dot per section. Dots reflect the
 * section currently in view and jump to it through the smooth-scroll engine.
 */
export const ScrollRail = ({ sections }: { sections: RailSection[] }) => {
  const progress = useScrollProgress();
  const reduce = useReducedMotion();
  const scrollTo = useScrollToSection();
  const [activeId, setActiveId] = useState(sections[0]?.id);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 400);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const visibleEntry = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visibleEntry?.target.id) setActiveId(visibleEntry.target.id);
      },
      { rootMargin: '-45% 0px -45% 0px', threshold: [0, 0.25, 0.5, 1] }
    );
    sections.forEach(({ id }) => {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, [sections]);

  return (
    <motion.aside
      aria-label="Section navigation"
      initial={false}
      animate={{ opacity: visible ? 1 : 0, x: visible ? 0 : 16 }}
      transition={{ duration: 0.35, ease: EASE }}
      className="fixed right-5 top-1/2 z-40 hidden -translate-y-1/2 flex-col items-center gap-4 xl:flex"
    >
      <span className="relative h-24 w-[2px] overflow-hidden rounded-full bg-border">
        <motion.span
          className="absolute inset-x-0 top-0 origin-top bg-primary"
          style={{ height: '100%', scaleY: reduce ? 1 : progress }}
        />
      </span>

      <ul className="flex flex-col items-center gap-3">
        {sections.map((section) => {
          const active = activeId === section.id;
          return (
            <li key={section.id}>
              <button
                type="button"
                onClick={() => scrollTo(`#${section.id}`)}
                aria-current={active ? 'true' : undefined}
                className="group relative flex items-center"
              >
                <span
                  className={cn(
                    'block rounded-full transition-all duration-300',
                    active ? 'h-2.5 w-2.5 bg-primary' : 'h-1.5 w-1.5 bg-border group-hover:bg-primary/60'
                  )}
                />
                <span className="pointer-events-none absolute right-6 whitespace-nowrap rounded-full bg-foreground px-2.5 py-1 text-[0.7rem] font-medium text-background opacity-0 transition-opacity duration-200 group-hover:opacity-100">
                  {section.label}
                </span>
              </button>
            </li>
          );
        })}
      </ul>
    </motion.aside>
  );
};

/* ===========================================================================
 * ROUTE TRANSITION
 * ========================================================================= */

/**
 * Wipes a panel across the viewport whenever the public route changes, then
 * scrolls the new route to the top. Deep-link scrolling in SectionPage runs
 * after the wipe clears.
 */
export const RouteTransition = () => {
  const location = useLocation();
  const reduce = useReducedMotion();
  const first = useRef(true);
  const [key, setKey] = useState<string | null>(null);

  useEffect(() => {
    if (first.current) {
      first.current = false;
      return;
    }
    setKey(location.pathname);
    const timer = window.setTimeout(() => setKey(null), 900);
    return () => window.clearTimeout(timer);
  }, [location.pathname]);

  if (reduce) return null;

  return (
    <AnimatePresence>
      {key && (
        <motion.div
          key={key}
          aria-hidden
          className="pointer-events-none fixed inset-0 z-[60] flex items-center justify-center bg-foreground"
          initial={{ clipPath: 'inset(0% 0% 100% 0%)' }}
          animate={{ clipPath: 'inset(0% 0% 0% 0%)' }}
          exit={{ clipPath: 'inset(100% 0% 0% 0%)' }}
          transition={{ duration: 0.45, ease: EASE }}
        >
          <img src={logoPath} alt="" width={40} height={60} className="h-10 w-auto opacity-90" />
        </motion.div>
      )}
    </AnimatePresence>
  );
};
