import React, { useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { AnimatePresence, motion, useMotionValueEvent, useReducedMotion, useScroll } from 'framer-motion';
import { ArrowRight, Check, ChevronDown, Clock, MoveHorizontal, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { cn } from '@/lib/utils';
import SectionHeading from '@/components/site/SectionHeading';
import { EASE, Reveal } from '@/components/site/motion';
import { HorizontalScroller, Magnetic } from '@/components/site/scroll';
import Scene3D from '@/components/site/three/Scene3D';
import { useCanRender3D } from '@/components/site/three/capabilities';
import { treatmentCategories, treatments, type Treatment } from '@/data/treatments';

/** How many cards ride the pinned horizontal rail before the grid takes over. */
const RAIL_COUNT = 10;

const TreatmentCard = ({
  treatment,
  onOpen,
  index,
  variant = 'rail',
}: {
  treatment: Treatment;
  onOpen: (t: Treatment) => void;
  index: number;
  variant?: 'rail' | 'grid';
}) => {
  const reduce = useReducedMotion();
  // Rail cards start offscreen to the right, where an in-view trigger would
  // never fire — they ride in with the rail instead. Grid cards fade up.
  const entrance =
    variant === 'grid' && !reduce
      ? {
          initial: { opacity: 0, y: 24 },
          whileInView: { opacity: 1, y: 0 },
          viewport: { once: true, amount: 0.2 },
          exit: { opacity: 0, y: -10 },
        }
      : {};

  return (
    <motion.article
      layout={!reduce}
      {...entrance}
      transition={{ duration: 0.55, delay: Math.min(index, 6) * 0.05, ease: EASE }}
      className={cn(
        'group surface lift-3d sheen flex h-full flex-col overflow-hidden',
        variant === 'rail' && 'w-[16.5rem] shrink-0 sm:w-[19rem]'
      )}
    >
      <button
        type="button"
        onClick={() => onOpen(treatment)}
        aria-label={`View details of ${treatment.name}`}
        className="relative block aspect-[4/3] w-full overflow-hidden bg-muted text-left"
      >
        <img
          src={treatment.image}
          alt={`${treatment.name} — Ayurvedic therapy at Sri Vinayaga Ayurvibe, Chennai`}
          width={900}
          height={675}
          loading="lazy"
          decoding="async"
          className="h-full w-full object-cover transition-transform duration-[1100ms] ease-out group-hover:scale-[1.08]"
        />
        <span
          aria-hidden
          className="absolute inset-0 bg-gradient-to-t from-foreground/70 via-transparent to-transparent opacity-80"
        />
        <span className="absolute left-3 top-3 rounded-full bg-background/92 px-2.5 py-1 text-[0.68rem] font-semibold uppercase tracking-wider text-foreground backdrop-blur">
          {treatment.category}
        </span>
        <span className="absolute bottom-3 left-3 flex items-center gap-1.5 text-xs font-medium text-white">
          <Clock className="h-3.5 w-3.5" aria-hidden />
          {treatment.duration}
        </span>
      </button>

      <div className="flex flex-1 flex-col p-5">
        <h3 className="font-display text-lg font-bold leading-snug text-foreground">{treatment.name}</h3>
        <p className="mt-2 line-clamp-3 text-sm leading-relaxed text-muted-foreground">
          {treatment.description}
        </p>

        <ul className="mt-4 space-y-1.5">
          {treatment.benefits.slice(0, 2).map((benefit) => (
            <li key={benefit} className="flex items-start gap-2 text-xs text-foreground/80">
              <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" aria-hidden />
              {benefit}
            </li>
          ))}
        </ul>

        <div className="mt-5 flex items-center gap-2 pt-1">
          <Button asChild size="sm" className="flex-1 rounded-full font-semibold">
            <Link to="/booking">Book</Link>
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={() => onOpen(treatment)}
            className="rounded-full border-border font-semibold hover:border-primary/40 hover:text-primary"
          >
            Details
          </Button>
        </div>
      </div>
    </motion.article>
  );
};

/**
 * Pinned 3D scene: the therapy photographs ride a cylinder that spins as the
 * section scrolls. The card facing the camera is mirrored into a real DOM panel
 * beside it, so its name, duration and links are selectable, focusable and
 * indexable — the canvas is presentation only.
 */
const CarouselScene = ({
  items,
  onOpen,
}: {
  items: Treatment[];
  onOpen: (t: Treatment) => void;
}) => {
  const pinRef = useRef<HTMLDivElement>(null);
  const progressRef = useRef(0);
  const [facing, setFacing] = useState(0);

  const { scrollYProgress } = useScroll({ target: pinRef, offset: ['start start', 'end end'] });
  useMotionValueEvent(scrollYProgress, 'change', (v) => {
    progressRef.current = v;
  });

  const active = items[Math.min(facing, items.length - 1)];

  return (
    <div ref={pinRef} style={{ height: `${items.length * 32 + 60}vh` }} className="relative">
      <div className="sticky top-0 h-screen overflow-hidden">
        <Scene3D
          name="carousel"
          items={items.map((t) => ({
            slug: t.slug,
            name: t.name,
            duration: t.duration,
            category: t.category,
            image: t.image,
          }))}
          progressRef={progressRef}
          onFacingChange={setFacing}
          className="absolute inset-0"
          minWidth={1024}
          fallback={null}
        />

        {/* DOM layer */}
        <div className="pointer-events-none relative z-10 flex h-full flex-col justify-between pb-14 pt-24">
          <div className="shell flex items-end justify-between gap-6">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.18em] text-primary">
                Signature therapies
              </p>
              <p className="mt-1 font-display text-2xl font-bold text-foreground">
                Spin through the treatment room
              </p>
            </div>
            <div className="hidden w-56 shrink-0 items-center gap-3 sm:flex">
              <span className="relative h-[3px] flex-1 overflow-hidden rounded-full bg-border">
                <motion.span
                  className="absolute inset-y-0 left-0 w-full origin-left rounded-full bg-primary"
                  style={{ scaleX: scrollYProgress }}
                />
              </span>
              <span className="text-xs font-medium text-muted-foreground">scroll or drag</span>
            </div>
          </div>

          <div className="shell">
            <AnimatePresence mode="wait">
              <motion.div
                key={active.slug}
                initial={{ opacity: 0, y: 18 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -12 }}
                transition={{ duration: 0.35, ease: EASE }}
                className="pointer-events-auto max-w-md rounded-2xl border border-border bg-background/92 p-6 shadow-warm backdrop-blur"
              >
                <p className="text-xs font-semibold uppercase tracking-wider text-primary">
                  {active.category} · {active.duration}
                </p>
                <h3 className="mt-1.5 font-display text-2xl font-bold text-foreground">{active.name}</h3>
                <p className="mt-2 line-clamp-2 text-sm leading-relaxed text-muted-foreground">
                  {active.description}
                </p>
                <div className="mt-4 flex gap-2">
                  <Button asChild size="sm" className="rounded-full font-semibold">
                    <Link to="/booking">Book this therapy</Link>
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => onOpen(active)}
                    className="rounded-full border-border font-semibold hover:border-primary/40 hover:text-primary"
                  >
                    Details
                  </Button>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
};

/**
 * Treatments scene.
 *
 * On wide screens the first ten cards ride a pinned rail that scrolls sideways
 * as you scroll down; everything else drops into an expandable grid. Narrow
 * screens and reduced-motion visitors get a normal swipeable row plus the grid,
 * so every therapy is reachable either way.
 */
const TreatmentsSection = () => {
  const [filter, setFilter] = useState<string>('All');
  const [expanded, setExpanded] = useState(false);
  const [active, setActive] = useState<Treatment | null>(null);
  const reduce = useReducedMotion();
  const can3D = useCanRender3D({ minWidth: 1024 });

  const filtered = useMemo(
    () => (filter === 'All' ? treatments : treatments.filter((t) => t.category === filter)),
    [filter]
  );
  const rail = filtered.slice(0, RAIL_COUNT);
  const rest = filtered.slice(RAIL_COUNT);

  return (
    <section id="treatments" aria-labelledby="treatments-heading" className="relative bg-background py-16 sm:py-20 lg:py-24">
      <div className="shell">
        <SectionHeading
          id="treatments-heading"
          eyebrow="Signature therapies"
          icon={Sparkles}
          title="33 classical treatments, matched to"
          highlight="your constitution"
          description="From Shirodhara and Pizhichil to Kati Vasti and Navara Kizhi — each therapy is prescribed after assessment, never sold as a standalone package."
        />

        <Reveal className="mt-10">
          <div className="flex flex-wrap justify-center gap-2" role="tablist" aria-label="Filter treatments by category">
            {treatmentCategories.map((category) => {
              const selected = filter === category;
              return (
                <button
                  key={category}
                  type="button"
                  role="tab"
                  aria-selected={selected}
                  onClick={() => {
                    setFilter(category);
                    setExpanded(false);
                  }}
                  className={cn(
                    'relative rounded-full border px-4 py-2 text-sm font-semibold transition-colors',
                    selected
                      ? 'border-primary text-primary-foreground'
                      : 'border-border text-muted-foreground hover:border-primary/40 hover:text-primary'
                  )}
                >
                  {selected && (
                    <motion.span
                      layoutId="treatment-filter-pill"
                      className="absolute inset-0 -z-10 rounded-full bg-primary"
                      transition={{ duration: 0.35, ease: EASE }}
                    />
                  )}
                  {category}
                </button>
              );
            })}
          </div>
        </Reveal>

        <p className="mt-5 flex items-center justify-center gap-2 text-center text-sm text-muted-foreground">
          <MoveHorizontal className="h-4 w-4 text-primary lg:animate-pulse" aria-hidden />
          <span>
            <span className="font-semibold text-foreground">{filtered.length}</span> therapies —{' '}
            <span className="hidden lg:inline">
              {can3D ? 'scroll to spin the carousel, or drag it' : 'keep scrolling to move through them'}
            </span>
            <span className="lg:hidden">swipe to browse</span>
          </span>
        </p>
      </div>

      {/* 3D carousel where the GPU allows it, pinned horizontal rail otherwise */}
      {can3D ? (
        <CarouselScene items={rail} onOpen={setActive} />
      ) : (
        <div className="mt-10 [perspective:1600px]">
          <p className="sr-only">Scroll to move through the featured therapies.</p>
          <HorizontalScroller
            ariaLabel="Featured therapies"
            trackClassName="items-stretch"
            header={(progress) => (
              <div className="shell flex items-end justify-between gap-6">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.18em] text-primary">
                    Signature therapies
                  </p>
                  <p className="mt-1 font-display text-2xl font-bold text-foreground">
                    {filter === 'All' ? 'Most requested at the clinic' : filter}
                  </p>
                </div>
                <div className="hidden w-56 shrink-0 items-center gap-3 sm:flex">
                  <span className="relative h-[3px] flex-1 overflow-hidden rounded-full bg-border">
                    <motion.span
                      className="absolute inset-y-0 left-0 w-full origin-left rounded-full bg-primary"
                      style={{ scaleX: progress }}
                    />
                  </span>
                  <span className="text-xs font-medium text-muted-foreground">scroll</span>
                </div>
              </div>
            )}
          >
            {rail.map((treatment, i) => (
              <TreatmentCard key={treatment.slug} treatment={treatment} onOpen={setActive} index={i} variant="rail" />
            ))}

            <div className="flex w-[16.5rem] shrink-0 items-center sm:w-[19rem]">
              <div className="surface flex h-full w-full flex-col justify-center p-7 text-center">
                <p className="font-display text-2xl font-bold text-foreground">
                  +{Math.max(0, filtered.length - RAIL_COUNT)} more therapies
                </p>
                <p className="mt-2 text-sm text-muted-foreground">
                  Vasti, Kizhi, Dhara and specialised protocols — all listed below.
                </p>
                <Magnetic className="mt-5 justify-center">
                  <Button onClick={() => setExpanded(true)} className="group rounded-full px-6 font-semibold">
                    See the full list
                    <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" aria-hidden />
                  </Button>
                </Magnetic>
              </div>
            </div>
          </HorizontalScroller>
        </div>
      )}

      {/* Every therapy stays in the document, whichever presentation is used. */}
      <ul className="sr-only">
        {treatments.map((t) => (
          <li key={t.slug}>
            {t.name} — {t.category}, {t.duration}. {t.description}
          </li>
        ))}
      </ul>

      {/* Full grid */}
      <div className="shell mt-14">
        <AnimatePresence initial={false}>
          {expanded && rest.length > 0 && (
            <motion.div
              key={`grid-${filter}`}
              initial={reduce ? false : { opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={reduce ? undefined : { opacity: 0, height: 0 }}
              transition={{ duration: 0.6, ease: EASE }}
              className="overflow-hidden"
            >
              <div className="grid grid-cols-1 gap-5 pb-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                {rest.map((treatment, i) => (
                  <TreatmentCard
                    key={treatment.slug}
                    treatment={treatment}
                    onOpen={setActive}
                    index={i}
                    variant="grid"
                  />
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {rest.length > 0 && (
          <div className="text-center">
            <Magnetic>
              <Button
                variant="outline"
                size="lg"
                onClick={() => setExpanded((v) => !v)}
                className="group rounded-full border-border px-7 font-semibold hover:border-primary/40 hover:text-primary"
              >
                {expanded ? 'Show fewer therapies' : `View all ${filtered.length} therapies`}
                <ChevronDown
                  className={cn('ml-2 h-4 w-4 transition-transform duration-300', expanded && 'rotate-180')}
                  aria-hidden
                />
              </Button>
            </Magnetic>
          </div>
        )}
      </div>

      {/* Details dialog */}
      <Dialog open={!!active} onOpenChange={(open) => !open && setActive(null)}>
        <DialogContent className="max-h-[88vh] max-w-2xl overflow-y-auto rounded-2xl p-0">
          {active && (
            <>
              <div className="relative aspect-[16/9] w-full overflow-hidden bg-muted">
                <img
                  src={active.image}
                  alt={`${active.name} — Ayurvedic therapy at Sri Vinayaga Ayurvibe, Chennai`}
                  width={900}
                  height={506}
                  className="h-full w-full object-cover"
                />
                <span aria-hidden className="absolute inset-0 bg-gradient-to-t from-foreground/70 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 p-5">
                  <span className="rounded-full bg-background/92 px-2.5 py-1 text-[0.68rem] font-semibold uppercase tracking-wider text-foreground">
                    {active.category}
                  </span>
                </div>
              </div>

              <div className="p-6">
                <DialogHeader className="space-y-1 text-left">
                  <DialogTitle className="font-display text-2xl font-bold">{active.name}</DialogTitle>
                  <DialogDescription className="flex items-center gap-1.5 text-sm">
                    <Clock className="h-4 w-4 text-primary" aria-hidden />
                    {active.duration} per session
                  </DialogDescription>
                </DialogHeader>

                <p className="mt-4 text-sm leading-relaxed text-muted-foreground">{active.description}</p>

                <h4 className="mt-6 text-sm font-semibold text-foreground">What it helps with</h4>
                <ul className="mt-3 grid gap-2 sm:grid-cols-2">
                  {active.benefits.map((benefit) => (
                    <li key={benefit} className="flex items-start gap-2 text-sm text-muted-foreground">
                      <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden />
                      {benefit}
                    </li>
                  ))}
                </ul>

                <div className="mt-7 flex flex-col gap-2 sm:flex-row">
                  <Button asChild className="group flex-1 rounded-full font-semibold">
                    <Link to="/booking" onClick={() => setActive(null)}>
                      Book this therapy
                      <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" aria-hidden />
                    </Link>
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setActive(null)}
                    className="rounded-full border-border font-semibold"
                  >
                    Close
                  </Button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
};

export default TreatmentsSection;
