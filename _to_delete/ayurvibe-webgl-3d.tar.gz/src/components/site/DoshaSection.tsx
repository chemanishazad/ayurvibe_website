import React, { useEffect, useState } from 'react';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { ChevronLeft, ChevronRight, Compass, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import SectionHeading from '@/components/site/SectionHeading';
import { EASE, Reveal, StaggerGroup, StaggerItem } from '@/components/site/motion';
import { Magnetic } from '@/components/site/scroll';
import Scene3D from '@/components/site/three/Scene3D';
import { useCanRender3D } from '@/components/site/three/capabilities';
import { doshas } from '@/data/site';
import DoshaQuiz from '@/components/DoshaQuiz';

const ROTATE_MS = 6000;

type Dosha = (typeof doshas)[number];

const DoshaCard = ({ dosha, active = true }: { dosha: Dosha; active?: boolean }) => (
  <article
    className={cn(
      'surface flex h-full w-full flex-col overflow-hidden transition-[opacity,box-shadow] duration-500',
      active ? 'opacity-100 shadow-warm' : 'opacity-55'
    )}
  >
    <div className={`bg-gradient-to-br ${dosha.accent} p-6`}>
      <span className="font-display text-5xl font-extrabold text-foreground/85">{dosha.name[0]}</span>
      <h3 className="mt-2 font-display text-2xl font-bold text-foreground">{dosha.name}</h3>
      <p className="text-sm font-medium text-foreground/70">{dosha.element}</p>
    </div>

    <div className="flex flex-1 flex-col p-6">
      <p className="text-sm leading-relaxed text-muted-foreground">{dosha.summary}</p>

      <h4 className="mt-5 text-xs font-semibold uppercase tracking-wider text-foreground">Typical traits</h4>
      <ul className="mt-2 flex flex-wrap gap-1.5">
        {dosha.traits.map((trait) => (
          <li key={trait} className="rounded-full border border-border px-2.5 py-1 text-xs text-muted-foreground">
            {trait}
          </li>
        ))}
      </ul>

      <h4 className="mt-5 text-xs font-semibold uppercase tracking-wider text-foreground">
        What keeps it balanced
      </h4>
      <ul className="mt-2 space-y-1">
        {dosha.lifestyle.slice(0, 4).map((tip) => (
          <li key={tip} className="flex items-start gap-2 text-xs text-muted-foreground">
            <span aria-hidden className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-primary" />
            {tip}
          </li>
        ))}
      </ul>
    </div>
  </article>
);

/**
 * Dosha scene.
 *
 * On capable wide screens the three constitutions are lit, noise-displaced 3D
 * orbs — airy, fiery, earthy — on a ring that turns to bring the selected one
 * forward. The written content lives in ordinary DOM beside the canvas, and
 * every dosha's copy stays in the document (visually hidden when it is not the
 * selected one) so nothing is locked inside WebGL. Narrow screens and
 * reduced-motion visitors get the plain three-card grid.
 */
const DoshaSection = () => {
  const [quizOpen, setQuizOpen] = useState(false);
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const reduce = useReducedMotion();
  const can3D = useCanRender3D({ minWidth: 1024 });

  useEffect(() => {
    if (!can3D || paused || quizOpen || reduce) return;
    const timer = window.setInterval(() => setIndex((i) => i + 1), ROTATE_MS);
    return () => window.clearInterval(timer);
  }, [can3D, paused, quizOpen, reduce]);

  const activeIndex = ((index % doshas.length) + doshas.length) % doshas.length;
  const active = doshas[activeIndex];

  return (
    <section id="dosha" aria-labelledby="dosha-heading" className="section-spacing overflow-hidden bg-secondary/40">
      <div className="shell">
        <SectionHeading
          id="dosha-heading"
          eyebrow="Know yourself"
          icon={Compass}
          title="Three constitutions, one"
          highlight="that's yours"
          description="Vata, Pitta and Kapha describe how your body runs — how you digest, sleep, react to stress and fall ill. Knowing yours is where a personalised plan starts."
        />

        {can3D ? (
          <div
            className="mt-14"
            onMouseEnter={() => setPaused(true)}
            onMouseLeave={() => setPaused(false)}
            onFocusCapture={() => setPaused(true)}
            onBlurCapture={() => setPaused(false)}
          >
            <div className="grid items-center gap-10 lg:grid-cols-[1.1fr_0.9fr] lg:gap-14">
              {/* Orbs */}
              <div className="relative">
                <Scene3D
                  name="orbs"
                  activeIndex={activeIndex}
                  className="relative h-[26rem] w-full lg:h-[30rem]"
                  minWidth={1024}
                  fallback={null}
                />
                <p className="mt-2 text-center text-xs text-muted-foreground">
                  Each orb is rendered live — its surface movement reflects the dosha's element.
                </p>
              </div>

              {/* Written content for the selected dosha */}
              <div>
                <AnimatePresence mode="wait">
                  <motion.div
                    key={active.name}
                    initial={reduce ? false : { opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={reduce ? undefined : { opacity: 0, y: -14 }}
                    transition={{ duration: 0.4, ease: EASE }}
                  >
                    <DoshaCard dosha={active} />
                  </motion.div>
                </AnimatePresence>
              </div>
            </div>

            {/* Controls */}
            <div className="mt-10 flex items-center justify-center gap-4">
              <button
                type="button"
                onClick={() => setIndex((i) => i - 1)}
                aria-label="Previous dosha"
                className="flex h-11 w-11 items-center justify-center rounded-full border border-border bg-background text-foreground transition-colors hover:border-primary/40 hover:text-primary"
              >
                <ChevronLeft className="h-5 w-5" aria-hidden />
              </button>

              <div className="flex items-center gap-2" role="tablist" aria-label="Choose a dosha">
                {doshas.map((dosha, i) => (
                  <button
                    key={dosha.name}
                    type="button"
                    role="tab"
                    aria-selected={i === activeIndex}
                    onClick={() => setIndex(i)}
                    className={cn(
                      'rounded-full px-4 py-2 text-sm font-semibold transition-colors',
                      i === activeIndex
                        ? 'bg-primary text-primary-foreground'
                        : 'border border-border text-muted-foreground hover:text-primary'
                    )}
                  >
                    {dosha.name}
                  </button>
                ))}
              </div>

              <button
                type="button"
                onClick={() => setIndex((i) => i + 1)}
                aria-label="Next dosha"
                className="flex h-11 w-11 items-center justify-center rounded-full border border-border bg-background text-foreground transition-colors hover:border-primary/40 hover:text-primary"
              >
                <ChevronRight className="h-5 w-5" aria-hidden />
              </button>
            </div>

            {/* The other two constitutions stay in the document. */}
            <div className="sr-only">
              {doshas
                .filter((d) => d.name !== active.name)
                .map((dosha) => (
                  <div key={dosha.name}>
                    <h3>
                      {dosha.name} — {dosha.element}
                    </h3>
                    <p>{dosha.summary}</p>
                    <p>Typical traits: {dosha.traits.join(', ')}.</p>
                    <p>What keeps it balanced: {dosha.lifestyle.join(', ')}.</p>
                  </div>
                ))}
            </div>
          </div>
        ) : (
          <StaggerGroup className="mt-12 grid gap-5 md:grid-cols-3" as="ul">
            {doshas.map((dosha) => (
              <StaggerItem key={dosha.name} as="li" className="h-full">
                <DoshaCard dosha={dosha} />
              </StaggerItem>
            ))}
          </StaggerGroup>
        )}

        <Reveal className="mt-14 flex flex-col items-center text-center">
          <Magnetic>
            <Button
              size="lg"
              onClick={() => setQuizOpen(true)}
              className="rounded-full px-8 py-6 text-base font-semibold shadow-glow"
            >
              <Sparkles className="mr-2 h-5 w-5" aria-hidden />
              Take the 5-minute dosha quiz
            </Button>
          </Magnetic>
          <p className="mt-3 text-sm text-muted-foreground">
            Free, no sign-up. The result is an indication — the clinical assessment happens in consultation.
          </p>
        </Reveal>
      </div>

      <DoshaQuiz isOpen={quizOpen} onClose={() => setQuizOpen(false)} />
    </section>
  );
};

export default DoshaSection;
