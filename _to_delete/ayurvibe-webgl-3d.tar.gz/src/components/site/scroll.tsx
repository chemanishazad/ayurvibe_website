import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import {
  motion,
  useMotionValue,
  useMotionValueEvent,
  useReducedMotion,
  useScroll,
  useSpring,
  useTransform,
  useVelocity,
  type MotionValue,
} from 'framer-motion';
import { cn } from '@/lib/utils';
import { EASE } from '@/components/site/motion';

/* ===========================================================================
 * SMOOTH SCROLL
 * ========================================================================= */

interface SmoothScrollApi {
  scrollTo: (target: string | number | HTMLElement, offset?: number) => void;
  stop: () => void;
  start: () => void;
}

const SmoothScrollContext = createContext<SmoothScrollApi | null>(null);

export const useSmoothScroll = () => useContext(SmoothScrollContext);

/** Wheel deltas arrive in pixels, lines or pages depending on the device. */
const normaliseWheel = (event: WheelEvent) => {
  if (event.deltaMode === 1) return event.deltaY * 20; // lines
  if (event.deltaMode === 2) return event.deltaY * window.innerHeight; // pages
  return event.deltaY;
};

/**
 * Inertia scrolling for the public site.
 *
 * The wheel is intercepted and fed into a target position that the real window
 * scroll eases toward each frame. Because it drives the actual scroll offset —
 * rather than transforming a wrapper — framer-motion's useScroll,
 * IntersectionObserver, `position: sticky` and browser scroll restoration all
 * keep working exactly as they would natively.
 *
 * It stands down completely for:
 *  - `prefers-reduced-motion`
 *  - touch input (mobile already has good native inertia; hijacking it is worse)
 *  - open dialogs, which lock the body scroll
 * and any scroll it did not originate (keyboard, scrollbar drag, anchor jump)
 * is detected and adopted rather than fought.
 */
export const SmoothScrollProvider = ({ children }: { children: React.ReactNode }) => {
  const reduce = useReducedMotion();
  const [api, setApi] = useState<SmoothScrollApi | null>(null);

  useEffect(() => {
    if (reduce) return;
    if (typeof window === 'undefined') return;
    // Coarse pointers keep native scrolling.
    if (!window.matchMedia('(pointer: fine)').matches) return;

    const root = document.documentElement;
    let target = window.scrollY;
    let current = window.scrollY;
    let lastApplied = window.scrollY;
    let running = true;
    let frame = 0;
    let last: number | null = null;
    let idle = true;

    const maxScroll = () => Math.max(0, document.documentElement.scrollHeight - window.innerHeight);
    const clamp = (value: number) => Math.min(maxScroll(), Math.max(0, value));

    const isLocked = () =>
      document.body.hasAttribute('data-scroll-locked') ||
      document.body.style.overflow === 'hidden' ||
      root.style.overflow === 'hidden';

    const onWheel = (event: WheelEvent) => {
      if (!running || isLocked()) return;
      if (event.ctrlKey) return; // pinch-zoom
      // Let nested scrollable panes (dialog bodies, code blocks) scroll natively.
      const path = event.composedPath?.() ?? [];
      for (const node of path) {
        if (!(node instanceof HTMLElement)) continue;
        if (node === document.body || node === root) break;
        if (node.hasAttribute('data-native-scroll')) return;
        const style = getComputedStyle(node);
        const scrollable = /(auto|scroll)/.test(style.overflowY) && node.scrollHeight > node.clientHeight + 2;
        if (scrollable) return;
      }

      event.preventDefault();
      target = clamp(target + normaliseWheel(event));
      idle = false;
    };

    const onExternalScroll = () => {
      // Somebody else moved the page (keyboard, scrollbar, anchor jump, a
      // programmatic scrollTo) — adopt that position instead of yanking back.
      if (Math.abs(window.scrollY - lastApplied) > 2) {
        target = window.scrollY;
        current = window.scrollY;
        lastApplied = window.scrollY;
      }
    };

    const tick = (now: number) => {
      if (last === null) last = now;
      const delta = Math.min(now - last, 64);
      last = now;

      if (running && !isLocked()) {
        const distance = target - current;
        if (Math.abs(distance) < 0.4) {
          if (!idle) {
            current = target;
            window.scrollTo(0, current);
            lastApplied = Math.round(window.scrollY);
            idle = true;
          }
        } else {
          // Frame-rate independent exponential ease.
          current += distance * (1 - Math.exp(-delta / 105));
          window.scrollTo(0, current);
          lastApplied = Math.round(window.scrollY);
          idle = false;
        }
      }
      frame = requestAnimationFrame(tick);
    };

    const onResize = () => {
      target = clamp(target);
    };

    window.addEventListener('wheel', onWheel, { passive: false });
    window.addEventListener('scroll', onExternalScroll, { passive: true });
    window.addEventListener('resize', onResize);
    frame = requestAnimationFrame(tick);
    root.classList.add('smooth-scroll-active');

    setApi({
      scrollTo: (to, offset = -88) => {
        let destination: number | null = null;
        if (typeof to === 'number') destination = to;
        else {
          const el = typeof to === 'string' ? document.querySelector<HTMLElement>(to) : to;
          if (el) destination = el.getBoundingClientRect().top + window.scrollY + offset;
        }
        if (destination === null) return;
        target = clamp(destination);
        idle = false;
      },
      stop: () => {
        running = false;
      },
      start: () => {
        target = window.scrollY;
        current = window.scrollY;
        running = true;
      },
    });

    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener('wheel', onWheel);
      window.removeEventListener('scroll', onExternalScroll);
      window.removeEventListener('resize', onResize);
      root.classList.remove('smooth-scroll-active');
      setApi(null);
    };
  }, [reduce]);

  const fallback = useMemo<SmoothScrollApi>(
    () => ({
      scrollTo: (to, offset = -88) => {
        if (typeof to === 'number') {
          window.scrollTo({ top: to, behavior: 'smooth' });
          return;
        }
        const el = typeof to === 'string' ? document.querySelector<HTMLElement>(to) : to;
        if (el) {
          window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY + offset, behavior: 'smooth' });
        }
      },
      stop: () => undefined,
      start: () => undefined,
    }),
    []
  );

  return <SmoothScrollContext.Provider value={api ?? fallback}>{children}</SmoothScrollContext.Provider>;
};

/* ===========================================================================
 * 3D PRIMITIVES
 * ========================================================================= */

/**
 * Tracks the pointer inside an element and returns normalised -0.5..0.5 values,
 * spring-smoothed, for driving perspective transforms.
 */
export const usePointerTilt = (strength = 1) => {
  const ref = useRef<HTMLDivElement>(null);
  const reduce = useReducedMotion();
  const rawX = useMotionValue(0);
  const rawY = useMotionValue(0);
  const x = useSpring(rawX, { stiffness: 120, damping: 20, mass: 0.6 });
  const y = useSpring(rawY, { stiffness: 120, damping: 20, mass: 0.6 });

  useEffect(() => {
    const el = ref.current;
    if (!el || reduce) return;
    // Only devices with a real pointer get tilt; touch has nothing to track.
    if (!window.matchMedia('(pointer: fine)').matches) return;

    const onMove = (event: PointerEvent) => {
      const rect = el.getBoundingClientRect();
      rawX.set(((event.clientX - rect.left) / rect.width - 0.5) * strength);
      rawY.set(((event.clientY - rect.top) / rect.height - 0.5) * strength);
    };
    const onLeave = () => {
      rawX.set(0);
      rawY.set(0);
    };

    el.addEventListener('pointermove', onMove);
    el.addEventListener('pointerleave', onLeave);
    return () => {
      el.removeEventListener('pointermove', onMove);
      el.removeEventListener('pointerleave', onLeave);
    };
  }, [rawX, rawY, reduce, strength]);

  return { ref, x, y };
};

/**
 * A perspective stage. Children placed inside can use translateZ / Depth to sit
 * at different distances from the camera, and the whole scene tilts toward the
 * pointer.
 */
export const Stage3D = ({
  children,
  className,
  perspective = 1400,
  maxRotate = 7,
}: {
  children: React.ReactNode;
  className?: string;
  perspective?: number;
  maxRotate?: number;
}) => {
  const { ref, x, y } = usePointerTilt();
  const rotateY = useTransform(x, (v) => v * maxRotate * 2);
  const rotateX = useTransform(y, (v) => -v * maxRotate * 2);

  return (
    <div ref={ref} className={cn('relative', className)} style={{ perspective }}>
      <motion.div style={{ rotateX, rotateY, transformStyle: 'preserve-3d' }} className="relative h-full w-full">
        {children}
      </motion.div>
    </div>
  );
};

/** Positions a child at a given depth inside a Stage3D. */
export const Depth = ({
  z = 0,
  children,
  className,
  style,
}: {
  z?: number;
  children: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
}) => (
  <div
    className={className}
    style={{ transform: `translateZ(${z}px)`, transformStyle: 'preserve-3d', ...style }}
  >
    {children}
  </div>
);

/* ===========================================================================
 * SCROLL-LINKED PRIMITIVES
 * ========================================================================= */

/** Progress 0→1 while `ref` travels through the viewport. */
export const useTravelProgress = (ref: React.RefObject<HTMLElement>) => {
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start end', 'end start'] });
  return scrollYProgress;
};

/** Vertical parallax driven by scroll, in pixels. */
export const Parallax = ({
  children,
  distance = 80,
  className,
  as = 'div',
}: {
  children: React.ReactNode;
  distance?: number;
  className?: string;
  as?: 'div' | 'span';
}) => {
  const ref = useRef<HTMLDivElement>(null);
  const reduce = useReducedMotion();
  const progress = useTravelProgress(ref);
  const raw = useTransform(progress, [0, 1], [distance, -distance]);
  const y = useSpring(raw, { stiffness: 90, damping: 26, restDelta: 0.4 });
  const Tag = as === 'span' ? motion.span : motion.div;

  return (
    <div ref={ref} className={className}>
      <Tag style={reduce ? undefined : { y }} className="will-change-transform">
        {children}
      </Tag>
    </div>
  );
};

/**
 * Wipes content in with a clip-path as it enters the viewport — the reveal used
 * for large imagery on editorial sites.
 */
export const ClipReveal = ({
  children,
  className,
  direction = 'up',
  delay = 0,
  duration = 1.1,
}: {
  children: React.ReactNode;
  className?: string;
  direction?: 'up' | 'left' | 'right';
  delay?: number;
  duration?: number;
}) => {
  const reduce = useReducedMotion();
  if (reduce) return <div className={className}>{children}</div>;

  const from =
    direction === 'up'
      ? 'inset(100% 0% 0% 0%)'
      : direction === 'left'
        ? 'inset(0% 0% 0% 100%)'
        : 'inset(0% 100% 0% 0%)';

  // The in-view trigger lives on an *unclipped* wrapper. Observing the clipped
  // element itself is unreliable — a fully clipped box can report as not
  // intersecting, and the reveal then never fires.
  return (
    <motion.div
      className={className}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, amount: 0.25 }}
    >
      <motion.div
        variants={{
          hidden: { clipPath: from, opacity: 0.35, scale: 1.05 },
          show: {
            clipPath: 'inset(0% 0% 0% 0%)',
            opacity: 1,
            scale: 1,
            transition: { duration, delay, ease: EASE },
          },
        }}
        className="h-full w-full"
      >
        {children}
      </motion.div>
    </motion.div>
  );
};

/**
 * Pins a section for `steps * viewport` of scrolling and reports which step is
 * active, so a scene can advance as the visitor scrolls. Falls back to a plain
 * stacked layout for reduced motion and narrow screens (where pinning fights
 * mobile browser chrome).
 */
export const usePinnedSteps = (steps: number, { enabled = true }: { enabled?: boolean } = {}) => {
  const ref = useRef<HTMLDivElement>(null);
  const reduce = useReducedMotion();
  const [isWide, setIsWide] = useState(false);
  const [active, setActive] = useState(0);

  useEffect(() => {
    const mq = window.matchMedia('(min-width: 1024px)');
    const update = () => setIsWide(mq.matches);
    update();
    mq.addEventListener('change', update);
    return () => mq.removeEventListener('change', update);
  }, []);

  const pinned = enabled && isWide && !reduce;
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start start', 'end end'] });

  useMotionValueEvent(scrollYProgress, 'change', (value) => {
    if (!pinned) return;
    const next = Math.min(steps - 1, Math.max(0, Math.floor(value * steps * 0.999)));
    setActive((current) => (current === next ? current : next));
  });

  return { ref, pinned, active, setActive, progress: scrollYProgress };
};

/**
 * Turns vertical scrolling into horizontal travel across a pinned track.
 * Disabled below lg and under reduced motion, where the track becomes a normal
 * swipeable row.
 */
export const HorizontalScroller = ({
  children,
  className,
  trackClassName,
  ariaLabel,
  header,
}: {
  children: React.ReactNode;
  className?: string;
  trackClassName?: string;
  ariaLabel?: string;
  /** Rendered inside the pinned viewport, above the track. */
  header?: (progress: MotionValue<number>) => React.ReactNode;
}) => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const reduce = useReducedMotion();
  const [isWide, setIsWide] = useState(false);
  const [travel, setTravel] = useState(0);

  useEffect(() => {
    const mq = window.matchMedia('(min-width: 1024px)');
    const update = () => setIsWide(mq.matches);
    update();
    mq.addEventListener('change', update);
    return () => mq.removeEventListener('change', update);
  }, []);

  const active = isWide && !reduce;

  // Measure how far the track has to move so the last card lands flush right.
  useLayoutEffect(() => {
    if (!active) {
      setTravel(0);
      return;
    }
    const measure = () => {
      const track = trackRef.current;
      if (!track) return;
      setTravel(Math.max(0, track.scrollWidth - window.innerWidth + 96));
    };
    measure();
    const observer = new ResizeObserver(measure);
    if (trackRef.current) observer.observe(trackRef.current);
    window.addEventListener('resize', measure);
    return () => {
      observer.disconnect();
      window.removeEventListener('resize', measure);
    };
  }, [active, children]);

  const { scrollYProgress } = useScroll({ target: sectionRef, offset: ['start start', 'end end'] });
  const rawX = useTransform(scrollYProgress, [0, 1], [0, -travel]);
  const x = useSpring(rawX, { stiffness: 120, damping: 30, restDelta: 0.5 });

  if (!active) {
    return (
      <div className={cn('edge-fade overflow-x-auto px-5 pb-4 sm:px-8', className)}>
        <div className={cn('flex gap-5', trackClassName)} aria-label={ariaLabel}>
          {children}
        </div>
      </div>
    );
  }

  return (
    <div ref={sectionRef} style={{ height: `calc(100vh + ${travel}px)` }} className={className}>
      <div className="sticky top-0 flex h-screen flex-col justify-center gap-8 overflow-hidden pt-20">
        {header ? <div className="shrink-0">{header(scrollYProgress)}</div> : null}
        <motion.div
          ref={trackRef}
          style={{ x }}
          className={cn('flex gap-6 pl-[max(1.25rem,calc((100vw-80rem)/2+2rem))] pr-24 will-change-transform', trackClassName)}
          aria-label={ariaLabel}
        >
          {children}
        </motion.div>
      </div>
    </div>
  );
};

/**
 * Marquee whose speed and skew respond to scroll velocity — it leans into the
 * direction you are scrolling and settles when you stop.
 */
export const VelocityMarquee = ({
  children,
  baseSpeed = 40,
  className,
  reverse = false,
}: {
  children: React.ReactNode;
  /** Pixels per second at rest. */
  baseSpeed?: number;
  className?: string;
  reverse?: boolean;
}) => {
  const reduce = useReducedMotion();
  const { scrollY } = useScroll();
  const scrollVelocity = useVelocity(scrollY);
  const smoothVelocity = useSpring(scrollVelocity, { stiffness: 320, damping: 46 });
  const skew = useTransform(smoothVelocity, [-2500, 0, 2500], [-4, 0, 4], { clamp: true });
  const boost = useTransform(smoothVelocity, [-2500, 0, 2500], [3, 1, 3], { clamp: true });

  const trackRef = useRef<HTMLDivElement>(null);
  const x = useMotionValue(0);
  const widthRef = useRef(0);
  const direction = reverse ? 1 : -1;

  useLayoutEffect(() => {
    const measure = () => {
      if (trackRef.current) widthRef.current = trackRef.current.scrollWidth / 2;
    };
    measure();
    const observer = new ResizeObserver(measure);
    if (trackRef.current) observer.observe(trackRef.current);
    return () => observer.disconnect();
  }, [children]);

  useEffect(() => {
    if (reduce) return;
    let frame = 0;
    let last: number | null = null;
    const step = (now: number) => {
      if (last === null) last = now;
      const delta = Math.min(now - last, 64) / 1000;
      last = now;
      const width = widthRef.current || 1;
      let next = x.get() + direction * baseSpeed * boost.get() * delta;
      // Wrap seamlessly: the track renders its children twice.
      if (next <= -width) next += width;
      if (next >= 0 && direction === 1) next -= width;
      x.set(next);
      frame = requestAnimationFrame(step);
    };
    frame = requestAnimationFrame(step);
    return () => cancelAnimationFrame(frame);
  }, [baseSpeed, boost, direction, reduce, x]);

  return (
    <div className={cn('overflow-hidden', className)}>
      <motion.div style={reduce ? undefined : { skewX: skew }}>
        <motion.div
          ref={trackRef}
          style={reduce ? undefined : { x }}
          className="flex w-max will-change-transform"
        >
          {children}
          {children}
        </motion.div>
      </motion.div>
    </div>
  );
};

/* ===========================================================================
 * INTERACTION
 * ========================================================================= */

/** Button/link wrapper that leans toward the cursor. */
export const Magnetic = ({
  children,
  className,
  strength = 14,
}: {
  children: React.ReactNode;
  className?: string;
  strength?: number;
}) => {
  const ref = useRef<HTMLDivElement>(null);
  const reduce = useReducedMotion();
  const x = useSpring(0, { stiffness: 260, damping: 18 });
  const y = useSpring(0, { stiffness: 260, damping: 18 });

  const onMove = (event: React.PointerEvent<HTMLDivElement>) => {
    if (reduce || event.pointerType !== 'mouse') return;
    const rect = ref.current?.getBoundingClientRect();
    if (!rect) return;
    x.set(((event.clientX - rect.left) / rect.width - 0.5) * strength * 2);
    y.set(((event.clientY - rect.top) / rect.height - 0.5) * strength);
  };

  return (
    <motion.div
      ref={ref}
      onPointerMove={onMove}
      onPointerLeave={() => {
        x.set(0);
        y.set(0);
      }}
      style={reduce ? undefined : { x, y }}
      className={cn('inline-flex', className)}
      data-cursor="grow"
    >
      {children}
    </motion.div>
  );
};

/** Scroll-linked value helper for one-off transforms inside components. */
export const useSectionTransform = (
  ref: React.RefObject<HTMLElement>,
  outputRange: [number, number],
  offset: ['start end' | 'start start' | 'start center', 'end start' | 'end end' | 'center start'] = [
    'start end',
    'end start',
  ]
): MotionValue<number> => {
  const { scrollYProgress } = useScroll({ target: ref, offset });
  return useTransform(scrollYProgress, [0, 1], outputRange);
};

/** Stable callback that scrolls to a selector through the smooth-scroll engine. */
export const useScrollToSection = () => {
  const smooth = useSmoothScroll();
  return useCallback(
    (selector: string) => {
      const el = document.querySelector<HTMLElement>(selector);
      if (el) smooth?.scrollTo(el);
    },
    [smooth]
  );
};
