import React, { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { AnimatePresence, motion, useReducedMotion, useScroll, useTransform } from 'framer-motion';
import { ArrowRight, BadgeCheck, CalendarDays, MousePointer2, Phone, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { clinic, doctor, heroImage, heroSlides, heroSrcSet, sceneImage, sceneSrcSet, trustPoints } from '@/data/site';
import { EASE } from '@/components/site/motion';
import { Magnetic, useScrollToSection } from '@/components/site/scroll';

const SLIDE_MS = 6000;

/**
 * Hero scene.
 *
 * Three things happen here:
 *  1. A perspective stage tilts the whole composition toward the pointer, with
 *     the image card, badges and orbs sitting at different translateZ depths.
 *  2. Scroll drives the scene away — copy rises and fades, the card recedes and
 *     blurs — so the page feels like a camera pulling back rather than a list.
 *  3. The gallery cross-fades through five clinical frames. Frame one is the
 *     preloaded LCP image; the <h1> never changes, so crawlers see one heading.
 */
const Hero = () => {
  const [index, setIndex] = useState(0);
  const [previous, setPrevious] = useState<number | null>(null);
  const [paused, setPaused] = useState(false);
  const [scrolling, setScrolling] = useState(false);
  const reduce = useReducedMotion();
  const sectionRef = useRef<HTMLElement>(null);
  const scrollTo = useScrollToSection();

  const { scrollYProgress } = useScroll({ target: sectionRef, offset: ['start start', 'end start'] });
  const cardY = useTransform(scrollYProgress, [0, 1], [0, 55]);
  const insetY = useTransform(scrollYProgress, [0, 1], [0, -34]);
  const sealY = useTransform(scrollYProgress, [0, 1], [0, 22]);

  // Crossfading two full-bleed photographs is the most expensive thing this
  // section does. Never do it while the visitor is scrolling.
  useEffect(() => {
    let timer = 0;
    const onScroll = () => {
      setScrolling(true);
      window.clearTimeout(timer);
      timer = window.setTimeout(() => setScrolling(false), 220);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', onScroll);
      window.clearTimeout(timer);
    };
  }, []);

  useEffect(() => {
    if (paused || reduce || scrolling) return;
    const timer = window.setInterval(() => {
      setIndex((i) => {
        setPrevious(i);
        return (i + 1) % heroSlides.length;
      });
    }, SLIDE_MS);
    return () => window.clearInterval(timer);
  }, [paused, reduce, scrolling]);

  const goTo = (next: number) => {
    setPrevious(index);
    setIndex(next);
  };

  const slide = heroSlides[index];
  const motionStyle = (style: Record<string, unknown>) => (reduce ? undefined : style);

  return (
    <section
      id="hero-section"
      ref={sectionRef}
      aria-labelledby="hero-heading"
      className="relative overflow-hidden bg-background pt-28 sm:pt-32 lg:pt-36"
    >
      {/* Ambient backdrop. Static gradients + one slow CSS animation: painted
          once, then composited — nothing recalculates while you scroll. */}
      <div aria-hidden className="hero-wash pointer-events-none absolute inset-0" />

      <div className="shell relative grid items-center gap-12 pb-20 lg:grid-cols-[1.05fr_1fr] lg:gap-16 lg:pb-28">
        {/* ---------------------------------------------------------------- */}
        {/* Copy                                                             */}
        {/* ---------------------------------------------------------------- */}
        <div className="max-w-2xl">
          <motion.span
            initial={reduce ? false : { opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: EASE }}
            className="eyebrow"
          >
            <BadgeCheck className="h-3.5 w-3.5" aria-hidden />
            Government certified · Reg. No. {clinic.regNo}
          </motion.span>

          {/* Word-by-word 3D headline: each word rotates up from below. */}
          <h1
            id="hero-heading"
            className="mt-5 font-display text-[2.35rem] font-extrabold leading-[1.06] text-foreground sm:text-5xl lg:text-[3.65rem]"
          >
            <motion.span
              className="inline-block"
              initial={reduce ? false : 'hidden'}
              animate="show"
              variants={{ show: { transition: { staggerChildren: 0.08, delayChildren: 0.08 } } }}
            >
              {['Authentic', 'Ayurveda', 'hospital', 'in'].map((word) => (
                <span key={word} className="inline-block overflow-hidden pb-[0.14em] align-bottom">
                  <motion.span
                    className="inline-block"
                    variants={{
                      hidden: { y: '108%' },
                      show: { y: 0, transition: { duration: 0.75, ease: EASE } },
                    }}
                  >
                    {word}&nbsp;
                  </motion.span>
                </span>
              ))}
              <span className="relative inline-block overflow-hidden pb-[0.14em] align-bottom">
                <motion.span
                  className="relative inline-block whitespace-nowrap text-primary"
                  variants={{
                    hidden: { y: '108%' },
                    show: { y: 0, transition: { duration: 0.75, ease: EASE } },
                  }}
                >
                  Chennai
                </motion.span>
                <svg
                  aria-hidden
                  viewBox="0 0 300 12"
                  preserveAspectRatio="none"
                  className="absolute bottom-[0.05em] left-0 h-2.5 w-full text-primary/35"
                >
                  <motion.path
                    d="M2 8 C 80 2, 220 2, 298 7"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="4"
                    strokeLinecap="round"
                    initial={reduce ? false : { pathLength: 0 }}
                    animate={{ pathLength: 1 }}
                    transition={{ duration: 0.9, delay: 0.65, ease: EASE }}
                  />
                </svg>
              </span>
            </motion.span>
          </h1>

          {/* This paragraph is the largest element in the viewport, i.e. the LCP
              candidate. It animates with transform + blur only — an opacity
              fade would make the browser treat it as unpainted and push LCP out
              by the length of the animation. */}
          <motion.p
            initial={reduce ? false : { y: 18, filter: 'blur(5px)' }}
            animate={{ y: 0, filter: 'blur(0px)' }}
            transition={{ duration: 0.55, delay: 0.18, ease: EASE }}
            className="mt-6 text-lg leading-relaxed text-muted-foreground sm:text-xl"
          >
            Classical Panchakarma, Abhyanga and Shirodhara at Nookampalayam, Perumbakkam — every
            plan written by {doctor.name}, {doctor.qualification}, after a full constitutional
            assessment. No packages sold before a diagnosis.
          </motion.p>

          <motion.div
            initial={reduce ? false : { opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.45, ease: EASE }}
            className="mt-8 flex flex-col gap-3 sm:flex-row"
          >
            <Magnetic>
              <Button asChild size="lg" className="group h-12 rounded-full px-7 text-base font-semibold shadow-glow sm:h-[3.25rem]">
                <Link to="/booking">
                  <CalendarDays className="mr-2 h-5 w-5" aria-hidden />
                  Book a consultation
                  <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" aria-hidden />
                </Link>
              </Button>
            </Magnetic>
            <Magnetic strength={10}>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="h-12 rounded-full border-border px-7 text-base font-semibold hover:border-primary/40 hover:text-primary sm:h-[3.25rem]"
              >
                <a href={`tel:${clinic.phone}`}>
                  <Phone className="mr-2 h-5 w-5 text-primary" aria-hidden />
                  {clinic.phoneDisplay}
                </a>
              </Button>
            </Magnetic>
          </motion.div>

          <motion.ul
            initial="hidden"
            animate="show"
            variants={{ show: { transition: { staggerChildren: 0.09, delayChildren: 0.6 } } }}
            className="mt-9 grid gap-x-6 gap-y-4 border-t border-border pt-6 sm:grid-cols-3"
          >
            {trustPoints.map((point) => (
              <motion.li
                key={point.label}
                variants={{ hidden: { opacity: 0, y: 12 }, show: { opacity: 1, y: 0 } }}
                transition={{ duration: 0.5, ease: EASE }}
              >
                <p className="flex items-center gap-1.5 text-sm font-semibold text-foreground">
                  <BadgeCheck className="h-4 w-4 text-primary" aria-hidden />
                  {point.label}
                </p>
                <p className="mt-0.5 pl-[1.375rem] text-xs text-muted-foreground">{point.detail}</p>
              </motion.li>
            ))}
          </motion.ul>
        </div>

        {/* ---------------------------------------------------------------- */}
        {/* 3D gallery                                                       */}
        {/* ---------------------------------------------------------------- */}
        <motion.div
          style={motionStyle({ y: cardY })}
          initial={reduce ? false : { opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.15, ease: EASE }}
          onMouseEnter={() => setPaused(true)}
          onMouseLeave={() => setPaused(false)}
          onFocusCapture={() => setPaused(true)}
          onBlurCapture={() => setPaused(false)}
        >
          <div className="relative">
            {/* Hairline frame, offset and turned a degree and a half. Depth for
                the cost of one border. */}
            <span
              aria-hidden
              className="pointer-events-none absolute -inset-3 hidden rotate-[1.5deg] rounded-[2.2rem] border border-primary/20 sm:block"
            />
            <span
              aria-hidden
              className="pointer-events-none absolute -inset-1.5 hidden -rotate-[0.8deg] rounded-[2rem] border border-saffron/20 sm:block"
            />

            <div className="relative">
              <div className="relative aspect-[4/5] overflow-hidden rounded-[1.75rem] border border-border bg-muted shadow-warm sm:aspect-[5/4] lg:aspect-[4/5]">
                {heroSlides.map((s, i) => {
                  // Mount only what is on screen: the current frame and the one
                  // fading out behind it.
                  if (i !== index && i !== previous) return null;
                  return (
                  <img
                    key={s.id}
                    src={heroImage(s.id, 1100)}
                    srcSet={heroSrcSet(s.id)}
                    sizes="(min-width: 1024px) 44vw, 100vw"
                    alt={s.alt}
                    width={1100}
                    height={1375}
                    loading={i === 0 ? 'eager' : 'lazy'}
                    // @ts-expect-error fetchpriority is a valid HTML attribute React 18 forwards as-is
                    fetchpriority={i === 0 ? 'high' : undefined}
                    decoding={i === 0 ? 'sync' : 'async'}
                    className={cn(
                      'absolute inset-0 h-full w-full object-cover transition-opacity duration-[900ms]',
                      i === index ? 'opacity-100' : 'opacity-0'
                    )}
                  />
                  );
                })}

                <div aria-hidden className="absolute inset-0 bg-gradient-to-t from-foreground/85 via-foreground/15 to-transparent" />

                <div className="absolute inset-x-0 bottom-0 p-5 sm:p-7">
                  <AnimatePresence mode="wait">
                    <motion.div
                      key={slide.id}
                      initial={reduce ? false : { opacity: 0, y: 18, filter: 'blur(6px)' }}
                      animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
                      exit={reduce ? undefined : { opacity: 0, y: -14, filter: 'blur(6px)' }}
                      transition={{ duration: 0.5, ease: EASE }}
                    >
                      <p className="text-xs font-semibold uppercase tracking-[0.16em] text-white/70">{slide.label}</p>
                      <p className="mt-1.5 font-display text-xl font-bold text-white sm:text-2xl">{slide.heading}</p>
                      <p className="mt-1 text-sm text-white/80">{slide.caption}</p>
                    </motion.div>
                  </AnimatePresence>

                  <div className="mt-5 flex gap-1.5" role="tablist" aria-label="Hero gallery">
                    {heroSlides.map((s, i) => (
                      <button
                        key={s.id}
                        type="button"
                        role="tab"
                        aria-selected={i === index}
                        aria-label={s.label}
                        onClick={() => goTo(i)}
                        className="group relative h-1 flex-1 overflow-hidden rounded-full bg-white/25"
                      >
                        <span
                          className={cn(
                            'absolute inset-y-0 left-0 rounded-full bg-white transition-[width] ease-linear',
                            i === index ? 'w-full' : 'w-0 group-hover:w-1/4'
                          )}
                          style={
                            i === index && !reduce && !paused
                              ? { animation: `hero-progress ${SLIDE_MS}ms linear` }
                              : undefined
                          }
                        />
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Second frame: a therapy close-up overlapping the corner, moving
                against the main card as you scroll. */}
            <motion.div
              style={motionStyle({ y: insetY })}
              initial={reduce ? false : { opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.55, ease: EASE }}
              className="absolute -left-8 top-[47%] hidden w-36 overflow-hidden rounded-2xl border-4 border-background shadow-warm sm:block lg:-left-14 lg:w-44"
            >
              <img
                src={sceneImage('shirodhara', 900)}
                srcSet={sceneSrcSet('shirodhara')}
                sizes="12rem"
                alt="Shirodhara therapy in progress at Sri Vinayaga Ayurvibe, Perumbakkam"
                width={900}
                height={675}
                loading="lazy"
                decoding="async"
                className="aspect-[4/5] w-full object-cover"
              />
            </motion.div>

            {/* Certification seal */}
            <motion.div
              style={motionStyle({ y: sealY })}
              initial={reduce ? false : { opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.95, ease: EASE }}
              className="absolute bottom-[26%] right-3 hidden h-24 w-24 place-items-center rounded-full border border-border bg-background shadow-warm sm:grid lg:-right-9"
            >
              <svg viewBox="0 0 100 100" className="seal-spin absolute inset-0 h-full w-full" aria-hidden>
                <defs>
                  <path id="seal-ring" d="M50 12a38 38 0 1 1 0 76 38 38 0 1 1 0-76" fill="none" />
                </defs>
                <text className="fill-muted-foreground text-[8px] font-semibold uppercase tracking-[0.2em]">
                  <textPath href="#seal-ring" startOffset="0">
                    {'\u00a0Government certified\u00a0·\u00a0Reg. 2095\u00a0·'}
                  </textPath>
                </text>
              </svg>
              <BadgeCheck className="h-8 w-8 text-primary" aria-hidden />
            </motion.div>

            {/* Rating card floats over the image */}
            <div className="absolute left-2 top-[22%] hidden w-52 -translate-y-1/2 sm:block lg:-left-14">
              <motion.figure
                initial={reduce ? false : { opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.7, ease: EASE }}
                className="rounded-2xl border border-border bg-background p-4 shadow-warm"
              >
                <div className="flex items-center gap-1" aria-hidden>
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-saffron text-saffron" />
                  ))}
                </div>
                <figcaption className="mt-2 text-sm font-semibold text-foreground">
                  {clinic.ratingValue} out of 5
                </figcaption>
                <p className="text-xs text-muted-foreground">{clinic.reviewCount} Google reviews</p>
              </motion.figure>
            </div>

            {/* Doctor card */}
            <div className="absolute -right-3 top-8 hidden max-w-[13rem] lg:block xl:-right-8">
              <motion.div
                initial={reduce ? false : { opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.85, ease: EASE }}
                className="rounded-2xl border border-border bg-background p-4 shadow-warm"
              >
                <p className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-primary">
                  <span className="h-2 w-2 rounded-full bg-primary pulse-dot" aria-hidden />
                  Consulting today
                </p>
                <p className="mt-2 text-sm font-semibold text-foreground">{doctor.name}</p>
                <p className="text-xs text-muted-foreground">
                  {doctor.qualification} · {doctor.role}
                </p>
              </motion.div>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Scroll cue */}
      <button
        type="button"
        onClick={() => scrollTo('#treatments')}
        className="group absolute bottom-6 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-1.5 text-xs font-medium uppercase tracking-[0.2em] text-muted-foreground lg:flex"
      >
        <MousePointer2 className="h-4 w-4 text-primary transition-transform group-hover:translate-y-0.5" aria-hidden />
        Scroll to explore
        <span className="mt-1 block h-8 w-[1px] overflow-hidden bg-border">
          <span className="scroll-cue block h-4 w-full bg-primary" />
        </span>
      </button>

      <style>{`@keyframes hero-progress { from { width: 0% } to { width: 100% } }`}</style>
    </section>
  );
};

export default Hero;
