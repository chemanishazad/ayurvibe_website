#!/usr/bin/env node
/**
 * Builds the medallion artwork.
 *
 * The exploded scenes label everything they open — sixty-two subjects, from
 * Haritaki to a wall calendar. Drawn as flat line icons they read as an icon
 * set; what the scenes need is a small illustration of the thing.
 *
 * So each subject is composed here and rasterised:
 *
 *   1. line work is taken from two sources — the hand-drawn botanicals in
 *      src/components/site/apothecary/Botanicals.tsx (parsed, so the drawings
 *      are never transcribed twice) and the icon set already in the bundle
 *      (read straight out of node_modules, so nothing is redrawn by hand),
 *   2. it is painted: a two-stop gradient along the stroke, a translucent
 *      interior, a dropped shadow copy behind and a light rim on top,
 *   3. each subject gets its own palette, because turmeric is not the same
 *      colour as rock salt and a set where everything is one green is exactly
 *      what makes an icon set look like an icon set,
 *   4. it is written out as a transparent WebP, so the medallion's own plate
 *      still supplies the background and one file works on the light sections
 *      and the dark ones.
 *
 * Output:  src/assets/marks/<id>.webp   (160px, transparent)
 * Usage:   npm run marks
 */
import { readFileSync, readdirSync, mkdirSync, existsSync, statSync } from 'fs';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT = dirname(__dirname);
const OUT = join(ROOT, 'src/assets/marks');
const BOTANICALS = join(ROOT, 'src/components/site/apothecary/Botanicals.tsx');
const LUCIDE = join(ROOT, 'node_modules/lucide-react/dist/esm/icons');

let sharp;
try {
  ({ default: sharp } = await import('sharp'));
} catch {
  console.error('[marks] `sharp` is not installed. Run `npm install` and try again.');
  process.exit(1);
}

/* -- palettes -------------------------------------------------------------
 * Mid-tone by design: these sit on a near-black section and a near-white one,
 * so nothing can be as pale as the dark tone would like or as deep as the
 * light tone would.
 */
const P = {
  herb:  { l: '#A6DBA0', d: '#3C8551', f1: '#63A874', f2: '#2F6B44' },
  deep:  { l: '#84CB9E', d: '#2C6B48', f1: '#4E9A6A', f2: '#265A3C' },
  amber: { l: '#F4C879', d: '#B9762A', f1: '#E0A34C', f2: '#A9691F' },
  gold:  { l: '#F7DC90', d: '#C08A22', f1: '#E8C05C', f2: '#A8761A' },
  clay:  { l: '#E6A587', d: '#9C4F31', f1: '#C87A56', f2: '#8B4127' },
  rust:  { l: '#EC9E76', d: '#A34A22', f1: '#CE7040', f2: '#8E3C17' },
  stone: { l: '#E2E8E3', d: '#87938C', f1: '#B9C4BD', f2: '#7C8A83' },
  cloud: { l: '#DCE8F1', d: '#7C93A6', f1: '#AFC5D6', f2: '#6E8698' },
  water: { l: '#AFD7EB', d: '#3C7A9B', f1: '#72AECD', f2: '#316A88' },
  fire:  { l: '#FDD095', d: '#C4451F', f1: '#EE8A3C', f2: '#AE3A16' },
  berry: { l: '#EEA6AC', d: '#9E3946', f1: '#CE6470', f2: '#8B2C39' },
  ink:   { l: '#C1CDD4', d: '#4E5F69', f1: '#8595A0', f2: '#43545E' },
};

/** Which palette each subject is painted in. */
const PALETTE = {
  // botanicals
  root: 'clay', leaf: 'herb', sprig: 'herb', berry: 'deep', fruit: 'clay',
  seed: 'stone', rhizome: 'gold', flower: 'berry', bark: 'clay', resin: 'amber',
  oil: 'amber', milk: 'stone', honey: 'gold', ghee: 'gold', salt: 'stone',
  grain: 'clay', pod: 'herb', thread: 'stone', wood: 'clay', pepper: 'clay',
  // everything else
  wind: 'cloud', waves: 'water', syringe: 'ink', droplets: 'water', droplet: 'amber',
  feather: 'stone', snowflake: 'water', moon: 'cloud', flame: 'fire', sun: 'gold',
  target: 'rust', thermometer: 'rust', spark: 'fire', anchor: 'ink', hourglass: 'clay',
  bed: 'stone', mountain: 'deep', cloud: 'cloud', pulse: 'rust', eye: 'water',
  clipboard: 'stone', compass: 'deep', checklist: 'deep', pill: 'amber', plate: 'clay',
  calendar: 'stone', clock: 'stone', door: 'clay', people: 'deep', stethoscope: 'water',
  trend: 'deep', sliders: 'stone', sunrise: 'gold', battery: 'amber', rain: 'cloud',
  bone: 'stone', activity: 'deep', foot: 'clay', scale: 'clay', gauge: 'ink',
  ring: 'berry', repeat: 'stone', baby: 'berry', shoot: 'herb', shield: 'deep',
};

/** Mark id -> icon-set filename, for the conceptual subjects. */
const ICON_FILE = {
  wind: 'wind', waves: 'waves', syringe: 'syringe', droplets: 'droplets', droplet: 'droplet',
  feather: 'feather', snowflake: 'snowflake', moon: 'moon', flame: 'flame', sun: 'sun',
  target: 'target', thermometer: 'thermometer', spark: 'zap', anchor: 'anchor',
  hourglass: 'hourglass', bed: 'bed', mountain: 'mountain', cloud: 'cloud',
  pulse: 'activity', eye: 'eye', clipboard: 'clipboard-list', compass: 'compass',
  checklist: 'list-checks', pill: 'pill', plate: 'utensils-crossed',
  calendar: 'calendar-days', clock: 'clock', door: 'door-closed', people: 'users',
  stethoscope: 'stethoscope', trend: 'trending-up', sliders: 'settings-2',
  sunrise: 'sunrise', battery: 'battery-low', rain: 'cloud-rain', bone: 'bone',
  activity: 'check-check', foot: 'footprints', scale: 'scale', gauge: 'gauge',
  ring: 'repeat', repeat: 'repeat', baby: 'baby', shoot: 'sprout', shield: 'shield',
};

/* -- source 1: the hand-drawn botanicals --------------------------------- */

/** JSX attribute syntax -> SVG attribute syntax. */
const jsxToSvg = (markup) =>
  markup
    .replace(/fill=\{FILL\}/g, 'fill="INTERIOR"')
    .replace(/\{FILL\}/g, '"INTERIOR"')
    .replace(/([a-z]+[A-Z][a-zA-Z]*)=\{([^}]*)\}/g, (_, name, value) => {
      const attr = name.replace(/[A-Z]/g, (c) => `-${c.toLowerCase()}`);
      return `${attr}="${value.replace(/['"]/g, '').trim()}"`;
    })
    .replace(/\s+/g, ' ')
    .trim();

const readBotanicals = () => {
  const src = readFileSync(BOTANICALS, 'utf8');
  const body = src.slice(src.indexOf('const glyphs'), src.indexOf('/** One ink drawing'));
  const out = {};
  // Each entry is `name: (\n <>...</>\n ),`
  const re = /^\s{2}(?:\/\*[\s\S]*?\*\/\s*)?([a-z]+):\s*\(\s*<>([\s\S]*?)<\/>\s*\),/gm;
  let m;
  while ((m = re.exec(body))) out[m[1]] = jsxToSvg(m[2]);
  return out;
};

/* -- source 2: the icon set --------------------------------------------- */

const readIcon = (file) => {
  const path = join(LUCIDE, `${file}.js`);
  if (!existsSync(path)) throw new Error(`icon not found: ${file}`);
  const src = readFileSync(path, 'utf8');
  const list = src.slice(src.indexOf('", ['), src.lastIndexOf(']);'));
  const nodes = [...list.matchAll(/\[\s*"(\w[\w-]*)"\s*,\s*\{([^}]*)\}\s*\]/g)];
  if (!nodes.length) throw new Error(`no nodes parsed: ${file}`);
  return nodes
    .map(([, tag, attrs]) => {
      const pairs = [...attrs.matchAll(/([\w-]+):\s*(?:"([^"]*)"|([\d.-]+))/g)]
        .filter(([, name]) => name !== 'key')
        .map(([, name, str, num]) => `${name}="${str ?? num}"`)
        .join(' ');
      return `<${tag} ${pairs} />`;
    })
    .join('');
};

/* -- compose ------------------------------------------------------------- */

/**
 * `box` is the drawing's native side length: the botanicals are drawn in 48,
 * the icon set in 24. Both are scaled into a 44-unit window inside a 64-unit
 * canvas, so every subject ends up the same visual weight.
 */
const compose = (markup, palette, box) => {
  const c = P[palette];
  const scale = 42 / box;
  const width = (box === 24 ? 1.95 : 2.05) / scale;
  const inner = markup.replace(/INTERIOR/g, 'url(#interior)');
  const shadow = markup.replace(/INTERIOR/g, '#0a1a12');

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" height="64">
  <defs>
    <linearGradient id="line" x1="0.15" y1="0" x2="0.6" y2="1">
      <stop offset="0" stop-color="${c.l}"/><stop offset="1" stop-color="${c.d}"/>
    </linearGradient>
    <linearGradient id="interior" x1="0.2" y1="0" x2="0.55" y2="1">
      <stop offset="0" stop-color="${c.f1}" stop-opacity="0.82"/>
      <stop offset="1" stop-color="${c.f2}" stop-opacity="0.52"/>
    </linearGradient>
    <radialGradient id="halo" cx="0.36" cy="0.3" r="0.72">
      <stop offset="0" stop-color="${c.f1}" stop-opacity="0.3"/>
      <stop offset="1" stop-color="${c.f2}" stop-opacity="0"/>
    </radialGradient>
    <linearGradient id="rim" x1="0.2" y1="0" x2="0.5" y2="0.8">
      <stop offset="0" stop-color="#ffffff" stop-opacity="0.5"/>
      <stop offset="1" stop-color="#ffffff" stop-opacity="0"/>
    </linearGradient>
  </defs>

  <circle cx="31" cy="30" r="31" fill="url(#halo)"/>

  <g transform="translate(11 11) scale(${scale.toFixed(4)})" fill="none"
     stroke-width="${width.toFixed(2)}" stroke-linecap="round" stroke-linejoin="round">
    <g stroke="#07130d" stroke-opacity="0.28" transform="translate(0.7 1.5)">${shadow}</g>
    <g stroke="url(#line)">${inner}</g>
    <g stroke="url(#rim)" stroke-width="${(width * 0.34).toFixed(2)}"
       transform="translate(-0.35 -0.7)" opacity="0.85">${markup.replace(/INTERIOR/g, 'none')}</g>
  </g>
</svg>`;
};

/* -- write --------------------------------------------------------------- */

const botanicals = readBotanicals();
mkdirSync(OUT, { recursive: true });

const subjects = new Map();
for (const [id, markup] of Object.entries(botanicals)) subjects.set(id, { markup, box: 48 });
for (const [id, file] of Object.entries(ICON_FILE)) {
  if (subjects.has(id)) continue; // a hand-drawn botanical always wins
  subjects.set(id, { markup: readIcon(file), box: 24 });
}

let written = 0;
let bytes = 0;
const missing = [];
for (const [id, { markup, box }] of subjects) {
  const palette = PALETTE[id];
  if (!palette) {
    missing.push(id);
    continue;
  }
  const svg = compose(markup, palette, box);
  const file = join(OUT, `${id}.webp`);
  await sharp(Buffer.from(svg), { density: 384 })
    .resize({ width: 160, height: 160, fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
    .webp({ quality: 82, effort: 6, alphaQuality: 90 })
    .toFile(file);
  bytes += statSync(file).size;
  written++;
}

if (missing.length) console.warn(`[marks] no palette for: ${missing.join(', ')}`);
console.log(`[marks] wrote ${written} WebP files — ${(bytes / 1024).toFixed(0)} KB total.`);
